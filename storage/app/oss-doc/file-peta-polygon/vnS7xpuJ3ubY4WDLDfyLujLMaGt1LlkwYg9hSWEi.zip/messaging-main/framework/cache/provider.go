package cache

import (
	"context"
	"errors"
	"github.com/go-redis/redis/v8"
	"time"
)

type RedisProvider struct {
	rdc *redis.Client
}

func NewRedisProvider(rdc *redis.Client) *RedisProvider {
	return &RedisProvider{rdc: rdc}
}

func (p *RedisProvider) Get(ctx context.Context, key string) (string, error) {
	val, err := p.rdc.Get(ctx, key).Result()
	if err != nil && errors.Is(err, redis.Nil) {
		return "", ErrCacheNotFound
	}

	return val, nil
}

func (p *RedisProvider) Set(ctx context.Context, key, val string, ttl time.Duration) error {
	return p.rdc.Set(ctx, key, val, ttl).Err()
}
