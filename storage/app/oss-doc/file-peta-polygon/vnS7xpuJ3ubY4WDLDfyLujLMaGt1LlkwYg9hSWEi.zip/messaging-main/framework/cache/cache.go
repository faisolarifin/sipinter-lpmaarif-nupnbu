package cache

import (
	"context"
	"encoding/json"
	"errors"
	"time"
)

type (
	Provider interface {
		Get(ctx context.Context, key string) (string, error)
		Set(ctx context.Context, key, val string, ttl time.Duration) error
	}

	wrapper[T any] struct {
		Data *T `json:"data"`
	}
)

func Cache[T any](ctx context.Context, provider Provider, key string, ttl time.Duration, getter func() (*T, error)) (*T, error) {
	var (
		tmp    T
		result *T
	)

	// get from cache
	val, err := provider.Get(ctx, key)
	if err != nil && !errors.Is(err, ErrCacheNotFound) {
		return nil, err
	}

	// data not found in cache, get from getter
	if errors.Is(err, ErrCacheNotFound) {
		result, err = getter()
		if err != nil {
			return nil, err
		}

		// encode data
		var data []byte
		switch any(tmp).(type) {
		case struct{}:
			data, err = json.Marshal(result)
			if err != nil {
				return nil, err
			}
		default:
			w := wrapper[T]{Data: result}
			data, err = json.Marshal(w)
			if err != nil {
				return nil, err
			}
		}

		// save data to cache
		err = provider.Set(ctx, key, string(data), ttl)
		if err != nil {
			return nil, err
		}

		return result, nil
	}

	// decode data
	result = new(T)
	switch any(tmp).(type) {
	case struct{}:
		err = json.Unmarshal([]byte(val), result)
		if err != nil {
			return nil, err
		}
	default:
		var w wrapper[T]
		err = json.Unmarshal([]byte(val), &w)
		if err != nil {
			return nil, err
		}

		result = w.Data
	}

	return result, nil
}
