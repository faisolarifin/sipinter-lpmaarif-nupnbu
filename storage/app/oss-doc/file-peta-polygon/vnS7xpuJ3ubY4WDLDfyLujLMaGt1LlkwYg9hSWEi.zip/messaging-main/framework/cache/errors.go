package cache

import "errors"

var ErrCacheNotFound = errors.New("cache not found")
