package loggerx

import (
	"github.com/sirupsen/logrus"
	"time"
)

func Elapsed(l *logrus.Entry, label string, fn func() error) error {
	startTime := time.Now()
	defer func(startTime time.Time) {
		finishTime := time.Now()
		elapsedTime := finishTime.Sub(startTime)
		l.WithFields(logrus.Fields{
			"start_time": startTime, "finish_time": finishTime, "elapsed_time": elapsedTime.String()}).
			Infoln(label)
	}(startTime)

	return fn()
}

func ElapsedWithResult[T any](l *logrus.Entry, label string, fn func() (*T, error)) (*T, error) {
	startTime := time.Now()
	defer func(startTime time.Time) {
		finishTime := time.Now()
		elapsedTime := finishTime.Sub(startTime)
		l.WithFields(logrus.Fields{
			"start_time": startTime, "finish_time": finishTime, "elapsed_time": elapsedTime.String()}).
			Infoln(label)
	}(startTime)

	return fn()
}
