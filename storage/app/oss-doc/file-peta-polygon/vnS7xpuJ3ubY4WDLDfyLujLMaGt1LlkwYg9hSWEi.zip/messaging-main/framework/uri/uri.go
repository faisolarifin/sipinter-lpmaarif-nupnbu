package uri

import (
	"net/url"
	"strconv"
	"strings"

	"github.com/pkg/errors"
)

type URI struct {
	*url.URL
}

func (u *URI) User() string {
	return u.URL.User.Username()
}

func (u *URI) Password() string {
	password, _ := u.URL.User.Password()
	return password
}

func (u *URI) Port() int {
	port, _ := strconv.Atoi(u.URL.Port())
	return port
}

func (u *URI) Database() string {
	var database string
	parts := strings.Split(strings.TrimLeft(u.Path, "/"), "/")
	if len(parts) > 0 {
		database = parts[0]
	}
	return database
}

func Parse(rawURI string) (*URI, error) {
	u, err := url.Parse(rawURI)
	if err != nil {
		return nil, errors.WithStack(err)
	}

	return &URI{URL: u}, nil
}
