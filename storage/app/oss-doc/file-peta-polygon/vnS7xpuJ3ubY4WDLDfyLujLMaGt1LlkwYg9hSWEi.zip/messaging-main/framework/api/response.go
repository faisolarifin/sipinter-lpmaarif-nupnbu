package api

import (
	"encoding/json"
	"fmt"
	"io"
	"io/ioutil"
	"net/http"
)

func NewErrorResponse(format string, args ...any) *ErrorResponse {
	return &ErrorResponse{message: fmt.Sprintf(format, args)}
}

func NewErrorResponseWithError(err error) *ErrorResponse {
	return NewErrorResponse("%+v", err)
}

type ErrorResponse struct {
	message string
}

func (e *ErrorResponse) Error() string {
	return e.message
}
 
func NewResponse[T any](response *http.Response) *Response[T] {
	result := &Response[T]{
		Header:     response.Header,
		Status:     response.Status,
		StatusCode: response.StatusCode,
	}
	body, err := ioutil.ReadAll(response.Body)
	if err != nil {
		result.Error = NewErrorResponseWithError(err)
		return result
	}
	defer func(body io.ReadCloser) {
		_ = body.Close()
	}(response.Body)

	result.RawBody = body
	resource := new(T)
	if err = json.Unmarshal(body, resource); err != nil {
		result.Error = NewErrorResponseWithError(err)
	}
	result.Resource = resource

	return result
}

type Response[T any] struct {
	Error      error
	Header     http.Header
	RawBody    []byte
	Resource   *T
	Status     string
	StatusCode int
}

func (r *Response[T]) IsError() bool {
	return r.Error != nil
}
