package framework

import (
	"reflect"
	"sync"
)

type Map[K comparable, V any] struct {
	m     map[K]V
	rwmtx sync.RWMutex
}

func NewMap[K comparable, V any]() *Map[K, V] {
	return &Map[K, V]{
		m:     map[K]V{},
		rwmtx: sync.RWMutex{},
	}
}

func (m *Map[K, V]) Add(key K, value V) {
	m.TryAdd(key, value)
}

func (m *Map[K, V]) Clear() {
	m.rwmtx.Lock()
	defer m.rwmtx.Unlock()
	for key, _ := range m.m {
		delete(m.m, key)
	}
}

func (m *Map[K, V]) Count() int {
	return len(m.m)
}

func (m *Map[K, V]) Get(key K) V {
	value, _ := m.TryGet(key)
	return value
}

func (m *Map[K, V]) HasKey(key K) bool {
	m.rwmtx.RLock()
	defer m.rwmtx.RUnlock()
	_, ok := m.m[key]
	return ok
}

func (m *Map[K, V]) HasValue(value V) bool {
	m.rwmtx.RLock()
	defer m.rwmtx.RUnlock()
	for _, v := range m.m {
		if reflect.DeepEqual(value, v) {
			return true
		}
	}
	return false
}

func (m *Map[K, V]) Keys() []K {
	m.rwmtx.RLock()
	defer m.rwmtx.RUnlock()
	var keys []K
	for key, _ := range m.m {
		keys = append(keys, key)
	}
	return keys
}

func (m *Map[K, V]) Values() []V {
	m.rwmtx.RLock()
	defer m.rwmtx.RUnlock()
	var values []V
	for _, value := range m.m {
		values = append(values, value)
	}
	return values
}

func (m *Map[K, V]) Range(fn func(key K, value V) bool) {
	m.rwmtx.RLock()
	defer m.rwmtx.RUnlock()
	for key, value := range m.m {
		if !fn(key, value) {
			break
		}
	}
}

func (m *Map[K, V]) Remove(key K) {
	m.TryRemove(key)
}

func (m *Map[K, V]) TryAdd(key K, value V) bool {
	m.rwmtx.Lock()
	defer m.rwmtx.Unlock()
	_, ok := m.m[key]
	if !ok {
		m.m[key] = value
	}
	return !ok
}

func (m *Map[K, V]) TryGet(key K) (V, bool) {
	m.rwmtx.RLock()
	defer m.rwmtx.RUnlock()
	value, ok := m.m[key]
	return value, ok
}

func (m *Map[K, V]) TryRemove(key K) bool {
	m.rwmtx.Lock()
	defer m.rwmtx.Unlock()
	_, ok := m.m[key]
	if ok {
		delete(m.m, key)
	}
	return ok
}
