package pointer

func New[T any](arg T) *T {
	result := new(T)
	*result = arg

	return result
}

func Default[T comparable](v *T, d T) T {
	if v == nil {
		return d
	}

	return *v
}

func Copy[T comparable](s *T) *T {
	var result *T
	if s != nil {
		result = New(*s)
	}

	return result
}
