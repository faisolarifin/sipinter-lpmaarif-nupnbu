package messaging

import (
	"sync/atomic"

	"framework/amqpx"
	"framework/messaging/consumer"

	amqp "github.com/rabbitmq/amqp091-go"
)

type AMQPConsumerOptions struct {
	Qos *consumer.QosOptions
}

type AMQPConsumerOption func(options *AMQPConsumerOptions)

func Qos(prefetchCount, prefetchSize int, global bool) AMQPConsumerOption {
	return func(options *AMQPConsumerOptions) {
		options.Qos = &consumer.QosOptions{
			PrefetchCount: prefetchCount,
			PrefetchSize:  prefetchSize,
			Global:        global,
		}
	}
}

type AMQPConsumer struct {
	opts    *AMQPConsumerOptions
	state   int32
	stop    chan struct{}
	stopped chan struct{}
	handler func(delivery amqp.Delivery)
	channel *amqpx.Channel
}

func NewAMQPConsumer(conn amqpx.ChannelReader, options ...AMQPConsumerOption) *AMQPConsumer {
	channel, err := conn.Channel()
	if err != nil {
		panic(err)
		return nil
	}

	opts := &AMQPConsumerOptions{}
	for _, option := range options {
		option(opts)
	}

	if opts.Qos == nil {
		opts.Qos = &consumer.QosOptions{
			PrefetchCount: 1,
			PrefetchSize:  0,
			Global:        false,
		}
	}

	return &AMQPConsumer{
		opts:    opts,
		channel: channel,
	}
}

func (c *AMQPConsumer) Consume(queue string, handler func(delivery amqp.Delivery)) error {
	if !atomic.CompareAndSwapInt32(&c.state, 0, 1) {
		return nil
	}

	_, _ = c.channel.QueueDeclare(queue, true, false, false, false, nil)

	c.handler = handler
	c.stop = make(chan struct{})
	c.stopped = make(chan struct{})

	if c.opts.Qos != nil {
		err := c.channel.Qos(c.opts.Qos.PrefetchCount, c.opts.Qos.PrefetchSize, c.opts.Qos.Global)
		if err != nil {
			return err
		}
	}

	deliveries, err := c.channel.Consume(
		queue,
		"",
		false,
		false,
		false,
		false,
		nil,
	)
	if err != nil {
		return err
	}

	go c.consume(c.channel, c.handler, deliveries, c.stop, c.stopped)

	return nil
}

func (c *AMQPConsumer) consume(channel *amqpx.Channel, handler func(delivery amqp.Delivery), deliveries <-chan amqp.Delivery, stop, stopped chan struct{}) {
	defer func(channel *amqpx.Channel) {
		if err := recover(); err != nil {
			c.consume(channel, handler, deliveries, stop, stopped)
		} else {
			_ = channel.Close()
			close(stopped)
		}
	}(channel)

	for {
		select {
		case delivery, ok := <-deliveries:
			if !ok || channel.IsClosed() {
				atomic.StoreInt32(&c.state, 0)
				return
			}
			handler(delivery)
		case <-stop:
			return
		}
	}
}

func (c *AMQPConsumer) Stop() {
	if !atomic.CompareAndSwapInt32(&c.state, 1, 0) {
		return
	}
	close(c.stop)
	<-c.stopped
}
