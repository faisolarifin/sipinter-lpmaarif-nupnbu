package messaging

import (
	"framework/amqpx"
	"framework/messaging/consumer"
)

type AMQPFactory interface {
	NewAMQPConsumer(opts ...AMQPConsumerOption) *AMQPConsumer
	NewAMQPWorkerConsumer(newAMQPWorker NewAMQPWorker, opts ...consumer.AMQPConsumerOption) *AMQPWorkerConsumer
	NewAMQPPublisher() *AMQPPublisher
}

type AMQPConnectionFactory struct {
	amqpReader amqpx.ChannelReader
	amqpWriter amqpx.ChannelReader
}

func NewAMQPConnectionFactory(amqpReader, amqpWriter amqpx.ChannelReader) *AMQPConnectionFactory {
	return &AMQPConnectionFactory{amqpReader: amqpReader, amqpWriter: amqpWriter}
}

func (f *AMQPConnectionFactory) NewAMQPConsumer(opts ...AMQPConsumerOption) *AMQPConsumer {
	return NewAMQPConsumer(f.amqpReader, opts...)
}

func (f *AMQPConnectionFactory) NewAMQPWorkerConsumer(newAMQPWorker NewAMQPWorker, opts ...consumer.AMQPConsumerOption) *AMQPWorkerConsumer {
	return NewAMQPWorkerConsumer(f.amqpReader, newAMQPWorker, opts...)
}

func (f *AMQPConnectionFactory) NewAMQPPublisher() *AMQPPublisher {
	return NewAMQPPublisher(f.amqpWriter)
}

type AMQPPoolFactory struct {
	amqpReader *amqpx.Pool
	amqpWriter *amqpx.Pool
}

func NewAMQPPoolFactory(amqpReader, amqpWriter *amqpx.Pool) *AMQPPoolFactory {
	return &AMQPPoolFactory{amqpReader: amqpReader, amqpWriter: amqpWriter}
}

func (f *AMQPPoolFactory) NewAMQPConsumer(opts ...AMQPConsumerOption) *AMQPConsumer {
	return NewAMQPConsumer(f.amqpReader, opts...)
}

func (f *AMQPPoolFactory) NewAMQPWorkerConsumer(newAMQPWorker NewAMQPWorker, opts ...consumer.AMQPConsumerOption) *AMQPWorkerConsumer {
	return NewAMQPWorkerConsumer(f.amqpReader, newAMQPWorker, opts...)
}

func (f *AMQPPoolFactory) NewAMQPPublisher() *AMQPPublisher {
	return NewAMQPPublisher(f.amqpWriter)
}
