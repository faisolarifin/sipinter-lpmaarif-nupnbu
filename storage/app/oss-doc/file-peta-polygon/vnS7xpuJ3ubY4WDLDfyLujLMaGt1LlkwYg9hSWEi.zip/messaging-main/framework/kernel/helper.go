package kernel

import (
	"os"
)

func exe() string {
	path, err := os.Executable()
	if err != nil {
		return ""
	}

	for i := len(path) - 1; i >= 0; i-- {
		if path[i] == os.PathSeparator {
			exe := path[i+1:]
			for j := len(exe) - 1; j >= 0; j-- {
				if exe[j] == '.' {
					return exe[:j]
				}
			}
			return exe
		}
	}

	return ""
}
