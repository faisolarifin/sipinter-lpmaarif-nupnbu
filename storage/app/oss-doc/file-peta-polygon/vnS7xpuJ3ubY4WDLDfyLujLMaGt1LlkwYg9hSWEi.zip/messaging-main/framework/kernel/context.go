package kernel

import (
	"github.com/sirupsen/logrus"
	"github.com/spf13/viper"
)

type Context interface {
	Config() *viper.Viper
	Logger() *logrus.Logger
}
