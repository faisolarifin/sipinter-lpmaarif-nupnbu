package kernel

import (
	"sync"

	"framework/kernel/config"
	"framework/kernel/logging"

	"github.com/sirupsen/logrus"
	"github.com/spf13/viper"
)

type Builder[T Context] interface {
	NewContext(fn NewContextFn[T]) Builder[T]
	ConfigureConfiguration(fn ConfigureConfigurationFn) Builder[T]
	ConfigureLogging(fn ConfigureLoggingFn) Builder[T]
	Bootstrap(fn func() []BootstrapFn[T]) Builder[T]
	Run(fn func(ctx T) []RunFn) Builder[T]
	Startup(fn StartupFn[T]) Builder[T]
	Shutdown(fn ShutdownFn[T]) Builder[T]
	Build() Kernel[T]
}

func NewBuilder[T Context]() Builder[T] {
	return &builder[T]{}
}

type builder[T Context] struct {
	newContext             NewContextFn[T]
	configureConfiguration ConfigureConfigurationFn
	configureLogging       ConfigureLoggingFn
	startup                StartupFn[T]
	shutdown               ShutdownFn[T]
	bootstraps             []func() []BootstrapFn[T]
	runners                []func(ctx T) []RunFn
}

func (b *builder[T]) NewContext(fn NewContextFn[T]) Builder[T] {
	b.newContext = fn
	return b
}

func (b *builder[T]) ConfigureConfiguration(fn ConfigureConfigurationFn) Builder[T] {
	b.configureConfiguration = fn
	return b
}

func (b *builder[T]) ConfigureLogging(fn ConfigureLoggingFn) Builder[T] {
	b.configureLogging = fn
	return b
}

func (b *builder[T]) Bootstrap(fn func() []BootstrapFn[T]) Builder[T] {
	b.bootstraps = append(b.bootstraps, fn)
	return b
}

func (b *builder[T]) Run(fn func(ctx T) []RunFn) Builder[T] {
	b.runners = append(b.runners, fn)
	return b
}

func (b *builder[T]) Startup(fn StartupFn[T]) Builder[T] {
	b.startup = fn
	return b
}

func (b *builder[T]) Shutdown(fn ShutdownFn[T]) Builder[T] {
	b.shutdown = fn
	return b
}

func (b *builder[T]) Build() Kernel[T] {
	conf := b.buildConfiguration()
	logger := b.buildLogging(conf)
	ctx := b.newContext(conf, logger)

	var bootstraps []BootstrapFn[T]
	for _, bootstrap := range b.bootstraps {
		bootstraps = append(bootstraps, bootstrap()...)
	}

	var runners []RunFn
	for _, runner := range b.runners {
		runners = append(runners, runner(ctx)...)
	}

	k := &kernel[T]{
		ctx:        ctx,
		bootstraps: bootstraps,
		runWg:      &sync.WaitGroup{},
		runners:    runners,
		startup:    b.startup,
		shutdown:   b.shutdown,
	}

	return k
}

func (b *builder[T]) buildConfiguration() *viper.Viper {
	configureConfiguration := b.configureConfiguration
	if configureConfiguration == nil {
		configureConfiguration = func() config.Options {
			return config.NewFileOptions().
				SetName(exe())
		}
	}

	return configureConfiguration().Build()
}

func (b *builder[T]) buildLogging(conf *viper.Viper) *logrus.Logger {
	configureLogging := b.configureLogging
	if configureLogging == nil {
		configureLogging = func(conf *viper.Viper) logging.Options {
			return logging.NewConfigFileOptions(logging.Key, conf)
		}
	}

	return configureLogging(conf).Build()
}
