package bootstrap

import (
	"context"
	"fmt"

	"framework/kernel"

	"github.com/go-redis/redis/v8"
)

const (
	RedisKey = "redis"
)

type RedisOptions struct {
	Host     string `mapstructure:"host"`
	Port     int    `mapstructure:"port"`
	Password string `mapstructure:"password"`
	Database int    `mapstructure:"database"`
}

func (o *RedisOptions) Address() string {
	return fmt.Sprintf("%s:%d", o.Host, o.Port)
}

func Redis(ctx context.Context, kctx kernel.Context) *redis.Client {
	return RedisWithKey(ctx, RedisKey, kctx)
}

func RedisWithKey(ctx context.Context, key string, kctx kernel.Context) *redis.Client {
	var opts RedisOptions
	err := kctx.Config().UnmarshalKey(key, &opts)
	if err != nil {
		panic(err)
	}

	return RedisWithOptions(ctx, &opts)
}

func RedisWithOptions(ctx context.Context, opts *RedisOptions) *redis.Client {
	client := redis.NewClient(&redis.Options{
		Addr:     opts.Address(),
		Password: opts.Password,
		DB:       opts.Database,
	})

	if _, err := client.Ping(ctx).Result(); err != nil {
		panic(err)
	}

	return client
}
