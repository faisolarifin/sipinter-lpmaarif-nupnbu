package logging

import (
	"fmt"
	"io"
	"path"
	"time"

	"framework/kernel/logging/hook"

	"github.com/sirupsen/logrus"
	"github.com/spf13/viper"
	"gopkg.in/natefinch/lumberjack.v2"
)

const (
	Key = "log"
)

type Options interface {
	Build() *logrus.Logger
}

type FileOptions struct {
	Dir          string `mapstructure:"dir"`
	Level        string `mapstructure:"level"`
	FileName     string `mapstructure:"file_name"`
	MaxBackups   int    `mapstructure:"max_backups"`
	MaxSize      int    `mapstructure:"max_size"`
	MaxAge       int    `mapstructure:"max_age"`
	Compress     bool   `mapstructure:"compress"`
	Console      bool   `mapstructure:"console"`
	ReportCaller bool   `mapstructure:"report_caller"`
}

func NewFileOptions(name string) *FileOptions {
	return &FileOptions{
		Dir:          ".",
		Level:        "trace",
		FileName:     name,
		MaxBackups:   100,
		MaxSize:      20,
		MaxAge:       30,
		Compress:     true,
		ReportCaller: true,
	}
}

func NewConfigFileOptions(key string, conf *viper.Viper) *FileOptions {
	opts := &FileOptions{}
	if err := conf.UnmarshalKey(key, opts); err != nil {
		panic(err)
	}
	return opts
}

func (o *FileOptions) SetDir(dir string) *FileOptions {
	o.Dir = dir
	return o
}

func (o *FileOptions) SetLevel(level string) *FileOptions {
	o.Level = level
	return o
}

func (o *FileOptions) SetFileName(fileName string) *FileOptions {
	o.FileName = fileName
	return o
}

func (o *FileOptions) SetMaxBackups(maxBackups int) *FileOptions {
	o.MaxBackups = maxBackups
	return o
}

func (o *FileOptions) SetMaxSize(maxSize int) *FileOptions {
	o.MaxSize = maxSize
	return o
}

func (o *FileOptions) SetMaxAge(maxAge int) *FileOptions {
	o.MaxAge = maxAge
	return o
}

func (o *FileOptions) SetCompress(compress bool) *FileOptions {
	o.Compress = compress
	return o
}

func (o *FileOptions) SetReportCaller(reportCaller bool) *FileOptions {
	o.ReportCaller = reportCaller
	return o
}

func (o *FileOptions) Build() *logrus.Logger {
	level, err := logrus.ParseLevel(o.Level)
	if err != nil {
		level = logrus.InfoLevel
	}

	errorWriter := &lumberjack.Logger{
		Compress:   o.Compress,
		Filename:   path.Join(o.Dir, fmt.Sprintf("%s.error.log", o.FileName)),
		MaxAge:     o.MaxAge,
		MaxBackups: o.MaxBackups,
		MaxSize:    o.MaxSize,
	}

	infoWriter := &lumberjack.Logger{
		Compress:   o.Compress,
		Filename:   path.Join(o.Dir, fmt.Sprintf("%s.info.log", o.FileName)),
		MaxAge:     o.MaxAge,
		MaxBackups: o.MaxBackups,
		MaxSize:    o.MaxSize,
	}

	logger := logrus.New()
	logger.SetLevel(level)
	logger.SetReportCaller(o.ReportCaller)
	logger.SetFormatter(&logrus.TextFormatter{
		FullTimestamp:   true,
		TimestampFormat: time.RFC3339Nano,
	})
	if !o.Console {
		logger.SetOutput(io.Discard)
	}

	// Send logs with level higher than warning to stderr
	logger.AddHook(&hook.Writer{
		Writer: errorWriter,
		LogLevels: []logrus.Level{
			logrus.PanicLevel,
			logrus.FatalLevel,
			logrus.ErrorLevel,
			logrus.WarnLevel,
		},
	})

	// Send info and debug logs to stdout
	logger.AddHook(&hook.Writer{
		Writer: infoWriter,
		LogLevels: []logrus.Level{
			logrus.InfoLevel,
			logrus.DebugLevel,
			logrus.TraceLevel,
		},
	})

	return logger
}
