package bootstrap

import (
	"framework/kernel"

	amqp "github.com/rabbitmq/amqp091-go"
)

const (
	AMQPKey = "amqp"
)

type AMQPOptions struct {
	URI string `mapstructure:"uri"`
}

func AMQP(ctx kernel.Context) *amqp.Connection {
	return AMQPWithKey(AMQPKey, ctx)
}

func AMQPWithKey(key string, ctx kernel.Context) *amqp.Connection {
	var opts AMQPOptions
	err := ctx.Config().UnmarshalKey(key, &opts)
	if err != nil {
		panic(err)
	}

	return AMQPWithURI(opts.URI)
}

func AMQPWithURI(uri string) *amqp.Connection {
	conn, err := amqp.Dial(uri)
	if err != nil {
		panic(err)
	}
	return conn
}
