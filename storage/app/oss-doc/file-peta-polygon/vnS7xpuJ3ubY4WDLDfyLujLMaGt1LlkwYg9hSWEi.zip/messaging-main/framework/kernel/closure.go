package kernel

import (
	"framework/kernel/config"
	"framework/kernel/logging"

	"github.com/sirupsen/logrus"
	"github.com/spf13/viper"
)

type (
	StartupFn[T Context]     func(ctx T)
	ShutdownFn[T Context]    func(ctx T)
	NewContextFn[T Context]  func(conf *viper.Viper, logger *logrus.Logger) T
	ConfigureLoggingFn       func(conf *viper.Viper) logging.Options
	ConfigureConfigurationFn func() config.Options
	BootstrapFn[T Context]   func(ctx T) func(ctx T)
	RunFn                    func(stop chan struct{})
)

func BootstrapNoCleanup[T Context](fn func(ctx T)) BootstrapFn[T] {
	return func(ctx T) func(ctx T) {
		fn(ctx)
		return func(ctx T) {}
	}
}
