package kernel

import (
	"fmt"
	"runtime/debug"
	"sync"
	"sync/atomic"
)

type Kernel[T Context] interface {
	Context() T
	Start()
	Stop()
}

type kernel[T Context] struct {
	ctx        T
	state      int32
	stop       chan struct{}
	bootstraps []BootstrapFn[T]
	cleanups   []func(ctx T)
	runWg      *sync.WaitGroup
	runners    []RunFn
	startup    StartupFn[T]
	shutdown   ShutdownFn[T]
}

func (k *kernel[T]) Context() T {
	return k.ctx
}

func (k *kernel[T]) Start() {
	if !atomic.CompareAndSwapInt32(&k.state, 0, 1) {
		return
	}

	for _, bootstrap := range k.bootstraps {
		cleanup := bootstrap(k.ctx)
		k.cleanups = append(k.cleanups, cleanup)
	}

	k.stop = make(chan struct{})
	k.run()

	if k.startup != nil {
		k.startup(k.ctx)
	}
}

func (k *kernel[T]) Stop() {
	if !atomic.CompareAndSwapInt32(&k.state, 1, 0) {
		return
	}

	close(k.stop)
	k.runWg.Wait()
	for _, cleanup := range k.cleanups {
		cleanup(k.ctx)
	}

	if k.shutdown != nil {
		k.shutdown(k.ctx)
	}
}

func (k *kernel[T]) launch(runner RunFn) {
	k.runWg.Add(1)
	go func(wg *sync.WaitGroup, fn RunFn) {
		defer func() {
			wg.Done()
			if err := recover(); err != nil {
				e := fmt.Errorf("%+v\n%s", err, string(debug.Stack()))
				k.ctx.Logger().WithError(e).Errorln("runner recover from panic")

				if atomic.LoadInt32(&k.state) == 1 {
					k.launch(runner)
				}
			}
		}()
		fn(k.stop)
	}(k.runWg, runner)
}

func (k *kernel[T]) run() {
	for _, runner := range k.runners {
		k.launch(runner)
	}
}
