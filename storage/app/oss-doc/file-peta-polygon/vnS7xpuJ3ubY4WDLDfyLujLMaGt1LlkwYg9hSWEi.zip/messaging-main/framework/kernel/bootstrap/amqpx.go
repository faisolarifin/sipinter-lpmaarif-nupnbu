package bootstrap

import (
	"framework/amqpx"
	"framework/kernel"
)

const (
	AMQPXKey = "amqp"
	poolSize = 2047
)

type AMQPXOptions struct {
	URI  string `mapstructure:"uri"`
	Pool struct {
		Size int `mapstructure:"size"`
	} `mapstructure:"pool"`
}

func AMQPX(ctx kernel.Context) *amqpx.Connection {
	return AMQPXWithKey(AMQPXKey, ctx)
}

func AMQPXWithKey(key string, ctx kernel.Context) *amqpx.Connection {
	var opts AMQPXOptions
	err := ctx.Config().UnmarshalKey(key, &opts)
	if err != nil {
		panic(err)
	}

	return AMQPXWithURI(opts.URI)
}

func AMQPXWithURI(uri string) *amqpx.Connection {
	conn, err := amqpx.Dial(uri)
	if err != nil {
		panic(err)
	}
	return conn
}

func AMQPXPool(ctx kernel.Context) *amqpx.Pool {
	return AMQPXPoolWithKey(AMQPXKey, ctx)
}

func AMQPXPoolWithKey(key string, ctx kernel.Context) *amqpx.Pool {
	var opts AMQPXOptions
	err := ctx.Config().UnmarshalKey(key, &opts)
	if err != nil {
		panic(err)
	}

	size := opts.Pool.Size
	if size < 1 {
		size = poolSize
	}

	return AMQPXPoolWithURI(opts.URI, size)
}

func AMQPXPoolWithURI(uri string, size int) *amqpx.Pool {
	return amqpx.DialPool(uri, size)
}
