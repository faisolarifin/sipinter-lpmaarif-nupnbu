package config

import (
	"bytes"
	"strings"

	"github.com/spf13/viper"
)

type Options interface {
	Build() *viper.Viper
}

type FileOptions struct {
	Type  string
	Name  string
	Paths []string
}

func NewFileOptions() *FileOptions {
	return &FileOptions{
		Type:  "yaml",
		Paths: []string{"."},
	}
}

func (o *FileOptions) SetType(typ string) *FileOptions {
	o.Type = typ
	return o
}

func (o *FileOptions) SetName(name string) *FileOptions {
	o.Name = name
	return o
}

func (o *FileOptions) SetPaths(paths []string) *FileOptions {
	o.Paths = paths
	return o
}

func (o *FileOptions) AddPath(paths ...string) *FileOptions {
	o.Paths = append(o.Paths, paths...)
	return o
}

func (o *FileOptions) Build() *viper.Viper {
	v := viper.New()
	v.SetConfigType(o.Type)
	v.SetConfigName(o.Name)
	for _, item := range o.Paths {
		v.AddConfigPath(item)
	}
	v.AutomaticEnv()
	v.AllowEmptyEnv(true)
	v.SetEnvKeyReplacer(strings.NewReplacer(".", "_"))
	if err := v.ReadInConfig(); err != nil {
		panic(err)
	}

	return v
}

type BytesOptions struct {
	Type string
	Data []byte
}

func NewBytesOptions() *BytesOptions {
	return &BytesOptions{
		Type: "yaml",
	}
}

func (o *BytesOptions) SetType(typ string) *BytesOptions {
	o.Type = typ
	return o
}

func (o *BytesOptions) SetData(data []byte) *BytesOptions {
	o.Data = data
	return o
}

func (o *BytesOptions) Build() *viper.Viper {
	v := viper.New()
	v.SetConfigType(o.Type)
	v.AutomaticEnv()
	v.AllowEmptyEnv(true)
	v.SetEnvKeyReplacer(strings.NewReplacer(".", "_"))
	if err := v.ReadConfig(bytes.NewBuffer(o.Data)); err != nil {
		panic(err)
	}

	return v
}

type RemoteOptions struct {
	Type     string
	Provider string
	Endpoint string
	Path     string
}

func NewRemoteOptions() *RemoteOptions {
	return &RemoteOptions{
		Type: "yaml",
	}
}

func (o *RemoteOptions) SetType(typ string) *RemoteOptions {
	o.Type = typ
	return o
}

func (o *RemoteOptions) SetProvider(provider string) *RemoteOptions {
	o.Provider = provider
	return o
}

func (o *RemoteOptions) SetEndpoint(endpoint string) *RemoteOptions {
	o.Provider = endpoint
	return o
}

func (o *RemoteOptions) SetPath(path string) *RemoteOptions {
	o.Path = path
	return o
}

func (o *RemoteOptions) Build() *viper.Viper {
	v := viper.New()
	v.SetConfigType(o.Type)
	if err := v.AddRemoteProvider(o.Provider, o.Endpoint, o.Path); err != nil {
		panic(err)
	}
	v.AutomaticEnv()
	v.AllowEmptyEnv(true)
	v.SetEnvKeyReplacer(strings.NewReplacer(".", "_"))
	if err := v.ReadRemoteConfig(); err != nil {
		panic(err)
	}

	return v
}
