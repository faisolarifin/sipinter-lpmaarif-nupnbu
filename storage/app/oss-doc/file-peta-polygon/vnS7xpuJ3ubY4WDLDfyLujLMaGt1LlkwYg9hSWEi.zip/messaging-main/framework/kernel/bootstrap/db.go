package bootstrap

import (
	"context"

	"framework/kernel"

	"github.com/jackc/pgx/v5/pgxpool"
)

const (
	DBKey = "db"
)

type DBOptions struct {
	DSN string `mapstructure:"dsn"`
}

func DB(ctx context.Context, kctx kernel.Context) *pgxpool.Pool {
	return DBWithKey(ctx, DBKey, kctx)
}

func DBWithKey(ctx context.Context, key string, kctx kernel.Context) *pgxpool.Pool {
	var opts DBOptions
	err := kctx.Config().UnmarshalKey(key, &opts)
	if err != nil {
		panic(err)
	}

	return DBWithURI(ctx, opts.DSN)
}

func DBWithURI(ctx context.Context, dsn string) *pgxpool.Pool {
	pool, err := pgxpool.New(ctx, dsn)
	if err != nil {
		panic(err)
	}

	err = pool.Ping(ctx)
	if err != nil {
		panic(err)
	}

	return pool
}
