package hook

import (
	"io"

	"github.com/sirupsen/logrus"
)

// Writer is a hook that writes logs of specified LogLevels to specified Writer
type Writer struct {
	Writer    io.Writer
	LogLevels []logrus.Level
}

// Fire will be called when some logging function is called with current hook
// It will format log entry to string and write it to appropriate writer
func (wh *Writer) Fire(entry *logrus.Entry) error {
	line, err := entry.String()
	if err != nil {
		return err
	}

	_, err = wh.Writer.Write([]byte(line))
	return err
}

// Levels define on which log levels this hook would trigger
func (wh *Writer) Levels() []logrus.Level {
	return wh.LogLevels
}
