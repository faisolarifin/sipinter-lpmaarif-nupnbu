package hash

import (
	"github.com/pkg/errors"
	"golang.org/x/crypto/bcrypt"
)

var (
	ErrMismatchedHashAndPassword = errors.New("hashedPassword is not the hash of the given password")
)

func Hash(password string) (string, error) {
	hash, err := bcrypt.GenerateFromPassword([]byte(password), 10)
	if err != nil {
		return "", errors.WithStack(err)
	}

	return string(hash), nil
}

func Compare(hash string, password string) error {
	if password == "" || hash == "" {
		return errors.New("empty password or hash")
	}

	if err := bcrypt.CompareHashAndPassword([]byte(hash), []byte(password)); err != nil {
		if err == bcrypt.ErrMismatchedHashAndPassword {
			err = ErrMismatchedHashAndPassword
		}

		return errors.WithStack(err)
	}

	return nil
}
