package list

func In[T comparable](arg T, list []T) bool {
	for _, item := range list {
		if arg == item {
			return true
		}
	}

	return false
}

func Copy[T comparable](list []T) []T {
	if list != nil {
		t := make([]T, len(list))
		copy(t, list)
		return t
	}
	return nil
}

func Unique[T any](list []T, key func(T) string) []T {
	var (
		t []T
		k string
	)
	m := make(map[string]bool)

	for i := 0; i < len(list); i++ {
		k = key(list[i])
		if _, ok := m[k]; !ok {
			m[k] = true
			t = append(t, list[i])
		}
	}

	return t
}

func IsUnique[T any](list []T, key func(T) string) bool {
	t := Unique(list, key)
	return len(t) == len(list)
}

func Map[S any, D any](list []S, fn func(item S) D) []D {
	result := make([]D, len(list))
	for i := 0; i < len(list); i++ {
		result[i] = fn(list[i])
	}

	return result
}

func First[T any](list []T) T {
	var result T
	if len(list) > 0 {
		result = list[0]
	}

	return result
}
