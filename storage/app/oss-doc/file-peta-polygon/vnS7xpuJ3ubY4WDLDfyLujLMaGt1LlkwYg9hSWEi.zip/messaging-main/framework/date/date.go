package date

import (
	"database/sql/driver"
	"fmt"
	"io"
	"strings"
	"time"
)

func New(year int, month time.Month, day int) Date {
	return Date(time.Date(year, month, day, 0, 0, 0, 0, time.Local))
}

func Time(tm time.Time) Date {
	return Date(tm)
}

func Now() Date {
	return Date(time.Now().Local())
}

type Date time.Time

func (t Date) Time() time.Time {
	return time.Time(t)
}

func (t Date) String() string {
	return time.Time(t).Format("2006-01-02")
}

func (t Date) MarshalJSON() ([]byte, error) {
	return []byte(fmt.Sprintf(`"%s"`, time.Time(t).Format("2006-01-02"))), nil
}

func (t *Date) UnmarshalJSON(bytes []byte) error {
	if bytes != nil {
		tm, err := time.Parse("2006-01-02", strings.Replace(string(bytes), `"`, "", -1))
		if err != nil {
			return err
		}
		*t = Date(tm.In(time.Local))
	}
	return nil
}

func (t Date) Value() (driver.Value, error) {
	return t.String(), nil
}

func (t *Date) Scan(src any) error {
	if src == nil {
		return nil
	}

	switch v := src.(type) {
	case []byte:
		tm, err := time.Parse("2006-01-02", string(v))
		if err != nil {
			return err
		}
		*t = Date(tm.In(time.Local))
	case string:
		tm, err := time.Parse("2006-01-02", v)
		if err != nil {
			return err
		}
		*t = Date(tm.In(time.Local))
	}

	return fmt.Errorf("invalid value `%+v`", src)
}

func (t Date) Format(f fmt.State, verb rune) {
	_, _ = io.WriteString(f, t.String())
}
