package database

import (
	"context"
	"testing"

	"github.com/jackc/pgtype/pgxtype"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/stretchr/testify/assert"
)

func TestTxRepository(t *testing.T) {
	db, err := pgxpool.Connect(context.Background(), "postgres://test:test@localhost/test?sslmode=disable")
	if err != nil {
		assert.FailNow(t, err.Error())
	}
	var repo SessionRepository
	repo = &SqlSessionRepository{
		db: db,
		TxRepository: NewTxRepository[SessionRepository](func() any {
			return &SqlSessionRepository{}
		}),
	}
	_ = db.BeginFunc(context.Background(), func(tx pgx.Tx) error {
		return repo.Tx(tx, func(repository SessionRepository) error {
			var id string
			id, err = repository.Get(context.Background(), "id")
			if err != nil {
				assert.FailNow(t, err.Error())
			}
			assert.Equal(t, "id", id)
			return nil
		})
	})
}

type SessionRepository interface {
	Transaction[SessionRepository]
	Get(ctx context.Context, id string) (string, error)
}

type SqlSessionRepository struct {
	*TxRepository[SessionRepository]
	db pgxtype.Querier
}

func (r *SqlSessionRepository) SetTx(tx pgx.Tx) {
	r.db = tx
}

func (r *SqlSessionRepository) Get(ctx context.Context, id string) (string, error) {
	var result string
	row := r.db.QueryRow(ctx, "select $1", id)
	if err := row.Scan(&result); err != nil {
		return "", err
	}

	return result, nil
}
