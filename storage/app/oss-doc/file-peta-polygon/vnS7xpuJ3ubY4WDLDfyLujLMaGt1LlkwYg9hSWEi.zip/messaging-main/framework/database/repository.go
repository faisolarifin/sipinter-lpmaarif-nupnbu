package database

import (
	"sync"

	"github.com/jackc/pgx/v5"
)

type TxSetter interface {
	SetTx(tx pgx.Tx)
}

type Transaction[T TxSetter] interface {
	TxSetter
	Tx(tx pgx.Tx, fn func(repository T) error) error
}

func NewTxRepository[T TxSetter](ctor func() any) *TxRepository[T] {
	return &TxRepository[T]{
		Pool: sync.Pool{
			New: ctor,
		},
	}
}

type TxRepository[T TxSetter] struct {
	Pool sync.Pool
}

func (r *TxRepository[T]) Tx(tx pgx.Tx, fn func(repository T) error) error {
	repository := r.Pool.Get().(T)
	repository.SetTx(tx)
	defer func() {
		repository.SetTx(nil)
		r.Pool.Put(repository)
	}()

	return fn(repository)
}
