package database

import "fmt"

type ErrorNotFound struct {
	message string
}

func NewErrorNotFound(format string, args ...any) *ErrorNotFound {
	return &ErrorNotFound{message: "no rows affected: " + fmt.Sprintf(format, args...)}
}

func (e *ErrorNotFound) Error() string {
	return e.message
}

type ErrorNoRowsAffected struct {
	message string
}

func NewErrorNoRowsAffected(format string, args ...any) *ErrorNoRowsAffected {
	return &ErrorNoRowsAffected{message: fmt.Sprintf(format, args...)}
}

func (e *ErrorNoRowsAffected) Error() string {
	return e.message
}
