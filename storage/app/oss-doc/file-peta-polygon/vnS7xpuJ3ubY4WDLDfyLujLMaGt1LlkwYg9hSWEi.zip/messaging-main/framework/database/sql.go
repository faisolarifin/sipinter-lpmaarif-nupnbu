package database

import (
	"bytes"
	"encoding/json"
	"fmt"
	"reflect"
)

const eof = rune(0)

func NamedQuery(query string, args map[string]any) (string, []any, error) {
	var (
		ch     rune
		tch    rune
		name   []rune
		ca     int
		values []any
	)

	reader := bytes.NewReader([]byte(query))
	writer := &bytes.Buffer{}
	for {
		ch = read(reader)
		if ch == eof {
			break
		}

		tch = peek(reader)
		if ch == ':' && isLetter(tch) {
			// named args
			for {
				ch = read(reader)
				if ch == eof {
					break
				}

				tch = peek(reader)
				if isLetterAndNumber(ch) || ch == '_' {
					name = append(name, ch)
				}

				if !isLetterAndNumber(tch) && tch != '_' {
					break
				}
			}

			value, ok := args[string(name)]
			if !ok {
				return "", nil, fmt.Errorf("undefined value arg `%s`", string(name))
			}

			vals := bindValues(value)
			for i := 0; i < len(vals); i++ {
				ca += 1
				values = append(values, vals[i])
				writer.WriteString(fmt.Sprintf("$%d", ca))
				if i < len(vals)-1 {
					writer.WriteString(", ")
				}
			}
			name = []rune{}
		} else if ch == ':' && tch == ':' {
			// sql
			writer.WriteRune(ch)
			for {
				ch = read(reader)
				if ch == eof {
					break
				}

				writer.WriteRune(ch)
				tch = peek(reader)
				if isWhitespace(ch) || tch == ',' || tch == '(' || tch == ')' {
					break
				}
			}
		} else {
			writer.WriteRune(ch)
		}
	}

	return writer.String(), values, nil
}

func bindValues(value any) []any {
	valueOf := reflect.ValueOf(value)
	switch valueOf.Kind() {
	case reflect.Slice:
		if valueOf.Len() < 1 {
			return []any{value}
		}

		switch value.(type) {
		case []byte, json.RawMessage:
			return []any{value}
		}

		result := make([]any, valueOf.Len())
		for i := 0; i < valueOf.Len(); i++ {
			result[i] = valueOf.Index(i).Interface()
		}

		return result
	}

	return []any{value}
}

// read return next rune or eof
func read(reader *bytes.Reader) rune {
	ch, _, err := reader.ReadRune()
	if err != nil {
		return eof
	}

	return ch
}

// peek
func peek(reader *bytes.Reader) rune {
	defer func(reader *bytes.Reader) {
		_ = reader.UnreadRune()
	}(reader)

	return read(reader)
}

// isWhitespace returns true if the rune is a space, tab, or newline.
func isWhitespace(ch rune) bool { return ch == ' ' || ch == '\t' || ch == '\n' }

// isLetter returns true if the rune is a letter.
func isLetter(ch rune) bool { return (ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z') }

// isNumber returns true if the rune is a number.
func isNumber(ch rune) bool { return ch >= '0' && ch <= '9' }

// isLetterAndNumber returns true if the rune is a letter.
func isLetterAndNumber(ch rune) bool {
	return (ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z') || ch >= '0' && ch <= '9'
}

func in(char rune, chars []rune) bool {
	for _, item := range chars {
		if char == item {
			return true
		}
	}

	return false
}

//var allowedBindRunes = []*unicode.RangeTable{unicode.Letter, unicode.Digit}
//
//func NamedQuery(sql string, args map[string]any) (query string, values []any, err error) {
//	var cast []byte
//	qs := []byte(sql)
//	rebound := make([]byte, 0, len(qs))
//
//	inName := false
//	last := len(qs) - 1
//	currentVar := 1
//	name := make([]byte, 0, 10)
//
//	for i := 0; i < len(qs); i++ {
//		b := qs[i]
//		if b == ':' {
//			if inName && i > 0 && qs[i-1] == ':' {
//				rebound = append(rebound, ':')
//				inName = false
//				continue
//			} else if inName {
//				skip := false
//				if i < last {
//					for j := i; j < len(qs); j++ {
//						b = qs[j]
//						if unicode.IsOneOf(allowedBindRunes, rune(b)) || b == ':' {
//							cast = append(cast, b)
//							i += 1
//						} else if b == ',' || unicode.IsSpace(rune(b)) {
//							cast = append(cast, b)
//							i += 1
//							skip = true
//							break
//						} else {
//							skip = true
//							break
//						}
//					}
//				}
//				if skip {
//					continue
//				}
//
//				err = errors.New("unexpected `:` while reading named param at " + strconv.Itoa(i))
//				return "", nil, err
//			}
//
//			inName = true
//			name = []byte{}
//		} else if inName && i > 0 && b == '=' && len(name) == 0 {
//			rebound = append(rebound, ':', '=')
//			inName = false
//			continue
//		} else if inName && (unicode.IsOneOf(allowedBindRunes, rune(b)) || b == '_' || b == '.') && i != last {
//			name = append(name, b)
//		} else if inName {
//			inName = false
//			if i == last && unicode.IsOneOf(allowedBindRunes, rune(b)) {
//				name = append(name, b)
//			}
//
//			value, ok := args[string(name)]
//			if !ok {
//				err = fmt.Errorf("arg %s value not found ", string(name))
//				return "", nil, err
//			}
//
//			vo := reflect.ValueOf(value)
//			switch vo.Kind() {
//			case reflect.Slice:
//				switch value.(type) {
//				case []byte, json.RawMessage:
//					rebound = append(rebound, '$')
//					for _, b := range strconv.Itoa(currentVar) {
//						rebound = append(rebound, byte(b))
//					}
//
//					if len(cast) > 0 {
//						rebound = append(rebound, cast...)
//					}
//
//					values = append(values, vo.Interface())
//					currentVar++
//				default:
//					if vo.Len() < 1 {
//						rebound = append(rebound, '$')
//						for _, b := range strconv.Itoa(currentVar) {
//							rebound = append(rebound, byte(b))
//						}
//
//						if len(cast) > 0 {
//							rebound = append(rebound, cast...)
//						}
//
//						values = append(values, vo.Interface())
//						currentVar++
//					} else {
//						for i := 0; i < vo.Len(); i++ {
//							rebound = append(rebound, '$')
//							for _, b := range strconv.Itoa(currentVar) {
//								rebound = append(rebound, byte(b))
//							}
//
//							if i < vo.Len()-1 {
//								rebound = append(rebound, ',')
//							}
//							values = append(values, vo.Index(i).Interface())
//							currentVar++
//						}
//
//						if len(cast) > 0 {
//							rebound = append(rebound, cast...)
//						}
//					}
//				}
//			default:
//				rebound = append(rebound, '$')
//				for _, b := range strconv.Itoa(currentVar) {
//					rebound = append(rebound, byte(b))
//				}
//
//				if len(cast) > 0 {
//					rebound = append(rebound, cast...)
//				}
//
//				values = append(values, vo.Interface())
//				currentVar++
//			}
//
//			if i != last {
//				rebound = append(rebound, b)
//			} else if !unicode.IsOneOf(allowedBindRunes, rune(b)) {
//				rebound = append(rebound, b)
//			}
//
//			if len(cast) > 0 {
//				cast = []byte{}
//			}
//		} else {
//			rebound = append(rebound, b)
//		}
//	}
//	//for i, b := range qs {
//	//	if b == ':' {
//	//		if inName && i > 0 && qs[i-1] == ':' {
//	//			rebound = append(rebound, ':')
//	//			inName = false
//	//			continue
//	//		} else if inName {
//	//			err = errors.New("unexpected `:` while reading named param at " + strconv.Itoa(i))
//	//			return "", nil, err
//	//		}
//	//
//	//		inName = true
//	//		name = []byte{}
//	//	} else if inName && i > 0 && b == '=' && len(name) == 0 {
//	//		rebound = append(rebound, ':', '=')
//	//		inName = false
//	//		continue
//	//	} else if inName && (unicode.IsOneOf(allowedBindRunes, rune(b)) || b == '_' || b == '.') && i != last {
//	//		name = append(name, b)
//	//	} else if inName {
//	//		inName = false
//	//		if i == last && unicode.IsOneOf(allowedBindRunes, rune(b)) {
//	//			name = append(name, b)
//	//		}
//	//
//	//		value, ok := args[string(name)]
//	//		if !ok {
//	//			err = fmt.Errorf("arg %s value not found ", string(name))
//	//			return "", nil, err
//	//		}
//	//
//	//		vo := reflect.ValueOf(value)
//	//		switch vo.Kind() {
//	//		case reflect.Slice:
//	//			if vo.Len() < 1 {
//	//				rebound = append(rebound, '$')
//	//				for _, b := range strconv.Itoa(currentVar) {
//	//					rebound = append(rebound, byte(b))
//	//				}
//	//				values = append(values, vo.Interface())
//	//				currentVar++
//	//			} else {
//	//				for i := 0; i < vo.Len(); i++ {
//	//					rebound = append(rebound, '$')
//	//					for _, b := range strconv.Itoa(currentVar) {
//	//						rebound = append(rebound, byte(b))
//	//					}
//	//					if i < vo.Len()-1 {
//	//						rebound = append(rebound, ',')
//	//					}
//	//					values = append(values, vo.Index(i).Interface())
//	//					currentVar++
//	//				}
//	//			}
//	//		default:
//	//			rebound = append(rebound, '$')
//	//			for _, b := range strconv.Itoa(currentVar) {
//	//				rebound = append(rebound, byte(b))
//	//			}
//	//			values = append(values, vo.Interface())
//	//			currentVar++
//	//		}
//	//
//	//		if i != last {
//	//			rebound = append(rebound, b)
//	//		} else if !unicode.IsOneOf(allowedBindRunes, rune(b)) {
//	//			rebound = append(rebound, b)
//	//		}
//	//	} else {
//	//		rebound = append(rebound, b)
//	//	}
//	//}
//
//	return string(rebound), values, err
//}
