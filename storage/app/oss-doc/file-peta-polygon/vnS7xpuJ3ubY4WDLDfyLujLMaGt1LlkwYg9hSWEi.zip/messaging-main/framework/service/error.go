package service

import "fmt"

type ErrorValidation struct {
	message string
}

func NewErrorValidation(format string, args ...any) *ErrorValidation {
	return &ErrorValidation{message: fmt.Sprintf(format, args...)}
}

func (e *ErrorValidation) Error() string {
	return e.message
}

type ErrorRetryable struct {
	message string
}

func NewErrorRetryable(format string, args ...any) *ErrorRetryable {
	return &ErrorRetryable{message: fmt.Sprintf(format, args...)}
}

func (e *ErrorRetryable) Error() string {
	return e.message
}
