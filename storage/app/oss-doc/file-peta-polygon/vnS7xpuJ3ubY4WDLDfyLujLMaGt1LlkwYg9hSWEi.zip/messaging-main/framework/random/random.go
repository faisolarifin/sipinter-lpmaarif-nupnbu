package random

import (
	"crypto/rand"
	"encoding/base32"
)

var encoding = base32.NewEncoding("ybndrfg8ejkmcpqxot1uwisza345h769")

func NewString(length int) string {
	data := make([]byte, 1+(length*5/8))
	_, _ = rand.Read(data)
	return encoding.EncodeToString(data)[:length]
}
