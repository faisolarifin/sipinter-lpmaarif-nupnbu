package sql

import (
	"context"

	"framework/database"
	"shared/entities"
	"shared/repositories/sql/queries"

	"github.com/jackc/pgx/v5"
	"github.com/pkg/errors"
)

type ApplicationRepository struct {
	db database.Querier
}

func NewApplicationRepository(db database.Querier) *ApplicationRepository {
	return &ApplicationRepository{
		db: db,
	}
}

func (r *ApplicationRepository) SetTx(tx pgx.Tx) {
	r.db = tx
}

func (r *ApplicationRepository) FindById(ctx context.Context, clientId, id string) (*entities.Application, error) {
	namedArgs := map[string]any{
		"client_id": clientId,
		"id":        id,
	}
	query, params, err := database.NamedQuery(queries.ApplicationRepositoryFindById, namedArgs)
	if err != nil {
		return nil, errors.WithMessage(err, "ApplicationRepository.FindById NamedQuery")
	}

	var client entities.Application
	row := r.db.QueryRow(ctx, query, params...)
	if err = r.scan(row, &client); err != nil {
		if err == pgx.ErrNoRows {
			return nil, errors.WithStack(entities.NewErrorApplicationNotFound("Application with id %s not found", id))
		}
		return nil, errors.WithMessage(err, "ApplicationRepository.FindById QueryRow")
	}

	return &client, nil
}

func (r *ApplicationRepository) FindDefault(ctx context.Context, clientId string) (*entities.Application, error) {
	namedArgs := map[string]any{
		"client_id": clientId,
	}
	query, params, err := database.NamedQuery(queries.ApplicationRepositoryFindDefault, namedArgs)
	if err != nil {
		return nil, errors.WithMessage(err, "ApplicationRepository.FindDefault NamedQuery")
	}

	var client entities.Application
	row := r.db.QueryRow(ctx, query, params...)
	if err = r.scan(row, &client); err != nil {
		if err == pgx.ErrNoRows {
			return nil, errors.WithStack(entities.NewErrorApplicationNotFound("Default application not found"))
		}
		return nil, errors.WithMessage(err, "ApplicationRepository.FindDefault QueryRow")
	}

	return &client, nil
}

func (r *ApplicationRepository) FindByApplicationId(ctx context.Context, clientId, applicationId string) (*entities.Application, error) {
	namedArgs := map[string]any{
		"client_id":      clientId,
		"application_id": applicationId,
	}
	query, params, err := database.NamedQuery(queries.ApplicationRepositoryFindByApplicationId, namedArgs)
	if err != nil {
		return nil, errors.WithMessage(err, "ApplicationRepository.FindByApplicationId NamedQuery")
	}

	var client entities.Application
	row := r.db.QueryRow(ctx, query, params...)
	if err = r.scan(row, &client); err != nil {
		if err == pgx.ErrNoRows {
			return nil, errors.WithStack(entities.NewErrorApplicationNotFound("Application with application id %s not found", applicationId))
		}
		return nil, errors.WithMessage(err, "ApplicationRepository.FindByApplicationId QueryRow")
	}

	return &client, nil
}

func (r *ApplicationRepository) ExistById(ctx context.Context, clientId, id string) error {
	namedArgs := map[string]any{
		"client_id": clientId,
		"id":        id,
	}
	query, params, err := database.NamedQuery(queries.ApplicationRepositoryExistsById, namedArgs)
	if err != nil {
		return errors.WithMessage(err, "ApplicationRepository.ExistById NamedQuery")
	}

	var exists bool
	row := r.db.QueryRow(ctx, query, params...)
	if err = row.Scan(&exists); err != nil {
		return errors.WithMessage(err, "ApplicationRepository.ExistById QueryRow")
	}

	if !exists {
		return errors.WithStack(entities.NewErrorApplicationNotFound("Application with id %s not found", id))
	}

	return nil
}

func (r *ApplicationRepository) scan(scanner database.RowScanner, application *entities.Application) error {
	return scanner.Scan(
		&application.Id,
		&application.ClientId,
		&application.ApplicationId,
		&application.Name,
		&application.Configuration,
		&application.IsDefault,
		&application.IsActive,
		&application.CreatedAt,
		&application.CreatedBy,
		&application.UpdatedAt,
		&application.UpdatedBy,
	)
}
