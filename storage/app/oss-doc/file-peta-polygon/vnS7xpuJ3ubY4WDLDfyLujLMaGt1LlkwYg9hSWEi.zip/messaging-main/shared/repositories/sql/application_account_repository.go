package sql

import (
	"context"

	"framework/database"
	"shared/entities"
	"shared/repositories/sql/queries"

	"github.com/jackc/pgx/v5"
	"github.com/pkg/errors"
)

type ApplicationAccountRepository struct {
	db database.Querier
}

func NewApplicationAccountRepository(db database.Querier) *ApplicationAccountRepository {
	return &ApplicationAccountRepository{
		db: db,
	}
}

func (r *ApplicationAccountRepository) GetByClient(ctx context.Context, clientId string) ([]*entities.ApplicationAccount, error) {
	namedArgs := map[string]any{
		"client_id": clientId,
	}
	query, params, err := database.NamedQuery(queries.ApplicationAccountRepositoryGetByClient, namedArgs)
	if err != nil {
		return nil, errors.WithMessage(err, "ApplicationAccountRepository.GetByClient NamedQuery")
	}

	rows, err := r.db.Query(ctx, query, params...)
	if err != nil {
		return nil, errors.WithMessage(err, "ApplicationAccountRepository.GetByClient Query")
	}
	defer rows.Close()

	applicationAccounts, err := r.scans(rows)
	if err != nil {
		return nil, errors.WithMessage(err, "ApplicationAccountRepository.GetByClient Scans")
	}

	return applicationAccounts, nil
}

func (r *ApplicationAccountRepository) GetByClientAndChannel(ctx context.Context, clientId, channelId string) ([]*entities.ApplicationAccount, error) {
	namedArgs := map[string]any{
		"channel_id": channelId,
		"client_id":  clientId,
	}
	query, params, err := database.NamedQuery(queries.ApplicationAccountRepositoryGetByClientAndChannel, namedArgs)
	if err != nil {
		return nil, errors.WithMessage(err, "ApplicationAccountRepository.GetByClientAndChannel NamedQuery")
	}

	rows, err := r.db.Query(ctx, query, params...)
	if err != nil {
		return nil, errors.WithMessage(err, "ApplicationAccountRepository.GetByClientAndChannel Query")
	}
	defer rows.Close()

	applicationAccounts, err := r.scans(rows)
	if err != nil {
		return nil, errors.WithMessage(err, "ApplicationAccountRepository.GetByClientAndChannel Scans")
	}

	return applicationAccounts, nil
}

func (r *ApplicationAccountRepository) FindByApplicationAndAccount(ctx context.Context, clientId, applicationId, accountId string) (*entities.ApplicationAccount, error) {
	namedArgs := map[string]any{
		"client_id":      clientId,
		"application_id": applicationId,
		"account_id":     accountId,
	}
	query, params, err := database.NamedQuery(queries.ApplicationAccountRepositoryFindByApplicationAndAccount, namedArgs)
	if err != nil {
		return nil, errors.WithMessage(err, "ApplicationAccountRepository.FindByApplicationAndAccount NamedQuery")
	}

	var client entities.ApplicationAccount
	row := r.db.QueryRow(ctx, query, params...)
	if err = r.scan(row, &client); err != nil {
		if err == pgx.ErrNoRows {
			return nil, errors.WithStack(entities.NewErrorApplicationAccountNotFound(
				"ApplicationAccount with application %s and id %s not found", applicationId, accountId))
		}
		return nil, errors.WithMessage(err, "ApplicationAccountRepository.FindByApplicationAndAccount QueryRow")
	}

	return &client, nil
}

func (r *ApplicationAccountRepository) FindByApplicationAndAccountAlias(ctx context.Context, clientId, applicationId, accountAlias string) (*entities.ApplicationAccount, error) {
	namedArgs := map[string]any{
		"client_id":      clientId,
		"application_id": applicationId,
		"account_alias":  accountAlias,
	}
	query, params, err := database.NamedQuery(queries.ApplicationAccountRepositoryFindByApplicationAndAccountAlias, namedArgs)
	if err != nil {
		return nil, errors.WithMessage(err, "ApplicationAccountRepository.FindByApplicationAndAccountAlias NamedQuery")
	}

	var client entities.ApplicationAccount
	row := r.db.QueryRow(ctx, query, params...)
	if err = r.scan(row, &client); err != nil {
		if err == pgx.ErrNoRows {
			return nil, errors.WithStack(entities.NewErrorApplicationAccountNotFound(
				"ApplicationAccount with application %s and alias %s not found", applicationId, accountAlias))
		}
		return nil, errors.WithMessage(err, "ApplicationAccountRepository.FindByApplicationAndAccountAlias QueryRow")
	}

	return &client, nil
}

func (r *ApplicationAccountRepository) ExistsApplicationAndAccount(ctx context.Context, clientId, applicationId, accountId string) error {
	namedArgs := map[string]any{
		"client_id":      clientId,
		"application_id": applicationId,
		"account_id":     accountId,
	}
	query, params, err := database.NamedQuery(queries.ApplicationAccountRepositoryExistsApplicationAndAccount, namedArgs)
	if err != nil {
		return errors.WithMessage(err, "ApplicationAccountRepository.ExistsApplicationAndAccount NamedQuery")
	}

	var exists bool
	row := r.db.QueryRow(ctx, query, params...)
	if err = row.Scan(&exists); err != nil {
		return errors.WithMessage(err, "ApplicationAccountRepository.ExistsApplicationAndAccount QueryRow")
	}

	if !exists {
		return errors.WithStack(entities.NewErrorApplicationAccountNotFound(
			"ApplicationAccount with application %s and id %s not found", applicationId, accountId))
	}

	return nil
}

func (r *ApplicationAccountRepository) ExistsApplicationAndAccountAlias(ctx context.Context, clientId, applicationId, accountAlias string) error {
	namedArgs := map[string]any{
		"client_id":      clientId,
		"application_id": applicationId,
		"account_alias":  accountAlias,
	}
	query, params, err := database.NamedQuery(queries.ApplicationAccountRepositoryExistsApplicationAndAccountAlias, namedArgs)
	if err != nil {
		return errors.WithMessage(err, "ApplicationAccountRepository.ExistsApplicationAndAccountAlias NamedQuery")
	}

	var exists bool
	row := r.db.QueryRow(ctx, query, params...)
	if err = row.Scan(&exists); err != nil {
		return errors.WithMessage(err, "ApplicationAccountRepository.ExistsApplicationAndAccountAlias QueryRow")
	}

	if !exists {
		return errors.WithStack(entities.NewErrorApplicationAccountNotFound(
			"ApplicationAccount with application %s and id %s not found", applicationId, accountAlias))
	}

	return nil
}

func (r *ApplicationAccountRepository) scan(scanner database.RowScanner, applicationAccount *entities.ApplicationAccount) error {
	return scanner.Scan(
		&applicationAccount.Id,
		&applicationAccount.ClientId,
		&applicationAccount.ChannelId,
		&applicationAccount.ClientApplicationId,
		&applicationAccount.ApplicationId,
		&applicationAccount.AccountId,
		&applicationAccount.AccountAlias,
		&applicationAccount.IsActive,
		&applicationAccount.CreatedAt,
		&applicationAccount.CreatedBy,
		&applicationAccount.UpdatedAt,
		&applicationAccount.UpdatedBy,
	)
}

func (r *ApplicationAccountRepository) scans(scanners database.RowsScanner) ([]*entities.ApplicationAccount, error) {
	var applicationAccounts []*entities.ApplicationAccount
	for scanners.Next() {
		applicationAccount := new(entities.ApplicationAccount)
		if err := r.scan(scanners, applicationAccount); err != nil {
			return nil, err
		}
		applicationAccounts = append(applicationAccounts, applicationAccount)
	}

	return applicationAccounts, nil
}
