package sql

import (
	"shared/repositories"

	"github.com/jackc/pgx/v5/pgxpool"
)

type RepositoryFactory struct {
	db *pgxpool.Pool
}

func NewRepositoryFactory(db *pgxpool.Pool) *RepositoryFactory {
	return &RepositoryFactory{db: db}
}

func (f *RepositoryFactory) NewAccountRepository() repositories.AccountRepository {
	return NewAccountRepository(f.db)
}

func (f *RepositoryFactory) NewAccountCountryRepository() repositories.AccountCountryRepository {
	return NewAccountCountryRepository(f.db)
}

func (f *RepositoryFactory) NewApplicationRepository() repositories.ApplicationRepository {
	return NewApplicationRepository(f.db)
}

func (f *RepositoryFactory) NewApplicationAccountRepository() repositories.ApplicationAccountRepository {
	return NewApplicationAccountRepository(f.db)
}

func (f *RepositoryFactory) NewClientRepository() repositories.ClientRepository {
	return NewClientRepository(f.db)
}
