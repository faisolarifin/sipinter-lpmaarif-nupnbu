package repositories

import (
	"context"
	"shared/entities"
)

type AccountCountryRepository interface {
	FindByAccountAndPrefix(ctx context.Context, accountId, prefix string) (*entities.AccountCountry, error)
	GetByAccountAndPrefixes(ctx context.Context, accountId string, prefixes []string) ([]*entities.AccountCountry, error)
}
