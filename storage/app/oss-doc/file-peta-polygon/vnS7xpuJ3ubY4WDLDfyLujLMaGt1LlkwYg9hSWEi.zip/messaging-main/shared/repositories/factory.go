package repositories

type RepositoryFactory interface {
	NewAccountRepository() AccountRepository
	NewAccountCountryRepository() AccountCountryRepository
	NewApplicationRepository() ApplicationRepository
	NewApplicationAccountRepository() ApplicationAccountRepository
	NewClientRepository() ClientRepository
}
