package queries

const (
	applicationRepositorySelect = `
		id,
		client_id,
		application_id,
		name,
		configuration,
		is_default,
		is_active,
		created_at,
		created_by,
		updated_at,
		updated_by
	`

	ApplicationRepositoryFindById = `
		select
			` + applicationRepositorySelect + `
		from public.client_applications
		where
			deleted_at is null
			and client_id = :client_id
			and id = :id
		limit 1
	`

	ApplicationRepositoryFindDefault = `
		select
			` + applicationRepositorySelect + `
		from public.client_applications
		where
			deleted_at is null
			and client_id = :client_id
			and is_default = true
		limit 1
	`

	ApplicationRepositoryFindByApplicationId = `
		select
			` + applicationRepositorySelect + `
		from public.client_applications
		where
			deleted_at is null
			and client_id = :client_id
			and application_id = :application_id
		limit 1
	`

	ApplicationRepositoryExistsById = `
		select
			count(*) > 0 as exists
		from public.client_applications
		where
			deleted_at is null
		  	and client_id = :client_id
			and id = :id
		limit 1
	`
)
