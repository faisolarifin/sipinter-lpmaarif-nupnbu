package queries

const (
	applicationAccountRepositorySelect = `
		ac.id,
		a.client_id,
		a.channel_id,
		ac.client_application_id,
		ca.application_id,
		ac.client_account_id,
		a.account_alias,
		ac.is_active,
		ac.created_at,
		ac.created_by,
		ac.updated_at,
		ac.updated_by
	`

	ApplicationAccountRepositoryGetByClient = `
		select
			` + applicationAccountRepositorySelect + `
		from public.client_application_accounts as ac
		left join public.client_accounts as a on ac.client_account_id = a.id
		left join public.client_applications as ca on ac.client_application_id = ca.id
		where
			ac.deleted_at is null
			and a.client_application_id is not null
			and a.client_id = :client_id
	`

	ApplicationAccountRepositoryGetByClientAndChannel = `
		select
			` + applicationAccountRepositorySelect + `
		from public.client_application_accounts as ac
		left join public.client_accounts as a on ac.client_account_id = a.id
		left join public.client_applications as ca on ac.client_application_id = ca.id
		where
			ac.deleted_at is null
			and a.client_application_id is not null
			and a.channel_id = :channel_id
			and a.client_id = :client_id
	`

	ApplicationAccountRepositoryFindByApplicationAndAccount = `
		select
			` + applicationAccountRepositorySelect + `
		from public.client_application_accounts as ac
		left join public.client_accounts as a on ac.client_account_id = a.id
		left join public.client_applications as ca on ac.client_application_id = ca.id
		where
			ac.deleted_at is null
			and a.client_id = :client_id
			and ac.client_application_id = :application_id
			and ac.client_account_id = :account_id
		limit 1
	`

	ApplicationAccountRepositoryFindByApplicationAndAccountAlias = `
		select
			` + applicationAccountRepositorySelect + `
		from public.client_application_accounts as ac
		left join public.client_accounts as a on ac.client_account_id = a.id
		left join public.client_applications as ca on ac.client_application_id = ca.id
		where
			ac.deleted_at is null
			and a.client_id = :client_id
			and ac.client_application_id = :application_id
			and a.account_alias = :account_alias
		limit 1
	`

	ApplicationAccountRepositoryExistsApplicationAndAccount = `
		select
			count(*) > 0 as exists
		from public.client_application_accounts as ac
		left join public.client_accounts as a on ac.client_account_id = a.id
		where
			ac.deleted_at is null
		  	and a.client_id = :client_id
			and ac.client_application_id = :application_id
			and ac.client_account_id = :account_id
		limit 1
	`

	ApplicationAccountRepositoryExistsApplicationAndAccountAlias = `
		select
			count(*) > 0 as exists
		from public.client_application_accounts as ac
		left join public.client_accounts as a on ac.client_account_id = a.id
		where
			ac.deleted_at is null
		  	and a.client_id = :client_id
			and ac.client_application_id = :application_id
			and ac.account_alias = :account_alias
		limit 1
	`
)
