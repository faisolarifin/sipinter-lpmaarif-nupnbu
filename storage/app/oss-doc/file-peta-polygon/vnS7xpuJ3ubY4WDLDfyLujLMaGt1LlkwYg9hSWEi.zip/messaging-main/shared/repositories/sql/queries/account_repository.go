package queries

const (
	accountRepositorySelect = `
		id,
		client_id,
		channel_id,
		channel_provider_id,
		account,
		account_title,
		account_alias,
		client_application_id,
		configuration,
		meta,
		allowed_to_other_country,
		allowed_to_all_other_country,
		is_active,
		created_at,
		created_by,
		updated_at,
		updated_by
	`

	AccountRepositoryGetAll = `
		select
			` + accountRepositorySelect + `
		from public.client_accounts
		where
			deleted_at is null
			and channel_id <> 'phone'
	`

	AccountRepositoryGetAllExceptChannels = `
		select
			` + accountRepositorySelect + `
		from public.client_accounts
		where
			deleted_at is null
			and not client_application_id is null 
			and channel_id not in(:channels)
	`

	AccountRepositoryGetByClient = `
		select
			` + accountRepositorySelect + `
		from public.client_accounts
		where
			deleted_at is null
			and client_application_id is not null
			and client_id = :client_id
	`

	AccountRepositoryGetByClientAndChannel = `
		select
			` + accountRepositorySelect + `
		from public.client_accounts
		where
			deleted_at is null
			and client_application_id is not null
			and channel_id = :channel_id
			and client_id = :client_id
	`

	AccountRepositoryFindByChannelAndAlias = `
		select
			` + accountRepositorySelect + `
		from public.client_accounts
		where
			deleted_at is null
			and client_id = :client_id
			and channel_id = :channel_id
			and account_alias = :account_alias
		limit 1
	`

	AccountRepositoryFindByChannelAndId = `
		select
			` + accountRepositorySelect + `
		from public.client_accounts
		where
			deleted_at is null
			and client_id = :client_id
			and channel_id = :channel_id
			and id = :id
		limit 1
	`

	AccountRepositoryExistByChannelAndAlias = `
		select
			count(*) > 0 as exists
		from public.client_accounts
		where
			deleted_at is null
		  	and client_id = :client_id
		  	and channel_id = :channel_id
			and account_alias = :account_alias
	`

	AccountRepositoryExistByChannelAndId = `
		select
			count(*) > 0 as exists
		from public.client_accounts
		where
			deleted_at is null
		  	and client_id = :client_id
		  	and channel_id = :channel_id
			and id = :id
	`
)
