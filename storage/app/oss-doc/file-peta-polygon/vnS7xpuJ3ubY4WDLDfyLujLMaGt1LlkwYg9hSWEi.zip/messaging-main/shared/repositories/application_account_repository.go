package repositories

import (
	"context"

	"shared/entities"
)

type ApplicationAccountRepository interface {
	GetByClient(ctx context.Context, clientId string) ([]*entities.ApplicationAccount, error)
	GetByClientAndChannel(ctx context.Context, clientId, channelId string) ([]*entities.ApplicationAccount, error)
	FindByApplicationAndAccount(ctx context.Context, clientId, applicationId, accountId string) (*entities.ApplicationAccount, error)
	FindByApplicationAndAccountAlias(ctx context.Context, clientId, applicationId, accountAlias string) (*entities.ApplicationAccount, error)
	ExistsApplicationAndAccount(ctx context.Context, clientId, applicationId, accountId string) error
	ExistsApplicationAndAccountAlias(ctx context.Context, clientId, applicationId, accountAlias string) error
}
