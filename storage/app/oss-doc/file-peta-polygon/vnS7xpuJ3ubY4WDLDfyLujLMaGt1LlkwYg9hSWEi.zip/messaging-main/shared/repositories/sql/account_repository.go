package sql

import (
	"context"
	"framework/database"
	"shared/entities"
	"shared/repositories/sql/queries"

	"github.com/jackc/pgx/v5"
	"github.com/pkg/errors"
)

type AccountRepository struct {
	db database.Querier
}

func NewAccountRepository(db database.Querier) *AccountRepository {
	return &AccountRepository{
		db: db,
	}
}

func (r *AccountRepository) GetAll(ctx context.Context) ([]*entities.Account, error) {
	rows, err := r.db.Query(ctx, queries.AccountRepositoryGetAll)
	if err != nil {
		return nil, errors.WithMessage(err, "AccountRepository.GetAll Query")
	}
	defer rows.Close()

	accounts, err := r.scans(rows)
	if err != nil {
		return nil, errors.WithMessage(err, "AccountRepository.GetAll Scans")
	}

	return accounts, nil
}

func (r *AccountRepository) GetAllExceptChannels(ctx context.Context, channels []string) ([]*entities.Account, error) {
	namedArgs := map[string]any{
		"channels": channels,
	}
	query, params, err := database.NamedQuery(queries.AccountRepositoryGetAllExceptChannels, namedArgs)
	if err != nil {
		return nil, errors.WithMessage(err, "AccountRepository.GetAllExceptChannels NamedQuery")
	}

	rows, err := r.db.Query(ctx, query, params...)
	if err != nil {
		return nil, errors.WithMessage(err, "AccountRepository.GetAllExceptChannels Query")
	}
	defer rows.Close()

	accounts, err := r.scans(rows)
	if err != nil {
		return nil, errors.WithMessage(err, "AccountRepository.GetAllExceptChannels Scans")
	}

	return accounts, nil
}

func (r *AccountRepository) GetByClient(ctx context.Context, clientId string) ([]*entities.Account, error) {
	namedArgs := map[string]any{
		"client_id": clientId,
	}
	query, params, err := database.NamedQuery(queries.AccountRepositoryGetByClient, namedArgs)
	if err != nil {
		return nil, errors.WithMessage(err, "AccountRepository.GetByClient NamedQuery")
	}

	rows, err := r.db.Query(ctx, query, params...)
	if err != nil {
		return nil, errors.WithMessage(err, "AccountRepository.GetByClient Query")
	}
	defer rows.Close()

	accounts, err := r.scans(rows)
	if err != nil {
		return nil, errors.WithMessage(err, "AccountRepository.GetByClient Scans")
	}

	return accounts, nil
}

func (r *AccountRepository) GetByClientAndChannel(ctx context.Context, clientId, channelId string) ([]*entities.Account, error) {
	namedArgs := map[string]any{
		"client_id":  clientId,
		"channel_id": channelId,
	}
	query, params, err := database.NamedQuery(queries.AccountRepositoryGetByClientAndChannel, namedArgs)
	if err != nil {
		return nil, errors.WithMessage(err, "AccountRepository.GetByClientAndChannel NamedQuery")
	}

	rows, err := r.db.Query(ctx, query, params...)
	if err != nil {
		return nil, errors.WithMessage(err, "AccountRepository.GetByClientAndChannel Query")
	}
	defer rows.Close()

	accounts, err := r.scans(rows)
	if err != nil {
		return nil, errors.WithMessage(err, "AccountRepository.GetByClientAndChannel Scans")
	}

	return accounts, nil
}

func (r *AccountRepository) FindByChannelAndAlias(ctx context.Context, clientId, channelId, alias string) (*entities.Account, error) {
	namedArgs := map[string]any{
		"client_id":     clientId,
		"channel_id":    channelId,
		"account_alias": alias,
	}
	query, params, err := database.NamedQuery(queries.AccountRepositoryFindByChannelAndAlias, namedArgs)
	if err != nil {
		return nil, errors.WithMessage(err, "AccountRepository.FindByChannelAndAlias NamedQuery")
	}

	var account entities.Account
	row := r.db.QueryRow(ctx, query, params...)
	if err = r.scan(row, &account); err != nil {
		if err == pgx.ErrNoRows {
			return nil, errors.WithStack(entities.NewErrorAccountNotFound(
				"Account with client '%s', channel '%s' and alias '%s' not found", clientId, channelId, alias))
		}
		return nil, errors.WithMessage(err, "AccountRepository.FindByChannelAndAlias QueryRow")
	}

	return &account, nil
}

func (r *AccountRepository) FindByChannelAndId(ctx context.Context, clientId, channelId, id string) (*entities.Account, error) {
	namedArgs := map[string]any{
		"client_id":  clientId,
		"channel_id": channelId,
		"id":         id,
	}
	query, params, err := database.NamedQuery(queries.AccountRepositoryFindByChannelAndId, namedArgs)
	if err != nil {
		return nil, errors.WithMessage(err, "AccountRepository.FindByChannelAndId NamedQuery")
	}
	var account entities.Account
	row := r.db.QueryRow(ctx, query, params...)
	if err = r.scan(row, &account); err != nil {
		if err == pgx.ErrNoRows {
			return nil, errors.WithStack(entities.NewErrorAccountNotFound(
				"Account with client '%s', channel '%s' and id '%s' not found", clientId, channelId, id))
		}
		return nil, errors.WithMessage(err, "AccountRepository.FindByChannelAndId QueryRow")
	}

	return &account, nil
}

func (r *AccountRepository) ExistByChannelAndAlias(ctx context.Context, clientId, channelId, alias string) error {
	namedArgs := map[string]any{
		"client_id":     clientId,
		"channel_id":    channelId,
		"account_alias": alias,
	}
	query, params, err := database.NamedQuery(queries.AccountRepositoryExistByChannelAndAlias, namedArgs)
	if err != nil {
		return errors.WithMessage(err, "AccountRepository.ExistByChannelAndAlias NamedQuery")
	}

	var exists bool
	row := r.db.QueryRow(ctx, query, params...)
	if err = row.Scan(&exists); err != nil {
		return errors.WithMessage(err, "AccountRepository.ExistByChannelAndAlias QueryRow")
	}

	if !exists {
		return errors.WithStack(entities.NewErrorAccountNotFound(
			"Account with channel %s and alias %s not found", channelId, alias))
	}

	return nil
}

func (r *AccountRepository) ExistByChannelAndId(ctx context.Context, clientId, channelId, id string) error {
	namedArgs := map[string]any{
		"client_id":  clientId,
		"channel_id": channelId,
		"id":         id,
	}
	query, params, err := database.NamedQuery(queries.AccountRepositoryExistByChannelAndId, namedArgs)
	if err != nil {
		return errors.WithMessage(err, "AccountRepository.ExistByChannelAndId NamedQuery")
	}

	var exists bool
	row := r.db.QueryRow(ctx, query, params...)
	if err = row.Scan(&exists); err != nil {
		return errors.WithMessage(err, "AccountRepository.ExistByChannelAndId QueryRow")
	}

	if !exists {
		return errors.WithStack(entities.NewErrorAccountNotFound(
			"Account with channel %s and id %s not found", channelId, id))
	}

	return nil
}

func (r *AccountRepository) scan(scanner database.RowScanner, account *entities.Account) error {
	return scanner.Scan(
		&account.Id,
		&account.ClientId,
		&account.ChannelId,
		&account.ChannelProviderId,
		&account.Account,
		&account.AccountTitle,
		&account.AccountAlias,
		&account.ApplicationId,
		&account.Configuration,
		&account.Meta,
		&account.AllowedToOtherCountry,
		&account.AllowedToAllOtherCountry,
		&account.IsActive,
		&account.CreatedAt,
		&account.CreatedBy,
		&account.UpdatedAt,
		&account.UpdatedBy,
	)
}

func (r *AccountRepository) scans(scanners database.RowsScanner) ([]*entities.Account, error) {
	var accounts []*entities.Account
	for scanners.Next() {
		account := new(entities.Account)
		if err := r.scan(scanners, account); err != nil {
			return nil, err
		}
		accounts = append(accounts, account)
	}

	return accounts, nil
}
