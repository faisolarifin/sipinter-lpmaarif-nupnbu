package sql

import (
	"context"

	"framework/database"
	"shared/entities"
	"shared/repositories/sql/queries"

	"github.com/jackc/pgx/v5"
	"github.com/pkg/errors"
)

type ClientRepository struct {
	db database.Querier
}

func NewClientRepository(db database.Querier) *ClientRepository {
	return &ClientRepository{
		db: db,
	}
}

func (r *ClientRepository) SetTx(tx pgx.Tx) {
	r.db = tx
}

func (r *ClientRepository) GetAll(ctx context.Context) ([]*entities.Client, error) {
	rows, err := r.db.Query(ctx, queries.ClientRepositoryGetAll)
	if err != nil {
		return nil, errors.WithMessage(err, "ClientRepository.GetAll Query")
	}
	defer rows.Close()

	clients, err := r.scans(rows)
	if err != nil {
		return nil, errors.WithMessage(err, "ClientRepository.GetAll Scans")
	}

	return clients, nil
}

func (r *ClientRepository) FindById(ctx context.Context, id string) (*entities.Client, error) {
	namedArgs := map[string]any{
		"id": id,
	}
	query, params, err := database.NamedQuery(queries.ClientRepositoryFindById, namedArgs)
	if err != nil {
		return nil, errors.WithMessage(err, "ClientRepository.FindById NamedQuery")
	}

	var client entities.Client
	row := r.db.QueryRow(ctx, query, params...)
	if err = r.scan(row, &client); err != nil {
		if err == pgx.ErrNoRows {
			return nil, errors.WithStack(entities.NewErrorClientNotFound("Client with id %s not found", id))
		}
		return nil, errors.WithMessage(err, "ClientRepository.FindById QueryRow")
	}

	return &client, nil
}

func (r *ClientRepository) ExistById(ctx context.Context, id string) error {
	namedArgs := map[string]any{
		"id": id,
	}
	query, params, err := database.NamedQuery(queries.ClientRepositoryExistsById, namedArgs)
	if err != nil {
		return errors.WithMessage(err, "ClientRepository.ExistById NamedQuery")
	}

	var exists bool
	row := r.db.QueryRow(ctx, query, params...)
	if err = row.Scan(&exists); err != nil {
		return errors.WithMessage(err, "ClientRepository.ExistById QueryRow")
	}

	if !exists {
		return errors.WithStack(entities.NewErrorClientNotFound("Client with id %s not found", id))
	}

	return nil
}

func (r *ClientRepository) scan(scanner database.RowScanner, client *entities.Client) error {
	return scanner.Scan(
		&client.Id,
		&client.Name,
		&client.DisplayName,
		&client.Website,
		&client.Icon,
		&client.Avatar,
		&client.Configuration,
		&client.CreatedAt,
		&client.CreatedBy,
		&client.UpdatedAt,
		&client.UpdatedBy,
	)
}

func (r *ClientRepository) scans(scanners database.RowsScanner) ([]*entities.Client, error) {
	var clients []*entities.Client
	for scanners.Next() {
		client := new(entities.Client)
		if err := r.scan(scanners, client); err != nil {
			return nil, err
		}
		clients = append(clients, client)
	}

	return clients, nil
}
