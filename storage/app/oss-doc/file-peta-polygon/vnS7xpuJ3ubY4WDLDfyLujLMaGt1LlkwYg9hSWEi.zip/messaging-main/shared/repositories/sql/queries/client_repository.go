package queries

const (
	clientRepositorySelect = `
		id,
		name,
		display_name,
		website,
		icon,
		avatar,
		configuration,
		created_at,
		created_by,
		updated_at,
		updated_by
	`

	ClientRepositoryGetAll = `
		select
			` + clientRepositorySelect + `
		from public.clients
		where
			deleted_at is null
	`

	ClientRepositoryFindById = `
		select
			` + clientRepositorySelect + `
		from public.clients
		where
			deleted_at is null
			and id = :id
		limit 1
	`

	ClientRepositoryExistsById = `
		select
			count(id) > 0 as exists
		from public.clients
		where
			deleted_at is null
			and id = :id
		limit 1
	`
)
