package repositories

import (
	"context"

	"shared/entities"
)

type AccountRepository interface {
	GetAll(ctx context.Context) ([]*entities.Account, error)
	GetAllExceptChannels(ctx context.Context, channels []string) ([]*entities.Account, error)
	GetByClient(ctx context.Context, clientId string) ([]*entities.Account, error)
	GetByClientAndChannel(ctx context.Context, clientId, channelId string) ([]*entities.Account, error)
	FindByChannelAndAlias(ctx context.Context, clientId, channelId, alias string) (*entities.Account, error)
	FindByChannelAndId(ctx context.Context, clientId, channelId, id string) (*entities.Account, error)
	ExistByChannelAndAlias(ctx context.Context, clientId, channelId, alias string) error
	ExistByChannelAndId(ctx context.Context, clientId, channelId, id string) error
}
