package queries

const (
	AccountCountryRepositoryFindByAccountIdAndPrefix = `
		select
			id,
			client_account_id,
			prefix
		from public.client_account_countries
		where
			deleted_at is null
			and client_account_id = :client_account_id
			and prefix = :prefix		
	`

	AccountCountryRepositoryFindByAccountIdAndPrefixes = `
		select
			id,
			client_account_id,
			prefix
		from public.client_account_countries
		where
			deleted_at is null
			and client_account_id = :client_account_id
			and prefix in(:prefix) 		
	`
)
