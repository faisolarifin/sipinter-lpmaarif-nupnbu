package repositories

import (
	"context"

	"shared/entities"
)

type ApplicationRepository interface {
	FindById(ctx context.Context, clientId, id string) (*entities.Application, error)
	FindDefault(ctx context.Context, clientId string) (*entities.Application, error)
	FindByApplicationId(ctx context.Context, clientId, applicationId string) (*entities.Application, error)
	ExistById(ctx context.Context, clientId, id string) error
}
