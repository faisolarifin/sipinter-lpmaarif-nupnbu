package repositories

import (
	"context"

	"shared/entities"
)

type ClientRepository interface {
	GetAll(ctx context.Context) ([]*entities.Client, error)
	FindById(ctx context.Context, id string) (*entities.Client, error)
	ExistById(ctx context.Context, id string) error
}
