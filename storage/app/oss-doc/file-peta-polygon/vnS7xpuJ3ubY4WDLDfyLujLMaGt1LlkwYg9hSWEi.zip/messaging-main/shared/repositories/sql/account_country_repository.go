package sql

import (
	"context"
	"framework/database"
	"shared/entities"
	"shared/repositories/sql/queries"

	"github.com/jackc/pgx/v5"
	"github.com/pkg/errors"
)

type AccountCountryRepository struct {
	db database.Querier
}

func NewAccountCountryRepository(db database.Querier) *AccountCountryRepository {
	return &AccountCountryRepository{db: db}
}

func (r *AccountCountryRepository) FindByAccountAndPrefix(ctx context.Context, accountId, prefix string) (*entities.AccountCountry, error) {
	namedArgs := map[string]any{
		"client_account_id": accountId,
		"prefix":            prefix,
	}
	query, params, err := database.NamedQuery(queries.AccountCountryRepositoryFindByAccountIdAndPrefix, namedArgs)
	if err != nil {
		return nil, errors.WithMessage(err, "AccountCountryRepository.FindByAccountAndPrefix NamedQuery")
	}
	var accountCountry entities.AccountCountry
	row := r.db.QueryRow(ctx, query, params...)
	if err = r.scan(row, &accountCountry); err != nil {
		if err == pgx.ErrNoRows {
			return nil, errors.WithStack(entities.NewErrorAccountCountryNotFound(
				"Account country with client account id '%s' and prefix '%s' not found", accountId, prefix))
		}
		return nil, errors.WithMessage(err, "AccountCountryRepository.FindByAccountAndPrefix QueryRow")
	}

	return &accountCountry, nil
}

func (r *AccountCountryRepository) GetByAccountAndPrefixes(ctx context.Context, accountId string, prefixes []string) ([]*entities.AccountCountry, error) {
	namedArgs := map[string]any{
		"client_account_id": accountId,
		"prefix":            prefixes,
	}
	query, params, err := database.NamedQuery(queries.AccountCountryRepositoryFindByAccountIdAndPrefixes, namedArgs)
	if err != nil {
		return nil, errors.WithMessage(err, "AccountCountryRepository.GetByAccountAndPrefixes NamedQuery")
	}

	rows, err := r.db.Query(ctx, query, params...)
	if err != nil {
		return nil, errors.WithMessage(err, "AccountCountryRepository.GetByAccountAndPrefixes Query")
	}
	defer rows.Close()

	accountCountries, err := r.scans(rows)
	if err != nil {
		return nil, errors.WithMessage(err, "AccountCountryRepository.GetByAccountAndPrefixes Scans")
	}

	return accountCountries, nil
}

func (r *AccountCountryRepository) scan(scanner database.RowScanner, accountCountry *entities.AccountCountry) error {
	return scanner.Scan(
		&accountCountry.Id,
		&accountCountry.AccountId,
		&accountCountry.Prefix,
	)
}

func (r *AccountCountryRepository) scans(scanners database.RowsScanner) ([]*entities.AccountCountry, error) {
	var accountCountries []*entities.AccountCountry
	for scanners.Next() {
		accountCountry := new(entities.AccountCountry)
		if err := r.scan(scanners, accountCountry); err != nil {
			return nil, err
		}
		accountCountries = append(accountCountries, accountCountry)
	}

	return accountCountries, nil
}
