package entities

import (
	"encoding/json"
	"fmt"
	"time"
)

type Account struct {
	Id                       string
	ClientId                 string
	ChannelId                string
	ChannelProviderId        *string
	Account                  string
	AccountTitle             string
	AccountAlias             string
	ApplicationId            *string
	Configuration            json.RawMessage
	Meta                     json.RawMessage
	AllowedToOtherCountry    bool
	AllowedToAllOtherCountry bool
	IsActive                 bool
	CreatedAt                *time.Time
	CreatedBy                *string
	UpdatedAt                *time.Time
	UpdatedBy                *string
}

type ErrorAccountNotFound struct {
	message string
}

func NewErrorAccountNotFound(format string, args ...any) *ErrorAccountNotFound {
	return &ErrorAccountNotFound{message: fmt.Sprintf(format, args...)}
}

func (e *ErrorAccountNotFound) Error() string {
	return e.message
}

type ErrorAccountInActive struct {
	message string
}

func NewErrorAccountInActive(format string, args ...any) *ErrorAccountInActive {
	return &ErrorAccountInActive{message: fmt.Sprintf(format, args...)}
}

func (e *ErrorAccountInActive) Error() string {
	return e.message
}
