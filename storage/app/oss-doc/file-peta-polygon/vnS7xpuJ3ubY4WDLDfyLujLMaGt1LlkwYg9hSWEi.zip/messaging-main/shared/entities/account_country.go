package entities

import "fmt"

type AccountCountry struct {
	Id        string
	AccountId string
	Prefix    string
}

type ErrorAccountCountryNotFound struct {
	message string
}

func NewErrorAccountCountryNotFound(format string, args ...any) *ErrorAccountCountryNotFound {
	return &ErrorAccountCountryNotFound{message: fmt.Sprintf(format, args...)}
}

func (e *ErrorAccountCountryNotFound) Error() string {
	return e.message
}
