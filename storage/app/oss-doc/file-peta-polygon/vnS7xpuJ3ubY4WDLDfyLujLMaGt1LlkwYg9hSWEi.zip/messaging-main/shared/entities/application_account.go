package entities

import (
	"fmt"
	"time"
)

type ApplicationAccount struct {
	Id                  string
	ClientId            string
	ChannelId           string
	ClientApplicationId string
	ApplicationId       string
	AccountId           string
	AccountAlias        string
	IsActive            bool
	CreatedAt           *time.Time
	CreatedBy           *string
	UpdatedAt           *time.Time
	UpdatedBy           *string
}

type ErrorApplicationAccountNotFound struct {
	message string
}

func NewErrorApplicationAccountNotFound(format string, args ...any) *ErrorApplicationAccountNotFound {
	return &ErrorApplicationAccountNotFound{message: fmt.Sprintf(format, args...)}
}

func (e *ErrorApplicationAccountNotFound) Error() string {
	return e.message
}
