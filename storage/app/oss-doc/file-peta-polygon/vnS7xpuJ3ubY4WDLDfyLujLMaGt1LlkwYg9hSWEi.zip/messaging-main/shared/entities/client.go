package entities

import (
	"encoding/json"
	"fmt"
	"time"
)

type Client struct {
	Id            string
	Name          string
	DisplayName   string
	Website       *string
	Icon          *string
	Avatar        *string
	Configuration json.RawMessage
	CreatedAt     *time.Time
	CreatedBy     *string
	UpdatedAt     *time.Time
	UpdatedBy     *string
}

type ErrorClientNotFound struct {
	Message string
}

func NewErrorClientNotFound(format string, args ...any) *ErrorClientNotFound {
	return &ErrorClientNotFound{Message: fmt.Sprintf(format, args...)}
}

func (e *ErrorClientNotFound) Error() string {
	return e.Message
}
