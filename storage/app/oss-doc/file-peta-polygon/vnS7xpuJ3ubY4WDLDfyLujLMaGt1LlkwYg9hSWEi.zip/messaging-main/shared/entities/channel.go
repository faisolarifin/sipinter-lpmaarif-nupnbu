package entities

import (
	"fmt"
	"strings"

	"framework/list"
)

const (
	ChannelUnknown       Channel = "unknown"
	ChannelEmail         Channel = "email"
	ChannelWhatsApp      Channel = "whatsapp"
	ChannelWhatsAppCloud Channel = "whatsapp-cloud"
	ChannelInstagram     Channel = "instagram"
	ChannelSMS           Channel = "sms"
)

var (
	ChannelList = []Channel{
		ChannelEmail,
		ChannelWhatsApp,
		ChannelWhatsAppCloud,
		ChannelInstagram,
		ChannelSMS,
	}

	ChannelListString = list.Map(ChannelList, func(item Channel) string {
		return item.String()
	})
)

type Channel string

func NewChannel(arg string) Channel {
	switch {
	case strings.EqualFold(arg, ChannelEmail.String()):
		return ChannelEmail
	case strings.EqualFold(arg, ChannelWhatsApp.String()):
		return ChannelWhatsApp
	case strings.EqualFold(arg, ChannelWhatsAppCloud.String()):
		return ChannelWhatsAppCloud
	case strings.EqualFold(arg, ChannelInstagram.String()):
		return ChannelInstagram
	case strings.EqualFold(arg, ChannelSMS.String()):
		return ChannelSMS
	}
	return ChannelUnknown
}

func (t Channel) IsValid() bool {
	return list.In(t, ChannelList)
}

func (t Channel) String() string {
	return string(t)
}

func IsChannelValid(channel string) error {
	if !list.In(channel, ChannelListString) {
		return NewErrorChannelInvalid("invalid channel want %s got %s", ChannelListString, channel)
	}

	return nil
}

type ErrorChannelInvalid struct {
	message string
}

func NewErrorChannelInvalid(format string, args ...any) *ErrorChannelInvalid {
	return &ErrorChannelInvalid{message: fmt.Sprintf(format, args...)}
}

func (e *ErrorChannelInvalid) Error() string {
	return e.message
}
