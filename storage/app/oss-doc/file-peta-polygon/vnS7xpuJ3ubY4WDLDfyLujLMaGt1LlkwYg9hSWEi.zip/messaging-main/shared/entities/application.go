package entities

import (
	"encoding/json"
	"fmt"
	"time"
)

type Application struct {
	Id            string
	ClientId      string
	ApplicationId string
	ServiceId     string
	Name          string
	Configuration json.RawMessage
	IsDefault     bool
	IsActive      bool
	CreatedAt     *time.Time
	CreatedBy     *string
	UpdatedAt     *time.Time
	UpdatedBy     *string
}

type ErrorApplicationNotFound struct {
	message string
}

func NewErrorApplicationNotFound(format string, args ...any) *ErrorApplicationNotFound {
	return &ErrorApplicationNotFound{message: fmt.Sprintf(format, args...)}
}

func (e *ErrorApplicationNotFound) Error() string {
	return e.message
}
