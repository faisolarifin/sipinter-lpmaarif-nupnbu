package entities

import "strings"

type StatusType string

const (
	StatusTypeUnknown   StatusType = "unknown"
	StatusTypeSent      StatusType = "sent"
	StatusTypeDelivered StatusType = "delivered"
	StatusTypeRead      StatusType = "read"
	StatusTypeFailed    StatusType = "failed"
	StatusTypeDeleted   StatusType = "deleted"
	StatusTypeError     StatusType = "error"
)

func (t StatusType) String() string {
	return string(t)
}

func NewStatusType(arg string) StatusType {
	switch {
	case strings.EqualFold(arg, StatusTypeSent.String()):
		return StatusTypeSent
	case strings.EqualFold(arg, StatusTypeDelivered.String()):
		return StatusTypeDelivered
	case strings.EqualFold(arg, StatusTypeRead.String()):
		return StatusTypeRead
	case strings.EqualFold(arg, StatusTypeFailed.String()):
		return StatusTypeFailed
	case strings.EqualFold(arg, StatusTypeDeleted.String()):
		return StatusTypeDeleted
	case strings.EqualFold(arg, StatusTypeError.String()):
		return StatusTypeError
	}

	return StatusTypeUnknown
}
