package repositories

import (
	"context"
	"core/entities"
)

type WhatsAppSessionRepository interface {
	CreateOrUpdate(ctx context.Context, channelId string, args *entities.CreateOrUpdateWhatsAppSession) error
}
