package repositories

import (
	"context"

	"core/entities"
)

type RouteRepository interface {
	Create(ctx context.Context, args *entities.RouteCreate) (*entities.Route, error)
}
