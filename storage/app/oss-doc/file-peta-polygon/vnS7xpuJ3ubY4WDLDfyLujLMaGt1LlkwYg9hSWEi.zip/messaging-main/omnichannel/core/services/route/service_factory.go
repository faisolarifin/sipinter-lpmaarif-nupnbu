package route

import (
	corerepositories "core/repositories"
	"framework/messaging"
	sharedrepositories "shared/repositories"

	"github.com/sirupsen/logrus"
)

func NewServiceFactory(
	sharedRepositoryFactory sharedrepositories.RepositoryFactory,
	coreRepositoryFactory corerepositories.RepositoryFactory,
	amqpMessagingFactory messaging.AMQPFactory,
	logger *logrus.Logger,
) *ServiceFactory {
	return &ServiceFactory{
		sharedRepositoryFactory: sharedRepositoryFactory,
		coreRepositoryFactory:   coreRepositoryFactory,
		amqpMessagingFactory:    amqpMessagingFactory,
		logger:                  logger,
	}
}

type ServiceFactory struct {
	sharedRepositoryFactory sharedrepositories.RepositoryFactory
	coreRepositoryFactory   corerepositories.RepositoryFactory
	amqpMessagingFactory    messaging.AMQPFactory
	logger                  *logrus.Logger
}

func (f *ServiceFactory) NewService() *Service {
	return NewService(
		f.sharedRepositoryFactory.NewClientRepository(),
		f.sharedRepositoryFactory.NewAccountRepository(),
		f.sharedRepositoryFactory.NewApplicationRepository(),
		f.sharedRepositoryFactory.NewApplicationAccountRepository(),
		f.coreRepositoryFactory.NewRouteRepository(),
		f.coreRepositoryFactory.NewSessionRepository(),
		f.amqpMessagingFactory.NewAMQPPublisher(),
		f.logger,
	)
}
