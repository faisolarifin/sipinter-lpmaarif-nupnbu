package entities

import (
	"fmt"
	"time"
)

type Session struct {
	Id                  string
	ClientId            string
	ChannelId           string
	AccountId           string
	ClientApplicationId string
	ApplicationId       string
	Sender              string
	ExpiredAt           *time.Time
	CreatedAt           time.Time
	UpdatedAt           *time.Time
}

type SessionCreate struct {
	ClientId      string
	ChannelId     string
	AccountAlias  string
	ApplicationId string
	Sender        string
	CreatedAt     time.Time
}

func (e *SessionCreate) ToMap() map[string]any {
	if e == nil {
		return nil
	}
	return map[string]any{
		"ClientId":      e.ClientId,
		"ChannelId":     e.ChannelId,
		"AccountAlias":  e.AccountAlias,
		"ApplicationId": e.ApplicationId,
		"Sender":        e.Sender,
		"CreatedAt":     e.CreatedAt,
	}
}

type SessionUpdate struct {
	ClientId      string
	ChannelId     string
	AccountAlias  string
	ApplicationId string
	Sender        string
	UpdatedAt     time.Time
}

func (e *SessionUpdate) ToMap() map[string]any {
	if e == nil {
		return nil
	}
	return map[string]any{
		"ClientId":      e.ClientId,
		"ChannelId":     e.ChannelId,
		"AccountAlias":  e.AccountAlias,
		"ApplicationId": e.ApplicationId,
		"Sender":        e.Sender,
		"UpdatedAt":     e.UpdatedAt,
	}
}

type ErrorSessionNotFound struct {
	message string
}

func NewErrorSessionNotFound(format string, args ...any) *ErrorSessionNotFound {
	return &ErrorSessionNotFound{message: fmt.Sprintf(format, args...)}
}

func (e *ErrorSessionNotFound) Error() string {
	return e.message
}
