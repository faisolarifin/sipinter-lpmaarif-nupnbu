package main

import (
	"context"
	"fmt"
	"framework/amqpx"
	amqp "github.com/rabbitmq/amqp091-go"
	"os"
	"os/signal"
	"sync"
	"sync/atomic"
)

type entry struct {
	conn     *amqpx.Connection
	channels []*amqpx.Channel
}

type Pool struct {
	url     string
	size    int
	index   int
	closed  int32
	rwMtx   sync.RWMutex
	entries map[int]*entry
	ctor    func() (*amqpx.Connection, error)
}

func New(url string, size int) *Pool {
	return &Pool{
		url:     url,
		size:    size,
		index:   -1,
		rwMtx:   sync.RWMutex{},
		entries: map[int]*entry{},
		ctor: func() (*amqpx.Connection, error) {
			return amqpx.Dial(url)
		},
	}
}

func (p *Pool) Channel() (*amqpx.Channel, error) {
	defer p.rwMtx.Unlock()
	p.rwMtx.Lock()

	_, ok := p.entries[p.index]
	if !ok {
		fmt.Println("entry not found create new connection")
		conn, err := p.ctor()
		if err != nil {
			return nil, err
		}

		p.index += 1
		p.entries[p.index] = &entry{conn: conn}
	}

	if len(p.entries[p.index].channels)+1 > p.size {
		fmt.Println("entry count reach limit")
		conn, err := p.ctor()
		if err != nil {
			return nil, err
		}

		p.index += 1
		p.entries[p.index] = &entry{conn: conn}
	}

	channel, err := p.entries[p.index].conn.Channel()
	if err != nil {
		return nil, err
	}
	p.entries[p.index].channels = append(p.entries[p.index].channels, channel)
	fmt.Println("entry index: ", p.index, "entry count: ", len(p.entries[p.index].channels))

	return channel, nil
}

func (p *Pool) Close() {
	if !atomic.CompareAndSwapInt32(&p.closed, 0, 1) {
		fmt.Println("already closed")
		return
	}

	for _, e := range p.entries {
		for _, c := range e.channels {
			_ = c.Close()
		}
		_ = e.conn.Close()
	}
}

func (p *Pool) ConnectionCount() int {
	defer p.rwMtx.RUnlock()
	p.rwMtx.RLock()

	return len(p.entries)
}

func (p *Pool) ChannelCount() int {
	defer p.rwMtx.RUnlock()
	p.rwMtx.RLock()

	var count int
	for _, item := range p.entries {
		count += len(item.channels)
	}

	return count
}

func main() {
	p := New("amqp://guest:guest@localhost:5672/", 101)

	for i := 0; i < 102; i++ {
		go func(i int) {
			channel, err := p.Channel()
			if err != nil {
				panic(err)
			}

			_, err = channel.QueueDeclare(fmt.Sprintf("test-%d", i), true, false, false, false, amqp.Table{})
			if err != nil {
				panic(err)
			}

			_ = channel.PublishWithContext(
				context.Background(), "", fmt.Sprintf("test-%d", i), false, false,
				amqp.Publishing{
					ContentType:  "application/json",
					DeliveryMode: amqp.Persistent,
					Body:         []byte(`{"id":"x"}`),
				},
			)
		}(i)

	}

	exit := make(chan os.Signal, 1)
	signal.Notify(exit, os.Interrupt, os.Kill)
	<-exit

	fmt.Println("connection: ", p.ConnectionCount())
	fmt.Println("channel: ", p.ChannelCount())

	channel, err := p.Channel()
	if err != nil {
		panic(err)
	}
	for i := 0; i < 102; i++ {
		_, err = channel.QueueDelete(fmt.Sprintf("test-%d", i), false, false, false)
		if err != nil {
			panic(err)
		}
	}
	p.Close()
	p.Close()
}
