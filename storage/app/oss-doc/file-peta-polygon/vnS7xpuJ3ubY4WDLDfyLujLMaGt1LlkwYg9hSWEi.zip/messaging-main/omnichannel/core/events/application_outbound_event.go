package events

import (
	"encoding/json"
)

type ApplicationOutboundEvent struct {
	XId           string          `json:"xid"`
	ClientId      string          `json:"client_id"`
	ChannelId     string          `json:"channel_id"`
	AccountAlias  string          `json:"account_alias"`
	ApplicationId string          `json:"application_id"`
	Data          json.RawMessage `json:"data"`
}
