package ratelimiter

import "fmt"

type ErrorLimitExceed struct {
	message string
}

func NewErrorLimitExceed(format string, args ...any) *ErrorLimitExceed {
	return &ErrorLimitExceed{message: fmt.Sprintf(format, args...)}
}

func (e *ErrorLimitExceed) Error() string {
	return e.message
}
