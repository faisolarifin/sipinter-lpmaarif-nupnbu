package entities

import "strings"

type OutboundType string

const (
	OutboundTypeUnknown     OutboundType = "unknown"
	OutboundTypeTemplate    OutboundType = "template"
	OutboundTypeInteractive OutboundType = "interactive"
)

func (t OutboundType) String() string {
	return string(t)
}

func NewOutboundType(arg string) OutboundType {
	switch {
	case strings.EqualFold(arg, OutboundTypeTemplate.String()):
		return OutboundTypeTemplate
	case strings.EqualFold(arg, OutboundTypeInteractive.String()):
		return OutboundTypeInteractive
	}

	return OutboundTypeUnknown
}
