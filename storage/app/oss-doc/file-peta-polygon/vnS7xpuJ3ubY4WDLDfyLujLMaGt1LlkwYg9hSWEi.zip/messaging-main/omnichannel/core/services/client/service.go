package client

import (
	"context"
	"github.com/robfig/cron/v3"
	"sync/atomic"

	"core/services/client/messaging"
	"framework"
	sharedentities "shared/entities"
	sharedrepositories "shared/repositories"

	"github.com/sirupsen/logrus"
)

type Options struct {
	OutboundConcurrency int
}

type Service struct {
	state                             int32
	opts                              *Options
	client                            *sharedentities.Client
	receiverInboundEventConsumers     *framework.Map[string, *messaging.ReceiverInboundEventConsumer]
	applicationOutboundEventConsumers *framework.Map[string, *messaging.ApplicationOutboundEventWorkerConsumer]
	//applicationOutboundEventConsumers *framework.Map[string, *messaging.ApplicationOutboundEventConsumer]
	receiverStatusEventConsumers   *framework.Map[string, *messaging.ReceiverStatusEventConsumer]
	applicationRouteEventConsumers *framework.Map[string, *messaging.ApplicationRouteEventConsumer]
	accountRepository              sharedrepositories.AccountRepository
	applicationAccountRepository   sharedrepositories.ApplicationAccountRepository
	messagingFactory               *MessagingFactory
	logger                         *logrus.Entry
	cron                           *cron.Cron
}

func NewService(
	opts *Options,
	client *sharedentities.Client,
	accountRepository sharedrepositories.AccountRepository,
	applicationAccountRepository sharedrepositories.ApplicationAccountRepository,
	messagingFactory *MessagingFactory,
	logger *logrus.Logger,
) *Service {
	cr := cron.New(
		cron.WithSeconds(),
		cron.WithChain(
			cron.SkipIfStillRunning(cron.DiscardLogger),
			cron.Recover(cron.DiscardLogger),
		))

	return &Service{
		opts:                              opts,
		client:                            client,
		receiverInboundEventConsumers:     framework.NewMap[string, *messaging.ReceiverInboundEventConsumer](),
		applicationOutboundEventConsumers: framework.NewMap[string, *messaging.ApplicationOutboundEventWorkerConsumer](),
		//applicationOutboundEventConsumers: framework.NewMap[string, *messaging.ApplicationOutboundEventConsumer](),
		receiverStatusEventConsumers:   framework.NewMap[string, *messaging.ReceiverStatusEventConsumer](),
		applicationRouteEventConsumers: framework.NewMap[string, *messaging.ApplicationRouteEventConsumer](),
		accountRepository:              accountRepository,
		applicationAccountRepository:   applicationAccountRepository,
		messagingFactory:               messagingFactory,
		logger: logger.WithFields(
			logrus.Fields{
				"resource": "ClientService",
			},
		),
		cron: cr,
	}
}

func (s *Service) Start() {
	if !atomic.CompareAndSwapInt32(&s.state, 0, 1) {
		return
	}

	logger := s.logger.WithFields(
		logrus.Fields{
			"func":      "Start",
			"client_id": s.client.Id,
		})
	ctx := context.Background()
	logger.Infoln("AccountRepository.GetByClient")
	accounts, err := s.accountRepository.GetByClient(ctx, s.client.Id)
	if err != nil {
		logger.WithError(err).
			Errorln("AccountRepository.GetByClient")
		return
	}

	for _, account := range accounts {
		receiverInboundEventConsumer := s.messagingFactory.NewReceiverInboundEventConsumer(account)
		s.receiverInboundEventConsumers.Add(account.Id, receiverInboundEventConsumer)

		receiverStatusEventConsumer := s.messagingFactory.NewReceiverStatusEventConsumer(account)
		s.receiverStatusEventConsumers.Add(account.Id, receiverStatusEventConsumer)

		applicationRouteEventConsumer := s.messagingFactory.NewApplicationRouteEventConsumer(account)
		s.applicationRouteEventConsumers.Add(account.Id, applicationRouteEventConsumer)
	}

	logger.Infoln("ApplicationAccountRepository.GetByClient")
	applicationAccounts, err := s.applicationAccountRepository.GetByClient(ctx, s.client.Id)
	if err != nil {
		logger.WithError(err).
			Errorln("ApplicationAccountRepository.GetByClient")
		return
	}
	for _, applicationAccount := range applicationAccounts {
		applicationOutboundEventConsumer := s.messagingFactory.NewApplicationOutboundEventWorkerConsumer(
			s.opts.OutboundConcurrency,
			applicationAccount,
		)
		s.applicationOutboundEventConsumers.Add(applicationAccount.Id, applicationOutboundEventConsumer)
		//applicationOutboundEventConsumer := s.messagingFactory.NewApplicationOutboundEventConsumer(applicationAccount)
		//s.applicationOutboundEventConsumers.Add(applicationAccount.Id, applicationOutboundEventConsumer)
	}

	s.receiverInboundEventConsumers.Range(func(_ string, consumer *messaging.ReceiverInboundEventConsumer) bool {
		consumer.Consume()
		return true
	})
	s.applicationOutboundEventConsumers.Range(func(_ string, consumer *messaging.ApplicationOutboundEventWorkerConsumer) bool {
		consumer.Consume()
		return true
	})
	//s.applicationOutboundEventConsumers.Range(func(_ string, consumer *messaging.ApplicationOutboundEventConsumer) bool {
	//	consumer.Consume()
	//	return true
	//})
	s.receiverStatusEventConsumers.Range(func(_ string, consumer *messaging.ReceiverStatusEventConsumer) bool {
		consumer.Consume()
		return true
	})
	s.applicationRouteEventConsumers.Range(func(_ string, consumer *messaging.ApplicationRouteEventConsumer) bool {
		consumer.Consume()
		return true
	})

	// add watcher to cron for detect new consumer
	//_, err = s.cron.AddFunc("@every 1m", s.watch)
	//if err != nil {
	//	logger.WithError(err).
	//		Errorln("ApplicationAccountRepository.Cron.AddFunc")
	//}

	go func() {
		s.cron.Start()
	}()
}

func (s *Service) Stop() {
	if !atomic.CompareAndSwapInt32(&s.state, 1, 0) {
		return
	}

	logger := s.logger.WithFields(
		logrus.Fields{
			"func":      "Stop",
			"client_id": s.client.Id,
		})

	logger.Infoln("Stopping ReceiverInboundEventConsumers")
	s.receiverInboundEventConsumers.Range(func(_ string, consumer *messaging.ReceiverInboundEventConsumer) bool {
		consumer.Stop()
		return true
	})

	logger.Infoln("Stopping ApplicationOutboundEventConsumers")
	s.applicationOutboundEventConsumers.Range(func(_ string, consumer *messaging.ApplicationOutboundEventWorkerConsumer) bool {
		consumer.Stop()
		return true
	})
	//s.applicationOutboundEventConsumers.Range(func(_ string, consumer *messaging.ApplicationOutboundEventConsumer) bool {
	//	consumer.Stop()
	//	return true
	//})

	logger.Infoln("Stopping ReceiverStatusEventConsumers")
	s.receiverStatusEventConsumers.Range(func(_ string, consumer *messaging.ReceiverStatusEventConsumer) bool {
		consumer.Stop()
		return true
	})

	logger.Infoln("Stopping ReceiverRouteEventConsumers")
	s.applicationRouteEventConsumers.Range(func(_ string, consumer *messaging.ApplicationRouteEventConsumer) bool {
		consumer.Stop()
		return true
	})

	s.cron.Stop()
}

func (s *Service) watch() {
	if atomic.LoadInt32(&s.state) == 0 {
		return
	}

	logger := s.logger.WithFields(
		logrus.Fields{
			"func":      "Watch",
			"client_id": s.client.Id,
		})

	ctx := context.Background()
	logger.Infoln("AccountRepository.GetByClientAndChannel")
	accounts, err := s.accountRepository.GetByClientAndChannel(ctx, s.client.Id, "instagram")
	if err != nil {
		logger.WithError(err).
			Errorln("AccountRepository.GetByClientAndChannel")
		return
	}

	for _, account := range accounts {
		if s.receiverInboundEventConsumers.HasKey(account.Id) {
			continue
		}

		receiverInboundEventConsumer := s.messagingFactory.NewReceiverInboundEventConsumer(account)
		s.receiverInboundEventConsumers.Add(account.Id, receiverInboundEventConsumer)

		receiverStatusEventConsumer := s.messagingFactory.NewReceiverStatusEventConsumer(account)
		s.receiverStatusEventConsumers.Add(account.Id, receiverStatusEventConsumer)

		applicationRouteEventConsumer := s.messagingFactory.NewApplicationRouteEventConsumer(account)
		s.applicationRouteEventConsumers.Add(account.Id, applicationRouteEventConsumer)
	}

	logger.Infoln("ApplicationAccountRepository.GetByClient")
	applicationAccounts, err := s.applicationAccountRepository.GetByClientAndChannel(ctx, s.client.Id, "instagram")
	if err != nil {
		logger.WithError(err).
			Errorln("ApplicationAccountRepository.GetByClientAndChannel")
		return
	}
	for _, applicationAccount := range applicationAccounts {
		if s.applicationOutboundEventConsumers.HasKey(applicationAccount.Id) {
			continue
		}

		//applicationOutboundEventConsumer := s.messagingFactory.NewApplicationOutboundEventConsumer(applicationAccount)
		//s.applicationOutboundEventConsumers.Add(applicationAccount.Id, applicationOutboundEventConsumer)
		applicationOutboundEventConsumer := s.messagingFactory.NewApplicationOutboundEventWorkerConsumer(
			s.opts.OutboundConcurrency,
			applicationAccount,
		)
		s.applicationOutboundEventConsumers.Add(applicationAccount.Id, applicationOutboundEventConsumer)
	}

	s.receiverInboundEventConsumers.Range(func(_ string, consumer *messaging.ReceiverInboundEventConsumer) bool {
		consumer.Consume()
		return true
	})
	s.applicationOutboundEventConsumers.Range(func(_ string, consumer *messaging.ApplicationOutboundEventWorkerConsumer) bool {
		consumer.Consume()
		return true
	})
	//s.applicationOutboundEventConsumers.Range(func(_ string, consumer *messaging.ApplicationOutboundEventConsumer) bool {
	//	consumer.Consume()
	//	return true
	//})
	s.receiverStatusEventConsumers.Range(func(_ string, consumer *messaging.ReceiverStatusEventConsumer) bool {
		consumer.Consume()
		return true
	})
	s.applicationRouteEventConsumers.Range(func(_ string, consumer *messaging.ApplicationRouteEventConsumer) bool {
		consumer.Consume()
		return true
	})
}
