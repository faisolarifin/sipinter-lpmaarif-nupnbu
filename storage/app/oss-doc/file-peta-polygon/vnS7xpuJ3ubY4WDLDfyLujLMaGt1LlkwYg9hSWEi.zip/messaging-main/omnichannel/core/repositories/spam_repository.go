package repositories

import (
	"context"
	"core/entities"
)

type SpamRepository interface {
	IsSpam(ctx context.Context, clientId, channelId, accountId, sender string) (bool, error)
	Create(ctx context.Context, args *entities.CreateSpam) error
	DeleteExpired(ctx context.Context, clientId, channelId string, limit int) (int64, error)
}
