package queries

const (
	sessionRepositorySelect = `
        s.id,
        s.client_id,
        s.channel_id,
        s.account_alias,
        s.application_id as client_application_id,
		ca.application_id,
        s.sender,
        s.expired_at,
        s.created_at,
        s.updated_at
	`

	SessionRepositoryFind = `
		select
		` + sessionRepositorySelect + `
		from core.sessions as s
		left join public.client_applications as ca on s.application_id = ca.id
		where
			s.client_id = :client_id
			and s.channel_id = :channel_id
			and s.account_alias = :account_alias
			and s.sender = :sender 
		limit 1
	`

	SessionRepositoryCreate = `
		with s as (
			insert into core.sessions(
				client_id, 
				channel_id, 
				account_alias, 
				application_id, 
				sender,
				created_at
			) values (
				:client_id, 
				:channel_id, 
				:account_alias, 
				:application_id, 
				:sender,
				:created_at		          
			) returning *
		) 
		select ` + sessionRepositorySelect + `
		from s
		left join public.client_applications as ca on s.application_id = ca.id
		
	`

	SessionRepositoryUpdate = `
		with s as (
			update core.sessions
			set
				application_id = :application_id,
				updated_at = :updated_at
			where 
				client_id = :client_id
				and channel_id = :channel_id
				and account_alias = :account_alias
				and sender = :sender 		          
			returning *
		) 
		select ` + sessionRepositorySelect + `
		from s
		left join public.client_applications as ca on s.application_id = ca.id
	`
)
