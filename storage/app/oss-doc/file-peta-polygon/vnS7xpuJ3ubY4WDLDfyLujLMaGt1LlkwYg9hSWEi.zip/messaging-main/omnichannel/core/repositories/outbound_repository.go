package repositories

import (
	"context"

	"core/entities"
)

type OutboundRepository interface {
	FindByChannelAndAccountAndId(ctx context.Context, clientId, channelId, accountId, id string) (*entities.Outbound, error)
	FindByChannelAndAccountAndXid(ctx context.Context, clientId, channelId, accountId, xid string) (*entities.Outbound, error)
	FindByChannelAndAccountAndMid(ctx context.Context, clientId, channelId, accountId, mid string) (*entities.Outbound, error)
	Create(ctx context.Context, args *entities.OutboundCreate) (*entities.Outbound, error)
	UpdateMId(ctx context.Context, args *entities.OutboundUpdateMid) error
}
