package repositories

import (
	"context"
	"core/entities"
)

type ClientApplicationRepository interface {
	FindByApplicationId(ctx context.Context, clientId, clientAccountAlias, applicationId string) (*entities.ClientApplication, error)
	FindById(ctx context.Context, clientId, clientAccountAlias, id string) (*entities.ClientApplication, error)
}
