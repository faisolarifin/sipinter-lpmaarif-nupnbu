package entities

import "time"

type ClientApplication struct {
	Id              string     `db:"id"`
	ClientId        string     `db:"client_id"`
	ApplicationId   string     `db:"application_id"`
	ClientAccountId string     `db:"client_account_id"`
	Name            string     `db:"name"`
	Configuration   []byte     `db:"configuration"`
	IsDefault       bool       `db:"is_default"`
	IsActive        bool       `db:"is_active"`
	CreatedAt       time.Time  `db:"created_at"`
	CreatedBy       string     `db:"created_by"`
	UpdatedAt       *time.Time `db:"updated_at"`
	UpdatedBy       *string    `db:"updated_by"`
}
