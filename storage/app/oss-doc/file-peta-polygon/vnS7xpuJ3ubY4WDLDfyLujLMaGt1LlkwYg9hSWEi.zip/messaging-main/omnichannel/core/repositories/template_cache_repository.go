package repositories

import (
	"context"
	"core/entities"
)

type TemplateCacheRepository interface {
	FindByName(ctx context.Context, clientId, accountId, name string) (*entities.Template, error)
	Create(ctx context.Context, arg *entities.CreateCacheTemplate) error
}
