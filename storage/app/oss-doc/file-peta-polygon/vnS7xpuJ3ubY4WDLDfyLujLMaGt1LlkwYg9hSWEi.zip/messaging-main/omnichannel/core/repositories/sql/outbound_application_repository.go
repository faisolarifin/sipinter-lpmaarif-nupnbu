package sql

import (
	"context"
	"core/repositories/sql/queries"
	"fmt"

	"core/entities"
	"framework/database"

	"github.com/jackc/pgx/v5"
	"github.com/pkg/errors"
)

type OutboundApplicationRepository struct {
	db database.Querier
}

func newOutboundApplicationRepository(db database.Querier) *OutboundApplicationRepository {
	return &OutboundApplicationRepository{
		db: db,
	}
}

func (r *OutboundApplicationRepository) SetTx(tx pgx.Tx) {
	r.db = tx
}

func (r *OutboundApplicationRepository) FindByChannelAndAccountAndMid(ctx context.Context, clientId, channelId, accountId, mid string) (*entities.OutboundApplication, error) {
	namedArgs := map[string]any{
		"client_id":  clientId,
		"account_id": accountId,
		"mid":        mid,
	}

	query := r.bindQueryChannel(queries.OutboundApplicationRepositoryFindByChannelAndAccountAndMid, channelId)
	query, params, err := database.NamedQuery(query, namedArgs)
	if err != nil {
		return nil, errors.WithMessage(err, "OutboundApplicationRepository.FindByChannelAndAccountAndMid NamedQuery")
	}

	var outbound entities.OutboundApplication
	row := r.db.QueryRow(ctx, query, params...)
	if err = r.scan(row, &outbound); err != nil {
		if err == pgx.ErrNoRows {
			return nil, errors.WithStack(entities.NewErrorOutboundNotFound(
				"Outbound with channel %s, account %s and mid %s not found", channelId, accountId, mid))
		}
		return nil, errors.WithMessage(err, "OutboundApplicationRepository.FindByChannelAndAccountAndMid QueryRow")
	}

	return &outbound, nil
}

func (r *OutboundApplicationRepository) bindQueryChannel(query, channelId string) string {
	return fmt.Sprintf(query, channelId)
}

func (r *OutboundApplicationRepository) scan(scanner database.RowScanner, outbound *entities.OutboundApplication) error {
	return scanner.Scan(
		&outbound.Id,
		&outbound.XId,
		&outbound.MId,
		&outbound.ClientId,
		&outbound.ChannelId,
		&outbound.AccountId,
		&outbound.ClientApplicationId,
		&outbound.ApplicationId,
		&outbound.Type,
		&outbound.Recipient,
		&outbound.Data,
		&outbound.CreatedAt,
		&outbound.UpdatedAt,
	)
}
