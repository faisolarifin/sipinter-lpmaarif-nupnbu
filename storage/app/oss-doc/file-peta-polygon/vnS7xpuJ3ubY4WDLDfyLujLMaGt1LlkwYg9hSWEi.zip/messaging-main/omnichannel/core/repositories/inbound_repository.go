package repositories

import (
	"context"

	"core/entities"
)

type InboundRepository interface {
	Create(ctx context.Context, args *entities.InboundCreate) (*entities.Inbound, error)
}
