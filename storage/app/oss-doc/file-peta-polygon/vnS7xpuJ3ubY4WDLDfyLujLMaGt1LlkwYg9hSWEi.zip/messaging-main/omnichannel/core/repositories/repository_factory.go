package repositories

type RepositoryFactory interface {
	NewInboundRepository() InboundRepository
	NewOutboundRepository() OutboundRepository
	NewOutboundApplicationRepository() OutboundApplicationRepository
	NewSessionRepository() SessionRepository
	NewStatusRepository() StatusRepository
	NewRouteRepository() RouteRepository
	NewClientApplicationRepository() ClientApplicationRepository
	NewWhatsAppSessionRepository() WhatsAppSessionRepository
	NewSpamRepository() SpamRepository
	NewTemplateRepository() TemplateRepository
	NewTemplateCacheRepository() TemplateCacheRepository
}
