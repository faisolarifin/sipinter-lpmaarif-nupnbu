package events

import (
	"encoding/json"
	"strings"
)

type ReceiverStatusEvent struct {
	ClientId            string          `json:"client_id"`
	ChannelId           string          `json:"channel"`
	AccountAlias        string          `json:"account_alias"`
	ChannelAccountAlias string          `json:"channel_account_alias"`
	Data                json.RawMessage `json:"data"`
}

func (e ReceiverStatusEvent) GetAccountAlias() string {
	result := strings.TrimSpace(e.ChannelAccountAlias)
	if result == "" {
		result = strings.TrimSpace(e.AccountAlias)
	}

	return result
}
