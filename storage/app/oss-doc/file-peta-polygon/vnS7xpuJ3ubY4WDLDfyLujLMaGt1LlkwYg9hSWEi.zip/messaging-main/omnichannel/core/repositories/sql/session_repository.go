package sql

import (
	"context"

	"core/entities"
	"core/repositories/sql/queries"
	"framework/database"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/pkg/errors"
)

type SessionRepository struct {
	db database.Querier
}

func newSessionRepository(db *pgxpool.Pool) *SessionRepository {
	return &SessionRepository{
		db: db,
	}
}

func (r *SessionRepository) Find(ctx context.Context, clientId, channelId, accountAlias, sender string) (*entities.Session, error) {
	namedArgs := map[string]any{
		"client_id":     clientId,
		"channel_id":    channelId,
		"account_alias": accountAlias,
		"sender":        sender,
	}

	query, params, err := database.NamedQuery(queries.SessionRepositoryFind, namedArgs)
	if err != nil {
		return nil, errors.WithMessage(err, "SessionRepository.Find NamedQuery")
	}

	var session entities.Session
	row := r.db.QueryRow(ctx, query, params...)
	if err = r.scan(row, &session); err != nil {
		if err == pgx.ErrNoRows {
			return nil, errors.WithStack(entities.NewErrorSessionNotFound(
				"Session with channel %s and sender %s not found", channelId, sender))
		}
		return nil, errors.WithMessage(err, "SessionRepository.Find QueryRow")
	}

	return &session, nil
}

func (r *SessionRepository) Create(ctx context.Context, args *entities.SessionCreate) (*entities.Session, error) {
	namedArgs := map[string]any{
		"client_id":      args.ClientId,
		"channel_id":     args.ChannelId,
		"account_alias":  args.AccountAlias,
		"application_id": args.ApplicationId,
		"sender":         args.Sender,
		"created_at":     args.CreatedAt,
	}

	query, params, err := database.NamedQuery(queries.SessionRepositoryCreate, namedArgs)
	if err != nil {
		return nil, errors.WithMessage(err, "SessionRepository.Create NamedQuery")
	}

	var session entities.Session
	row := r.db.QueryRow(ctx, query, params...)
	if err = r.scan(row, &session); err != nil {
		return nil, errors.WithMessage(err, "SessionRepository.Create QueryRow")
	}

	return &session, nil
}

func (r *SessionRepository) Update(ctx context.Context, args *entities.SessionUpdate) (*entities.Session, error) {
	namedArgs := map[string]any{
		"client_id":      args.ClientId,
		"channel_id":     args.ChannelId,
		"account_alias":  args.AccountAlias,
		"application_id": args.ApplicationId,
		"sender":         args.Sender,
		"updated_at":     args.UpdatedAt,
	}

	query, params, err := database.NamedQuery(queries.SessionRepositoryUpdate, namedArgs)
	if err != nil {
		return nil, errors.WithMessage(err, "SessionRepository.Update NamedQuery")
	}

	var session entities.Session
	row := r.db.QueryRow(ctx, query, params...)
	if err = r.scan(row, &session); err != nil {
		return nil, errors.WithMessage(err, "SessionRepository.Update QueryRow")
	}

	return &session, nil
}

func (r *SessionRepository) scan(scanner database.RowScanner, session *entities.Session) error {
	return scanner.Scan(
		&session.Id,
		&session.ClientId,
		&session.ChannelId,
		&session.AccountId,
		&session.ClientApplicationId,
		&session.ApplicationId,
		&session.Sender,
		&session.ExpiredAt,
		&session.CreatedAt,
		&session.UpdatedAt,
	)
}
