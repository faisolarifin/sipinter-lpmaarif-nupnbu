package entities

import "time"

type ClientAccountCountry struct {
	Id              string
	ClientAccountId string
	Prefix          string
	CreatedAt       time.Time
	CreatedBy       string
	UpdatedAt       *time.Time
	UpdatedBy       *string
}
