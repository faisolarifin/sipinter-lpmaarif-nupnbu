package events

import (
	"encoding/json"
	"time"
)

type ApplicationStatusEvent struct {
	Id            string          `json:"id"`
	OId           string          `json:"oid"`
	XId           string          `json:"xid"`
	MId           string          `json:"mid"`
	ClientId      string          `json:"client_id"`
	ChannelId     string          `json:"channel_id"`
	AccountId     string          `json:"account_id"`
	AccountAlias  string          `json:"account_alias"`
	ApplicationId string          `json:"application_id"`
	Type          string          `json:"type"`
	Data          json.RawMessage `json:"data"`
	Outbound      *Outbound       `json:"outbound,omitempty"`
	CreatedAt     time.Time       `json:"created_at"`
}

func (e *ApplicationStatusEvent) ToMap() map[string]any {
	if e == nil {
		return nil
	}

	return map[string]any{
		"Id":            e.Id,
		"OId":           e.OId,
		"XId":           e.XId,
		"MId":           e.MId,
		"ClientId":      e.ClientId,
		"ChannelId":     e.ChannelId,
		"AccountId":     e.AccountId,
		"AccountAlias":  e.AccountAlias,
		"ApplicationId": e.ApplicationId,
		"Data":          string(e.Data),
		"Outbound":      e.Outbound.ToMap(),
		"CreatedAt":     e.CreatedAt,
	}
}

type Outbound struct {
	Type      string          `json:"type"`
	Recipient string          `json:"recipient"`
	Data      json.RawMessage `json:"data"`
}

func (e *Outbound) ToMap() map[string]any {
	if e == nil {
		return nil
	}

	return map[string]any{
		"Type":      e.Type,
		"Recipient": e.Recipient,
		"Data":      string(e.Data),
	}
}
