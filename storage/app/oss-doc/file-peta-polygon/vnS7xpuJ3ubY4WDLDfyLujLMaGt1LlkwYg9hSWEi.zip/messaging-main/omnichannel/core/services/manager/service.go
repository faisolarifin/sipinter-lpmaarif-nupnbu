package manager

import (
	"context"
	"sync"
	"sync/atomic"

	clientservice "core/services/client"
	"framework"
	sharedentities "shared/entities"
	sharedrepositories "shared/repositories"

	"github.com/sirupsen/logrus"
)

type Service struct {
	state                int32
	rwmtx                sync.Mutex
	clients              *framework.Map[string, *clientservice.Service]
	clientRepository     sharedrepositories.ClientRepository
	clientServiceFactory *clientservice.ServiceFactory
	logger               *logrus.Entry
}

func NewService(
	clientRepository sharedrepositories.ClientRepository,
	clientServiceFactory *clientservice.ServiceFactory,
	logger *logrus.Logger,
) *Service {
	return &Service{
		clients:              framework.NewMap[string, *clientservice.Service](),
		clientRepository:     clientRepository,
		clientServiceFactory: clientServiceFactory,
		logger: logger.WithFields(
			logrus.Fields{
				"resource": "ManagerService",
			},
		),
	}
}

func (s *Service) Add(client *sharedentities.Client) bool {
	s.rwmtx.Lock()
	defer s.rwmtx.Unlock()
	if !s.clients.HasKey(client.Id) {
		clientService := s.clientServiceFactory.NewClientService(client)
		clientService.Start()
		s.clients.Add(client.Id, clientService)
		return true
	}
	return false
}

func (s *Service) Remove(client *sharedentities.Client) bool {
	s.rwmtx.Lock()
	defer s.rwmtx.Unlock()
	if s.clients.HasKey(client.Id) {
		clientService := s.clients.Get(client.Id)
		clientService.Stop()
		clientService = nil
		s.clients.Remove(client.Id)
		return true
	}
	return false
}

func (s *Service) Start() {
	if !atomic.CompareAndSwapInt32(&s.state, 0, 1) {
		return
	}
	logger := s.logger.WithFields(
		logrus.Fields{
			"func": "Start",
		})
	ctx := context.Background()
	logger.Infoln("ClientRepository.GetAll")
	clients, err := s.clientRepository.GetAll(ctx)
	if err != nil {
		logger.WithError(err).Infoln("ClientRepository.GetAll")
		return
	}

	logger.Infoln("Starting ClientService")
	for _, client := range clients {
		clientService := s.clientServiceFactory.NewClientService(client)
		clientService.Start()
		s.clients.Add(client.Id, clientService)
	}
}

func (s *Service) Stop() {
	if !atomic.CompareAndSwapInt32(&s.state, 1, 0) {
		return
	}
	logger := s.logger.WithFields(
		logrus.Fields{
			"func": "Stop",
		})
	logger.Infoln("Stopping ClientService")
	s.clients.Range(func(_ string, service *clientservice.Service) bool {
		service.Stop()
		service = nil
		return true
	})
}
