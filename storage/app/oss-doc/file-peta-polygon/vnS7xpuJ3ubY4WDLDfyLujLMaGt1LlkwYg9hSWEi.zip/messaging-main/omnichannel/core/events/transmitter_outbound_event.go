package events

import (
	"encoding/json"

	"core/entities"
)

type TransmitterOutboundEvent struct {
	Id            string                `json:"id"`
	XId           string                `json:"xid"`
	ClientId      string                `json:"client_id"`
	ChannelId     string                `json:"channel_id"`
	AccountId     string                `json:"account_id"`
	AccountAlias  string                `json:"account_alias"`
	ApplicationId string                `json:"application_id"`
	Type          entities.OutboundType `json:"type"`
	Data          json.RawMessage       `json:"data"`
}

func (e *TransmitterOutboundEvent) ToMap() map[string]any {
	if e == nil {
		return nil
	}

	return map[string]any{
		"Id":            e.Id,
		"ClientId":      e.ClientId,
		"ChannelId":     e.ChannelId,
		"AccountId":     e.AccountId,
		"AccountAlias":  e.AccountAlias,
		"ApplicationId": e.ApplicationId,
		"Type":          e.Type,
		"Data":          string(e.Data),
	}
}
