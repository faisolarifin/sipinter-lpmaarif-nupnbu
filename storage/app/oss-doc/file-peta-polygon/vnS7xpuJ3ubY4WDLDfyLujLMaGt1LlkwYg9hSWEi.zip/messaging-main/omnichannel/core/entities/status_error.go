package entities

import "strings"

type StatusError string

func NewStatusError(arg string) StatusError {
	switch {
	case strings.EqualFold(arg, StatusErrorMissingId.String()):
		return StatusErrorMissingId
	case strings.EqualFold(arg, StatusErrorMissingXId.String()):
		return StatusErrorMissingXId
	case strings.EqualFold(arg, StatusErrorMissingMId.String()):
		return StatusErrorMissingMId
	case strings.EqualFold(arg, StatusErrorMissingClientId.String()):
		return StatusErrorMissingClientId
	case strings.EqualFold(arg, StatusErrorMissingChannelId.String()):
		return StatusErrorMissingChannelId
	case strings.EqualFold(arg, StatusErrorMissingAccountAlias.String()):
		return StatusErrorMissingAccountAlias
	case strings.EqualFold(arg, StatusErrorClientIdNotFound.String()):
		return StatusErrorClientIdNotFound
	case strings.EqualFold(arg, StatusErrorAccountIdNotFound.String()):
		return StatusErrorAccountIdNotFound
	case strings.EqualFold(arg, StatusErrorInvalidChannelId.String()):
		return StatusErrorInvalidChannelId
	case strings.EqualFold(arg, StatusErrorInactiveAccountId.String()):
		return StatusErrorInactiveAccountId
	case strings.EqualFold(arg, StatusErrorInvalidRouting.String()):
		return StatusErrorInvalidRouting
	case strings.EqualFold(arg, StatusErrorInvalidContentType.String()):
		return StatusErrorInvalidContentType
	case strings.EqualFold(arg, StatusErrorOutboundNotFound.String()):
		return StatusErrorOutboundNotFound
	}

	return StatusErrorUnknown
}

const (
	StatusErrorUnknown             StatusError = "unknown"
	StatusErrorMissingId           StatusError = "missing_id"
	StatusErrorMissingXId          StatusError = "missing_xid"
	StatusErrorMissingMId          StatusError = "missing_mid"
	StatusErrorMissingClientId     StatusError = "missing_client_id"
	StatusErrorMissingChannelId    StatusError = "missing_channel_id"
	StatusErrorMissingAccountAlias StatusError = "missing_account_alias"
	StatusErrorClientIdNotFound    StatusError = "client_id_not_found"
	StatusErrorAccountIdNotFound   StatusError = "account_id_not_found"
	StatusErrorInvalidChannelId    StatusError = "invalid_channel_id"
	StatusErrorInactiveAccountId   StatusError = "inactive_account_id"
	StatusErrorInvalidRouting      StatusError = "invalid_routing"
	StatusErrorInvalidContentType  StatusError = "invalid_content_type"
	StatusErrorOutboundNotFound    StatusError = "outbound_not_found"
)

func (t StatusError) Error() string {
	return t.String()
}

func (t StatusError) String() string {
	return string(t)
}
