package sql

import (
	"context"
	"core/entities"
	"fmt"
	"framework/database"
	"github.com/jackc/pgx/v5"
	"github.com/pkg/errors"
)

func newWhatsAppSessionRepository(db database.Querier) *WhatsAppSessionRepository {
	return &WhatsAppSessionRepository{db: db}
}

type WhatsAppSessionRepository struct {
	db database.Querier
}

func (r *WhatsAppSessionRepository) CreateOrUpdate(ctx context.Context, channelId string, args *entities.CreateOrUpdateWhatsAppSession) error {
	query := fmt.Sprintf(`
		insert into "%s".sessions(client_id, client_account_id, recipient, conversation_id, pricing_category, expired_at, created_at)
			values (@client_id, @client_account_id, @recipient, @conversation_id, @pricing_category, @expired_at, @datetime)
		on conflict (client_id, client_account_id, recipient, pricing_category) do update
		set conversation_id = excluded.conversation_id,
			expired_at = excluded.expired_at,
			updated_at = @datetime
	`, channelId)
	params := pgx.NamedArgs{
		"client_id":         args.ClientId,
		"client_account_id": args.ClientAccountId,
		"recipient":         args.Recipient,
		"conversation_id":   args.ConversationId,
		"pricing_category":  args.PricingCategory,
		"expired_at":        args.ExpiredAt,
		"datetime":          args.DateTime,
	}
	_, err := r.db.Exec(ctx, query, params)
	if err != nil {
		return errors.WithStack(err)
	}

	return nil
}
