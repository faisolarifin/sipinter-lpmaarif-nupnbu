package sql

import (
	"context"
	"fmt"

	"core/entities"
	"core/repositories/sql/queries"
	"framework/database"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/pkg/errors"
)

type RouteRepository struct {
	db database.Querier
}

func newRouteRepository(db *pgxpool.Pool) *RouteRepository {
	return &RouteRepository{
		db: db,
	}
}

func (r *RouteRepository) SetTx(tx pgx.Tx) {
	r.db = tx
}

func (r *RouteRepository) Create(ctx context.Context, args *entities.RouteCreate) (*entities.Route, error) {
	namedArgs := map[string]any{
		"mid":            args.MId,
		"client_id":      args.ClientId,
		"channel_id":     args.ChannelId,
		"account_id":     args.AccountId,
		"application_id": args.ApplicationId,
		"route":          args.Route,
		"data":           args.Data,
		"created_at":     args.CreatedAt,
	}

	query := r.bindQueryChannel(queries.RouteRepositoryCreate, args.ChannelId)
	query, params, err := database.NamedQuery(query, namedArgs)
	if err != nil {
		return nil, errors.WithMessage(err, "RouteRepository.Create NamedQuery")
	}

	var route entities.Route
	row := r.db.QueryRow(ctx, query, params...)
	if err = r.scan(row, &route); err != nil {
		return nil, errors.WithMessage(err, "RouteRepository.Create QueryRow")
	}

	return &route, nil
}

func (r *RouteRepository) bindQueryChannel(query, channelId string) string {
	return fmt.Sprintf(query, channelId)
}

func (r *RouteRepository) scan(scanner database.RowScanner, route *entities.Route) error {
	return scanner.Scan(
		&route.Id,
		&route.MId,
		&route.ClientId,
		&route.ChannelId,
		&route.AccountId,
		&route.ApplicationId,
		&route.Route,
		&route.Data,
		&route.CreatedAt,
	)
}
