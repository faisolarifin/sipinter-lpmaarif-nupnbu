package client

import (
	clientmessaging "core/services/client/messaging"
	"core/services/inbound"
	"core/services/outbound"
	"core/services/route"
	"core/services/status"
	"framework/messaging"
	"framework/messaging/consumer"
	"github.com/sirupsen/logrus"
	sharedentities "shared/entities"
)

func NewMessagingFactory(
	coreInboundServiceFactory *inbound.ServiceFactory,
	coreOutboundServiceFactory *outbound.ServiceFactory,
	coreStatusServiceFactory *status.ServiceFactory,
	coreRouteServiceFactory *route.ServiceFactory,
	amqpMessagingFactory messaging.AMQPFactory,
	logger *logrus.Logger,
) *MessagingFactory {
	return &MessagingFactory{
		coreInboundServiceFactory:  coreInboundServiceFactory,
		coreOutboundServiceFactory: coreOutboundServiceFactory,
		coreStatusServiceFactory:   coreStatusServiceFactory,
		coreRouteServiceFactory:    coreRouteServiceFactory,
		amqpMessagingFactory:       amqpMessagingFactory,
		logger:                     logger,
	}
}

type MessagingFactory struct {
	coreInboundServiceFactory  *inbound.ServiceFactory
	coreOutboundServiceFactory *outbound.ServiceFactory
	coreStatusServiceFactory   *status.ServiceFactory
	coreRouteServiceFactory    *route.ServiceFactory
	amqpMessagingFactory       messaging.AMQPFactory
	logger                     *logrus.Logger
}

func (f *MessagingFactory) NewReceiverInboundEventConsumer(account *sharedentities.Account) *clientmessaging.ReceiverInboundEventConsumer {
	return clientmessaging.NewReceiverInboundEventConsumer(
		account,
		f.coreInboundServiceFactory.NewService(),
		f.amqpMessagingFactory.NewAMQPConsumer(),
		f.logger,
	)
}

func (f *MessagingFactory) NewApplicationOutboundEventConsumer(applicationAccount *sharedentities.ApplicationAccount) *clientmessaging.ApplicationOutboundEventConsumer {
	return clientmessaging.NewApplicationOutboundEventConsumer(
		applicationAccount,
		f.coreOutboundServiceFactory.NewService(),
		f.amqpMessagingFactory.NewAMQPConsumer(),
		f.logger,
	)
}

func (f *MessagingFactory) NewApplicationOutboundEventWorkerConsumer(concurrency int, applicationAccount *sharedentities.ApplicationAccount) *clientmessaging.ApplicationOutboundEventWorkerConsumer {
	return clientmessaging.NewApplicationOutboundEventWorkerConsumer(
		applicationAccount,
		f.amqpMessagingFactory.NewAMQPWorkerConsumer(func() messaging.AMQPWorker {
			return clientmessaging.NewApplicationOutboundEventWorker(f.logger, f.coreOutboundServiceFactory.NewService())
		},
			consumer.Qos(concurrency, 0, false),
			consumer.Concurrency(concurrency)),
		f.logger,
	)
}

func (f *MessagingFactory) NewReceiverStatusEventConsumer(account *sharedentities.Account) *clientmessaging.ReceiverStatusEventConsumer {
	return clientmessaging.NewReceiverStatusEventConsumer(
		account,
		f.coreStatusServiceFactory.NewService(),
		f.amqpMessagingFactory.NewAMQPConsumer(),
		f.logger,
	)
}

func (f *MessagingFactory) NewApplicationRouteEventConsumer(account *sharedentities.Account) *clientmessaging.ApplicationRouteEventConsumer {
	return clientmessaging.NewApplicationRouteEventConsumer(
		account,
		f.coreRouteServiceFactory.NewService(),
		f.amqpMessagingFactory.NewAMQPConsumer(),
		f.logger,
	)
}
