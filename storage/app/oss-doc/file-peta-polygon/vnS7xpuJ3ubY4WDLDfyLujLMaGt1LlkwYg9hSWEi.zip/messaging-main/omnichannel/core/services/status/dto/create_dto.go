package dto

import (
	"encoding/json"
	"strings"
	"time"

	"core/entities"
	sharedentities "shared/entities"

	uuid "github.com/satori/go.uuid"
	"github.com/tidwall/gjson"
)

type CreateDto struct {
	ClientId     string
	ChannelId    string
	AccountAlias string
	Data         json.RawMessage
	CreatedAt    time.Time
}

func (d *CreateDto) MId() string {
	var mid string
	switch sharedentities.NewChannel(d.ChannelId) {
	case sharedentities.ChannelWhatsApp:
		mid = gjson.GetBytes(d.Data, "statuses.0.id").String()
	case sharedentities.ChannelWhatsAppCloud:
		mid = gjson.GetBytes(d.Data, "entry.0.changes.0.value.statuses.0.id").String()
	case sharedentities.ChannelEmail:
		mid = strings.Replace(uuid.NewV1().String(), "-", "", -1)
	case sharedentities.ChannelSMS:
		mid = gjson.GetBytes(d.Data, "message_id").String()
	}

	return mid
}

func (d *CreateDto) Type() entities.StatusType {
	switch sharedentities.NewChannel(d.ChannelId) {
	case sharedentities.ChannelWhatsApp:
		return entities.NewStatusType(gjson.GetBytes(d.Data, "statuses.0.status").String())
	case sharedentities.ChannelWhatsAppCloud:
		return entities.NewStatusType(gjson.GetBytes(d.Data, "entry.0.changes.0.value.statuses.0.status").String())
	case sharedentities.ChannelEmail:
		return entities.StatusTypeDelivered
	case sharedentities.ChannelSMS:
		status := gjson.GetBytes(d.Data, "delivery_status").String()
		if status == "1" {
			return entities.StatusTypeDelivered
		} else {
			return entities.StatusTypeFailed
		}
	}

	return entities.StatusTypeUnknown
}

func (d *CreateDto) ToMap() map[string]any {
	if d == nil {
		return nil
	}

	return map[string]any{
		"MId":          d.MId,
		"ClientId":     d.ClientId,
		"ChannelId":    d.ChannelId,
		"AccountAlias": d.AccountAlias,
		"Data":         string(d.Data),
		"CreatedAt":    d.CreatedAt,
	}
}
