package entities

import "time"

type CreateOrUpdateWhatsAppSession struct {
	ClientId        string
	ClientAccountId string
	Recipient       string
	ConversationId  string
	PricingCategory string
	ExpiredAt       time.Time
	DateTime        time.Time
}
