package entities

const (
	ApplicationTypeUnknown      ApplicationType = ""
	ApplicationTypeHelpdesk     ApplicationType = "helpdesk"
	ApplicationTypeChatbot      ApplicationType = "chatbot"
	ApplicationTypeCampaign     ApplicationType = "campaign"
	ApplicationTypeBroadcast    ApplicationType = "broadcast"
	ApplicationTypeBroadcastM2M ApplicationType = "broadcast-m2m"
)

type ApplicationType string

func (t ApplicationType) String() string {
	return string(t)
}
