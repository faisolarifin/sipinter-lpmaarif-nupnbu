package manager

import (
	clientservice "core/services/client"
	sharedrepositories "shared/repositories"

	"github.com/sirupsen/logrus"
)

type ServiceFactory struct {
	sharedRepositoryFactory sharedrepositories.RepositoryFactory
	clientServiceFactory    *clientservice.ServiceFactory
	logger                  *logrus.Logger
}

func NewServiceFactory(
	sharedRepositoryFactory sharedrepositories.RepositoryFactory,
	clientServiceFactory *clientservice.ServiceFactory,
	logger *logrus.Logger,
) *ServiceFactory {
	return &ServiceFactory{
		sharedRepositoryFactory: sharedRepositoryFactory,
		clientServiceFactory:    clientServiceFactory,
		logger:                  logger,
	}
}

func (f *ServiceFactory) NewManagerService() *Service {
	return NewService(
		f.sharedRepositoryFactory.NewClientRepository(),
		f.clientServiceFactory,
		f.logger,
	)
}
