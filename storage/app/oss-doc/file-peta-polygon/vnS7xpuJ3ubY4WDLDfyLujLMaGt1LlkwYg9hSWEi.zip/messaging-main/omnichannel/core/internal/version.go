package internal

const (
	// Version current application version
	Version = "0.0.1"

	// Author application creator
	Author = "jatis mobile"
)
