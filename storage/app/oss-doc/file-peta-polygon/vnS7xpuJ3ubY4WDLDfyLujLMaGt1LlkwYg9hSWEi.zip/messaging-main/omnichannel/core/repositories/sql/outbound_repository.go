package sql

import (
	"context"
	"fmt"

	"core/entities"
	"core/repositories/sql/queries"
	"framework/database"

	"github.com/jackc/pgx/v5"
	"github.com/pkg/errors"
)

type OutboundRepository struct {
	db database.Querier
}

func newOutboundRepository(db database.Querier) *OutboundRepository {
	return &OutboundRepository{
		db: db,
	}
}

func (r *OutboundRepository) SetTx(tx pgx.Tx) {
	r.db = tx
}

func (r *OutboundRepository) FindByChannelAndAccountAndId(ctx context.Context, clientId, channelId, accountId, id string) (*entities.Outbound, error) {
	namedArgs := map[string]any{
		"client_id":  clientId,
		"account_id": accountId,
		"id":         id,
	}

	query := r.bindQueryChannel(queries.OutboundRepositoryFindByChannelAndAccountAndId, channelId)
	query, params, err := database.NamedQuery(query, namedArgs)
	if err != nil {
		return nil, errors.WithMessage(err, "OutboundRepository.FindByChannelAndAccountAndId NamedQuery")
	}

	var outbound entities.Outbound
	row := r.db.QueryRow(ctx, query, params...)
	if err = r.scan(row, &outbound); err != nil {
		if err == pgx.ErrNoRows {
			return nil, errors.WithStack(entities.NewErrorOutboundNotFound(
				"Outbound with channel %s, account %s and id %s not found", channelId, accountId, id))
		}
		return nil, errors.WithMessage(err, "OutboundRepository.FindByChannelAndAccountAndId QueryRow")
	}

	return &outbound, nil
}

func (r *OutboundRepository) FindByChannelAndAccountAndXid(ctx context.Context, clientId, channelId, accountId, xid string) (*entities.Outbound, error) {
	namedArgs := map[string]any{
		"client_id":  clientId,
		"account_id": accountId,
		"xid":        xid,
	}

	query := r.bindQueryChannel(queries.OutboundRepositoryFindByChannelAndAccountAndXid, channelId)
	query, params, err := database.NamedQuery(query, namedArgs)
	if err != nil {
		return nil, errors.WithMessage(err, "OutboundRepository.FindByChannelAndAccountAndXid NamedQuery")
	}

	var outbound entities.Outbound
	row := r.db.QueryRow(ctx, query, params...)
	if err = r.scan(row, &outbound); err != nil {
		if err == pgx.ErrNoRows {
			return nil, errors.WithStack(entities.NewErrorOutboundNotFound(
				"Outbound with channel %s, account %s and xid %s not found", channelId, accountId, xid))
		}
		return nil, errors.WithMessage(err, "OutboundRepository.FindByChannelAndAccountAndXid QueryRow")
	}

	return &outbound, nil
}

func (r *OutboundRepository) FindByChannelAndAccountAndMid(ctx context.Context, clientId, channelId, accountId, mid string) (*entities.Outbound, error) {
	namedArgs := map[string]any{
		"client_id":  clientId,
		"account_id": accountId,
		"mid":        mid,
	}

	query := r.bindQueryChannel(queries.OutboundRepositoryFindByChannelAndAccountAndMid, channelId)
	query, params, err := database.NamedQuery(query, namedArgs)
	if err != nil {
		return nil, errors.WithMessage(err, "OutboundRepository.FindByChannelAndAccountAndMid NamedQuery")
	}

	var outbound entities.Outbound
	row := r.db.QueryRow(ctx, query, params...)
	if err = r.scan(row, &outbound); err != nil {
		if err == pgx.ErrNoRows {
			return nil, errors.WithStack(entities.NewErrorOutboundNotFound(
				"Outbound with channel %s, account %s and mid %s not found", channelId, accountId, mid))
		}
		return nil, errors.WithMessage(err, "OutboundRepository.FindByChannelAndAccountAndMid QueryRow")
	}

	return &outbound, nil
}

func (r *OutboundRepository) Create(ctx context.Context, args *entities.OutboundCreate) (*entities.Outbound, error) {
	namedArgs := map[string]any{
		"xid":            args.XId,
		"client_id":      args.ClientId,
		"channel_id":     args.ChannelId,
		"account_id":     args.AccountId,
		"application_id": args.ApplicationId,
		"type":           args.Type,
		"recipient":      args.Recipient,
		"data":           args.Data,
		"created_at":     args.CreatedAt,
	}

	query := r.bindQueryChannel(queries.OutboundRepositoryCreate, args.ChannelId)
	query, params, err := database.NamedQuery(query, namedArgs)
	if err != nil {
		return nil, errors.WithMessage(err, "OutboundRepository.Create NamedQuery")
	}

	var outbound entities.Outbound
	row := r.db.QueryRow(ctx, query, params...)
	if err = r.scan(row, &outbound); err != nil {
		return nil, errors.WithMessage(err, "OutboundRepository.Create QueryRow")
	}

	return &outbound, nil
}

func (r *OutboundRepository) UpdateMId(ctx context.Context, args *entities.OutboundUpdateMid) error {
	namedArgs := map[string]any{
		"id":         args.Id,
		"mid":        args.MId,
		"client_id":  args.ClientId,
		"updated_at": args.UpdatedAt,
	}

	query := r.bindQueryChannel(queries.OutboundRepositoryUpdateMId, args.ChannelId)
	query, params, err := database.NamedQuery(query, namedArgs)
	if err != nil {
		return errors.WithMessage(err, "OutboundRepository.UpdateMId NamedQuery")
	}

	commandTag, err := r.db.Exec(ctx, query, params...)
	if err != nil {
		return errors.WithMessage(err, "OutboundRepository.UpdateMId QueryRow")
	}

	if commandTag.RowsAffected() < 1 {
		return errors.WithStack(database.NewErrorNoRowsAffected(
			"Outbound with channel %s and id %s not found", args.ChannelId, args.Id))
	}

	return nil
}

func (r *OutboundRepository) bindQueryChannel(query, channelId string) string {
	return fmt.Sprintf(query, channelId)
}

func (r *OutboundRepository) scan(scanner database.RowScanner, outbound *entities.Outbound) error {
	return scanner.Scan(
		&outbound.Id,
		&outbound.XId,
		&outbound.MId,
		&outbound.ClientId,
		&outbound.ChannelId,
		&outbound.AccountId,
		&outbound.ApplicationId,
		&outbound.Type,
		&outbound.Recipient,
		&outbound.Data,
		&outbound.CreatedAt,
		&outbound.UpdatedAt,
	)
}
