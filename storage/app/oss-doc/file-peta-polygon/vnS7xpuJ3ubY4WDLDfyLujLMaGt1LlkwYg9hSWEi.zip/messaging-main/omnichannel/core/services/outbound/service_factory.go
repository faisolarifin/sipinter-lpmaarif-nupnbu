package outbound

import (
	corerepositories "core/repositories"
	"framework/cache"
	"framework/messaging"
	"github.com/go-redis/redis/v8"
	sharedrepositories "shared/repositories"

	"github.com/sirupsen/logrus"
)

type ServiceFactory struct {
	redis                   *redis.Client
	sharedRepositoryFactory sharedrepositories.RepositoryFactory
	coreRepositoryFactory   corerepositories.RepositoryFactory
	amqpMessagingFactory    messaging.AMQPFactory
	logger                  *logrus.Logger
}

func NewServiceFactory(
	redis *redis.Client,
	sharedRepositoryFactory sharedrepositories.RepositoryFactory,
	coreRepositoryFactory corerepositories.RepositoryFactory,
	amqpMessagingFactory messaging.AMQPFactory,
	logger *logrus.Logger,
) *ServiceFactory {
	return &ServiceFactory{
		redis:                   redis,
		sharedRepositoryFactory: sharedRepositoryFactory,
		coreRepositoryFactory:   coreRepositoryFactory,
		amqpMessagingFactory:    amqpMessagingFactory,
		logger:                  logger,
	}
}

func (f *ServiceFactory) NewService() *Service {
	return NewService(
		cache.NewRedisProvider(f.redis),
		f.sharedRepositoryFactory.NewClientRepository(),
		f.sharedRepositoryFactory.NewAccountRepository(),
		f.sharedRepositoryFactory.NewApplicationRepository(),
		f.sharedRepositoryFactory.NewApplicationAccountRepository(),
		f.coreRepositoryFactory.NewOutboundRepository(),
		f.coreRepositoryFactory.NewTemplateRepository(),
		f.coreRepositoryFactory.NewTemplateCacheRepository(),
		f.amqpMessagingFactory.NewAMQPPublisher(),
		f.logger,
	)
}
