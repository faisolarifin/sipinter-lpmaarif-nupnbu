package cache

import (
	"context"
	"core/entities"
	"encoding/json"
	"fmt"
	"framework/database"
	"github.com/go-redis/redis/v8"
	"github.com/pkg/errors"
	"strings"
)

type TemplateCacheRepository struct {
	conn *redis.Client
}

func NewTemplateRepository(
	conn *redis.Client,
) *TemplateCacheRepository {
	return &TemplateCacheRepository{
		conn: conn,
	}
}

func (r TemplateCacheRepository) FindByName(ctx context.Context, clientId, accountId, name string) (*entities.Template, error) {
	var result entities.Template

	key := fmt.Sprintf("%s.%s.%s-template", clientId, accountId, strings.ReplaceAll(name, " ", "_"))
	value, err := r.conn.Get(ctx, key).Result()
	if err != nil {
		if err == redis.Nil {
			return nil, errors.WithStack(
				database.NewErrorNotFound("template with client id %s, account_id %s and name %s",
					clientId, accountId, name))
		}

		return nil, errors.WithMessage(err, "TemplateCacheRepository.FindByName")
	}

	err = json.Unmarshal([]byte(value), &result)
	if err != nil {
		return nil, errors.WithMessage(err, "TemplateCacheRepository.FindByName")
	}

	return &result, nil
}

func (r TemplateCacheRepository) Create(ctx context.Context, arg *entities.CreateCacheTemplate) error {
	key := fmt.Sprintf("%s.%s.%s-template", arg.ClientId, arg.AccountId, strings.ReplaceAll(arg.Name, " ", "_"))
	_, err := r.conn.Set(ctx, key, arg.String(), arg.Ttl).Result()
	if err != nil {
		return errors.WithMessage(err, "TemplateCacheRepository.Create")
	}

	return nil
}
