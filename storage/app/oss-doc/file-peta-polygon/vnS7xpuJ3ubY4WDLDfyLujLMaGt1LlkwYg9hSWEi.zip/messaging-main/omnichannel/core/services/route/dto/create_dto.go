package dto

import (
	"encoding/json"
	"strings"
	"time"

	"framework/pointer"
	sharedentities "shared/entities"

	uuid "github.com/satori/go.uuid"
	"github.com/tidwall/gjson"
)

type CreateDto struct {
	ClientId      string
	ChannelId     string
	AccountId     string
	AccountAlias  string
	ApplicationId string
	Route         string
	Sender        *string
	Data          json.RawMessage
	CreatedAt     time.Time
}

func (d *CreateDto) MId() *string {
	var mid *string
	if d.Data != nil {
		messageType := gjson.GetBytes(d.Data, "message_type").String()
		if messageType != "outbound" {
			switch sharedentities.NewChannel(d.ChannelId) {
			case sharedentities.ChannelWhatsApp:
				mid = pointer.New(gjson.GetBytes(d.Data, "messages.0.id").String())
			case sharedentities.ChannelWhatsAppCloud:
				mid = pointer.New(gjson.GetBytes(d.Data, "entry.0.changes.0.value.messages.0.id").String())
			case sharedentities.ChannelEmail:
				mid = pointer.New(strings.Replace(uuid.NewV1().String(), "-", "", -1))
			}
		}
	}

	return mid
}

func (d *CreateDto) GetSender() *string {
	var sender *string
	if d.Sender == nil {
		messageType := gjson.GetBytes(d.Data, "message_type").String()
		switch sharedentities.NewChannel(d.ChannelId) {
		case sharedentities.ChannelWhatsApp:
			if messageType == "outbound" {
				sender = pointer.New(gjson.GetBytes(d.Data, "to").String())
			} else {
				sender = pointer.New(gjson.GetBytes(d.Data, "messages.0.from").String())
			}
		case sharedentities.ChannelWhatsAppCloud:
			if messageType == "outbound" {
				sender = pointer.New(gjson.GetBytes(d.Data, "to").String())
			} else {
				sender = pointer.New(gjson.GetBytes(d.Data, "entry.0.changes.0.value.messages.0.from").String())
			}
		case sharedentities.ChannelEmail:
			sender = pointer.New(gjson.GetBytes(d.Data, "data.from.email").String())
		}
	} else {
		sender = pointer.Copy(d.Sender)
	}

	return sender
}

func (d *CreateDto) ToMap() map[string]any {
	if d == nil {
		return nil
	}

	return map[string]any{
		"MId":           pointer.Default(d.MId(), ""),
		"ClientId":      d.ClientId,
		"ChannelId":     d.ChannelId,
		"AccountId":     d.AccountId,
		"AccountAlias":  d.AccountAlias,
		"ApplicationId": d.ApplicationId,
		"Route":         d.Route,
		"Sender":        pointer.Default(d.GetSender(), ""),
		"Data":          string(d.Data),
		"CreatedAt":     d.CreatedAt,
	}
}
