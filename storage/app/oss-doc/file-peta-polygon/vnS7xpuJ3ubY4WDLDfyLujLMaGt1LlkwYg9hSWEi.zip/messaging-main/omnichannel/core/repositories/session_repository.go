package repositories

import (
	"context"

	"core/entities"
)

type SessionRepository interface {
	Find(ctx context.Context, clientId, channelId, accountAlias, sender string) (*entities.Session, error)
	Create(ctx context.Context, args *entities.SessionCreate) (*entities.Session, error)
	Update(ctx context.Context, args *entities.SessionUpdate) (*entities.Session, error)
}
