package queries

const (
	outboundApplicationRepositorySelect = `
		o.id,
		o.xid,
		o.mid,
		o.client_id,
		o.channel_id,
		o.account_id,
		o.application_id as client_application_id,
		ca.application_id,
		o.type,
		o.recipient,
		o.data,
		o.created_at,
		o.updated_at
	`

	OutboundApplicationRepositoryFindByChannelAndAccountAndMid = `
		select
		    ` + outboundApplicationRepositorySelect + `
		from "%s".outbounds as o
		left join client_applications as ca on o.application_id = ca.id
		where
			o.client_id = :client_id
			and o.account_id = :account_id
			and o.mid = :mid
		limit 1
	`
)
