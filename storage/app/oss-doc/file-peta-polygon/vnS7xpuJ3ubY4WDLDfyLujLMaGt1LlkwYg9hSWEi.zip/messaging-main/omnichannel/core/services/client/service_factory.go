package client

import (
	"github.com/spf13/viper"
	sharedentities "shared/entities"
	sharedrepositories "shared/repositories"

	"github.com/sirupsen/logrus"
)

type ServiceFactory struct {
	conf                    *viper.Viper
	sharedRepositoryFactory sharedrepositories.RepositoryFactory
	messagingFactory        *MessagingFactory
	logger                  *logrus.Logger
}

func NewServiceFactory(
	conf *viper.Viper,
	sharedRepositoryFactory sharedrepositories.RepositoryFactory,
	messagingFactory *MessagingFactory,
	logger *logrus.Logger,
) *ServiceFactory {
	return &ServiceFactory{
		conf:                    conf,
		sharedRepositoryFactory: sharedRepositoryFactory,
		messagingFactory:        messagingFactory,
		logger:                  logger,
	}
}

func (f *ServiceFactory) NewClientService(client *sharedentities.Client) *Service {
	outboundConcurrency := f.conf.GetInt("concurrency.outbound")
	if outboundConcurrency <= 0 {
		outboundConcurrency = 1
	}

	return NewService(
		&Options{
			OutboundConcurrency: outboundConcurrency,
		},
		client,
		f.sharedRepositoryFactory.NewAccountRepository(),
		f.sharedRepositoryFactory.NewApplicationAccountRepository(),
		f.messagingFactory,
		f.logger,
	)
}
