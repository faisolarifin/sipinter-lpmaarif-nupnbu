package outbound

import (
	"context"
	"fmt"
	"framework/cache"
	"framework/loggerx"
	"github.com/tidwall/gjson"
	"strings"
	"time"

	"core/entities"
	"core/events"
	corerepositories "core/repositories"
	"core/services/outbound/dto"
	"framework/list"
	"framework/messaging"
	"framework/service"
	"github.com/jackc/pgx/v5/pgconn"
	"github.com/pkg/errors"
	"github.com/sirupsen/logrus"
	sharedentity "shared/entities"
	sharedrepositories "shared/repositories"
)

type Service struct {
	cacheProvider                cache.Provider
	clientRepository             sharedrepositories.ClientRepository
	accountRepository            sharedrepositories.AccountRepository
	applicationRepository        sharedrepositories.ApplicationRepository
	applicationAccountRepository sharedrepositories.ApplicationAccountRepository
	outboundRepository           corerepositories.OutboundRepository
	templateRepository           corerepositories.TemplateRepository
	templateCacheRepository      corerepositories.TemplateCacheRepository
	amqpPublisher                *messaging.AMQPPublisher
	logger                       *logrus.Entry
}

func NewService(
	cacheProvider cache.Provider,
	clientRepository sharedrepositories.ClientRepository,
	accountRepository sharedrepositories.AccountRepository,
	applicationRepository sharedrepositories.ApplicationRepository,
	applicationAccountRepository sharedrepositories.ApplicationAccountRepository,
	outboundRepository corerepositories.OutboundRepository,
	templateRepository corerepositories.TemplateRepository,
	templateCacheRepository corerepositories.TemplateCacheRepository,
	amqpPublisher *messaging.AMQPPublisher,
	logger *logrus.Logger,
) *Service {
	return &Service{
		cacheProvider:                cacheProvider,
		clientRepository:             clientRepository,
		accountRepository:            accountRepository,
		applicationRepository:        applicationRepository,
		applicationAccountRepository: applicationAccountRepository,
		outboundRepository:           outboundRepository,
		templateRepository:           templateRepository,
		templateCacheRepository:      templateCacheRepository,
		amqpPublisher:                amqpPublisher,
		logger: logger.WithFields(
			logrus.Fields{
				"resource": "OutboundService",
			},
		),
	}
}

func (s *Service) Create(ctx context.Context, dto *dto.CreateDto) error {
	logger := s.logger.WithField("xid", dto.XId)

	if strings.TrimSpace(dto.XId) == "" {
		return errors.WithStack(service.NewErrorValidation("id required"))
	}

	if len(dto.XId) > 100 {
		return errors.WithStack(service.NewErrorValidation("length xid must be less than 100"))
	}

	if strings.TrimSpace(dto.ClientId) == "" {
		return errors.WithStack(service.NewErrorValidation("client id required"))
	}

	if err := loggerx.Elapsed(logger, "find client exists", func() error {
		return s.clientRepository.ExistById(ctx, dto.ClientId)
	}); err != nil {
		switch errors.Cause(err).(type) {
		case *sharedentity.ErrorClientNotFound:
			return errors.WithStack(service.NewErrorValidation(err.Error()))
		default:
			return errors.WithStack(err)
		}
	}

	if strings.TrimSpace(dto.ChannelId) == "" {
		return errors.WithStack(service.NewErrorValidation("channel id required"))
	}

	if err := sharedentity.IsChannelValid(dto.ChannelId); err != nil {
		return errors.WithStack(service.NewErrorValidation(err.Error()))
	}

	if strings.TrimSpace(dto.AccountAlias) == "" {
		return errors.WithStack(service.NewErrorValidation("account alias required"))
	}

	account, err := loggerx.ElapsedWithResult[sharedentity.Account](logger, "find account", func() (*sharedentity.Account, error) {
		return cache.Cache[sharedentity.Account](
			ctx,
			s.cacheProvider,
			fmt.Sprintf("account:%s.%s.%s", dto.ClientId, dto.ChannelId, dto.AccountAlias),
			time.Hour,
			func() (*sharedentity.Account, error) {
				return s.accountRepository.FindByChannelAndAlias(ctx, dto.ClientId, dto.ChannelId, dto.AccountAlias)
			},
		)
	})
	if err != nil {
		switch errors.Cause(err).(type) {
		case *sharedentity.ErrorAccountNotFound:
			return errors.WithStack(service.NewErrorValidation(err.Error()))
		default:
			return errors.WithStack(err)
		}
	}

	if !account.IsActive {
		return errors.WithStack(service.NewErrorValidation("inactive account with channel %s and alias %s",
			dto.ChannelId, dto.AccountAlias))
	}

	if strings.TrimSpace(dto.ApplicationId) == "" {
		return errors.WithStack(service.NewErrorValidation("application id required"))
	}

	if dto.Data == nil {
		return errors.WithStack(service.NewErrorValidation("data required"))
	}

	outboundCreate := &entities.OutboundCreate{
		XId:           dto.XId,
		ClientId:      dto.ClientId,
		ChannelId:     dto.ChannelId,
		AccountId:     account.Id,
		ApplicationId: dto.ApplicationId,
		Type:          dto.Type(),
		Recipient:     dto.Recipient(),
		Data:          list.Copy(dto.Data),
		CreatedAt:     dto.CreatedAt,
	}

	outbound, err := loggerx.ElapsedWithResult[entities.Outbound](logger, "create outbound", func() (*entities.Outbound, error) {
		return s.outboundRepository.Create(ctx, outboundCreate)
	})
	if err != nil {
		switch e := errors.Cause(err).(type) {
		case *pgconn.PgError:
			if e.Code == "23505" {
				return errors.WithStack(service.NewErrorValidation(err.Error()))
			} else {
				return errors.WithStack(err)
			}
		default:
			return errors.WithStack(err)
		}
	}

	outboundEvent := &events.TransmitterOutboundEvent{
		Id:            outbound.Id,
		XId:           outbound.XId,
		ClientId:      outbound.ClientId,
		ChannelId:     outbound.ChannelId,
		AccountId:     outbound.AccountId,
		AccountAlias:  account.AccountAlias,
		ApplicationId: outbound.ApplicationId,
		Type:          outbound.Type,
		Data:          list.Copy(outbound.Data),
	}

	var (
		key      string
		template *entities.Template
	)
	switch sharedentity.NewChannel(outbound.ChannelId) {
	case sharedentity.ChannelWhatsApp, sharedentity.ChannelWhatsAppCloud:
		// key: client.channel.account_alias.outbound-type
		type_ := outbound.Type.String()
		if outbound.Type == "template" {
			templateName := strings.TrimSpace(gjson.GetBytes(outbound.Data, "template.name").String())

			template, err = loggerx.ElapsedWithResult[entities.Template](logger, "find template", func() (*entities.Template, error) {
				return cache.Cache[entities.Template](
					ctx,
					s.cacheProvider,
					fmt.Sprintf("template:%s.%s.%s", outbound.ClientId, outbound.AccountId, templateName),
					time.Hour,
					func() (*entities.Template, error) {
						return s.templateRepository.FindByName(ctx, outbound.ClientId, outbound.AccountId, templateName)
					},
				)
			})

			// routing queue based on category
			if template != nil && strings.TrimSpace(template.CategoryId) != "" {
				type_ = "template-" + strings.ToLower(template.CategoryId)
			}
		}

		key = fmt.Sprintf(
			"%s.%s.%s.outbound-%s",
			outboundEvent.ClientId,
			outboundEvent.ChannelId,
			account.AccountAlias,
			type_,
		)
	case sharedentity.ChannelEmail, sharedentity.ChannelInstagram, sharedentity.ChannelSMS:
		// key: client.channel.account_alias.outbound
		key = fmt.Sprintf(
			"%s.%s.%s.outbound",
			outboundEvent.ClientId,
			outboundEvent.ChannelId,
			account.AccountAlias,
		)
	}

	logger.WithFields(
		logrus.Fields{
			"queue": key,
			"args":  outboundEvent.ToMap(),
		},
	).Infoln("Publishing Outbound Message To Transmitter")

	//if err = s.amqpPublisher.Publish(ctx, key, outboundEvent); err != nil {
	if err = loggerx.Elapsed(logger, "publish to transmitter queue", func() error {
		return s.amqpPublisher.Publish(ctx, key, outboundEvent)
	}); err != nil {
		return errors.WithMessage(err, "Publishing Outbound Message To Transmitter")
	}

	return nil
}
