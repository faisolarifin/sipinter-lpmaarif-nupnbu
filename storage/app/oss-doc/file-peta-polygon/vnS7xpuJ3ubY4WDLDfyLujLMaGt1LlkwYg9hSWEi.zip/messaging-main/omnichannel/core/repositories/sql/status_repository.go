package sql

import (
	"context"
	"fmt"

	"core/entities"
	"core/repositories/sql/queries"
	"framework/database"

	"github.com/pkg/errors"
)

type StatusRepository struct {
	db database.Querier
}

func newStatusRepository(db database.Querier) *StatusRepository {
	return &StatusRepository{
		db: db,
	}
}

func (r *StatusRepository) Create(ctx context.Context, args *entities.StatusCreate) (*entities.Status, error) {
	namedArgs := map[string]any{
		"oid":            args.OId,
		"xid":            args.XId,
		"mid":            args.MId,
		"client_id":      args.ClientId,
		"channel_id":     args.ChannelId,
		"account_id":     args.AccountId,
		"application_id": args.ApplicationId,
		"type":           args.Type,
		"error":          args.Error,
		"data":           args.Data,
		"created_at":     args.CreatedAt,
	}

	var query string
	if args.ChannelId == "whatsapp-cloud" {
		query = queries.StatusRepositoryCreateStatusClouds
	} else {
		query = r.bindQueryChannel(queries.StatusRepositoryCreate, args.ChannelId)
	}

	query, params, err := database.NamedQuery(query, namedArgs)
	if err != nil {
		return nil, errors.WithMessage(err, "StatusRepository.Create NamedQuery")
	}

	var outbound entities.Status
	row := r.db.QueryRow(ctx, query, params...)
	if err = r.scan(row, &outbound); err != nil {
		return nil, errors.WithMessage(err, "StatusRepository.Create QueryRow")
	}

	return &outbound, nil
}

func (r *StatusRepository) bindQueryChannel(query, channelId string) string {
	return fmt.Sprintf(query, channelId)
}

func (r *StatusRepository) scan(scanner database.RowScanner, outbound *entities.Status) error {
	return scanner.Scan(
		&outbound.Id,
		&outbound.OId,
		&outbound.XId,
		&outbound.MId,
		&outbound.ClientId,
		&outbound.ChannelId,
		&outbound.AccountId,
		&outbound.ApplicationId,
		&outbound.Type,
		&outbound.Error,
		&outbound.Data,
		&outbound.CreatedAt,
	)
}
