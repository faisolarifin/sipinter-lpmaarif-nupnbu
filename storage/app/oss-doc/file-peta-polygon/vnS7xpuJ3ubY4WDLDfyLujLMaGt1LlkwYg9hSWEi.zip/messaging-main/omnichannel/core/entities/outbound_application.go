package entities

import (
	"encoding/json"
	"fmt"
	"time"
)

var (
	NilOutboundApplication = &OutboundApplication{}
)

type OutboundApplication struct {
	Id                  string
	XId                 string
	MId                 *string
	ClientId            string
	ChannelId           string
	AccountId           string
	ClientApplicationId string
	ApplicationId       string
	Type                OutboundType
	Recipient           string
	Data                json.RawMessage
	CreatedAt           time.Time
	UpdatedAt           *time.Time
}

type ErrorOutboundApplicationNotFound struct {
	message string
}

func NewErrorOutboundApplicationNotFound(format string, args ...any) *ErrorOutboundNotFound {
	return &ErrorOutboundNotFound{message: fmt.Sprintf(format, args...)}
}

func (e *ErrorOutboundApplicationNotFound) Error() string {
	return e.message
}
