package queries

const (
	outboundRepositorySelect = `
			id,
			xid,
			mid,
			client_id,
			channel_id,
			account_id,
			application_id,
			type,
			recipient,
			data,
			created_at,
			updated_at
	`

	OutboundRepositoryFindByChannelAndAccountAndId = `
		select
		    ` + outboundRepositorySelect + `
		from "%s".outbounds
		where 
			client_id = :client_id
			and account_id = :account_id
			and id = :id
		limit 1
	`

	OutboundRepositoryFindByChannelAndAccountAndXid = `
		select
		    ` + outboundRepositorySelect + `
		from "%s".outbounds
		where
			client_id = :client_id
			and account_id = :account_id
			and xid = :xid
		limit 1
	`

	OutboundRepositoryFindByChannelAndAccountAndMid = `
		select
		    ` + outboundRepositorySelect + `
		from "%s".outbounds
		where
			client_id = :client_id
			and account_id = :account_id
			and mid = :mid
		limit 1
	`

	OutboundRepositoryCreate = `
		insert into "%s".outbounds(
			xid,
			client_id,
			channel_id,
			account_id,
			application_id,
		    type,
		    recipient,
			data,
			created_at		                         
		) values (
			:xid,
			:client_id,
			:channel_id,
			:account_id,
			:application_id,
			:type,		      
			:recipient,		      
			:data::jsonb,
			:created_at		
		) returning ` +
		outboundRepositorySelect

	OutboundRepositoryUpdateMId = `
		update "%s".outbounds
		set
			mid = :mid,
			updated_at = :updated_at
		where
		    client_id = :client_id
			and id = :id
	`
)
