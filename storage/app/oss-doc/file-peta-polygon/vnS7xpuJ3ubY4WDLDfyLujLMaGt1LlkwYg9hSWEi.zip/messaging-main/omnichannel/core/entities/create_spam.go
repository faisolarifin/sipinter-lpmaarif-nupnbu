package entities

import "time"

const (
	SpamTypeTemporary = "temporary"
	SpamTypePermanent = "permanent"
)

type CreateSpam struct {
	ClientId  string
	ChannelId string
	AccountId string
	Sender    string
	Type      string
	ExpiredAt time.Time
	CreatedAt time.Time
}
