package queries

const (
	routeRepositorySelect = `
		id,
		mid, 
		client_id, 
		channel_id, 
		account_id, 
		application_id, 
		route, 
		data, 
		created_at
	`

	RouteRepositoryCreate = `
		insert into "%s".routes (
			mid, 
			client_id, 
			channel_id, 
			account_id, 
			application_id, 
			route, 
			data, 
			created_at
		) values (
			:mid, 
			:client_id, 
			:channel_id, 
			:account_id, 
			:application_id, 
			:route, 
			:data::jsonb, 
			:created_at		          
		) returning ` + routeRepositorySelect
)
