package ratelimiter

import "time"

type Options struct {
	Period time.Duration
	Limit  int64
}

func NewOptions(limit int64) *Options {
	return &Options{
		Period: time.Second,
		Limit:  limit,
	}
}

func (o *Options) SetPeriod(period time.Duration) *Options {
	o.Period = period
	return o
}

func (o *Options) SetLimit(limit int64) *Options {
	o.Limit = limit
	return o
}
