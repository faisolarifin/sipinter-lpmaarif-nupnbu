package queries

const (
	statusRepositorySelect = `
			id,
			oid,
			xid,
			mid,
			client_id,
			channel_id,
			account_id,
			application_id,
			type,
			error,
			data,
			created_at
	`

	StatusRepositoryCreate = `
		insert into "%s".statuses(
			oid,
			xid,
			mid,
			client_id,
			channel_id,
			account_id,
			application_id,
		    type,
		    error,
			data,
			created_at		                         
		) values (
			:oid,
			:xid,
			:mid,
			:client_id,
			:channel_id,
			:account_id,
			:application_id,
			:type,		      
			:error,		      
			:data::jsonb,
			:created_at		
		) returning ` +
		statusRepositorySelect

	StatusRepositoryCreateStatusClouds = `
		insert into "whatsapp-cloud".status_clouds(
			oid,
			xid,
			mid,
			client_id,
			channel_id,
			account_id,
			application_id,
		    type,
		    error,
			data,
			created_at		                         
		) values (
			:oid,
			:xid,
			:mid,
			:client_id,
			:channel_id,
			:account_id,
			:application_id,
			:type,		      
			:error,		      
			:data::jsonb,
			:created_at		
		) returning ` +
		statusRepositorySelect
)
