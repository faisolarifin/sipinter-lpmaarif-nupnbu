package events

import (
	"encoding/json"

	"framework/pointer"
	sharedentities "shared/entities"

	"github.com/tidwall/gjson"
)

type ApplicationRouteEvent struct {
	ClientId      string          `json:"client_id"`
	ChannelId     string          `json:"channel_id"`
	AccountId     string          `json:"account_id"`
	AccountAlias  string          `json:"account_alias"`
	ApplicationId string          `json:"application_id"`
	Route         string          `json:"route"`
	Sender        *string         `json:"sender"`
	Data          json.RawMessage `json:"data,omitempty"`
}

func (e *ApplicationRouteEvent) GetSender() *string {
	var sender *string
	if e.Sender == nil {
		messageType := gjson.GetBytes(e.Data, "message_type").String()
		switch sharedentities.NewChannel(e.ChannelId) {
		case sharedentities.ChannelWhatsApp:
			if messageType == "outbound" {
				sender = pointer.New(gjson.GetBytes(e.Data, "to").String())
			} else {
				sender = pointer.New(gjson.GetBytes(e.Data, "messages.0.from").String())
			}
		case sharedentities.ChannelWhatsAppCloud:
			if messageType == "outbound" {
				sender = pointer.New(gjson.GetBytes(e.Data, "to").String())
			} else {
				sender = pointer.New(gjson.GetBytes(e.Data, "entry.0.changes.0.value.messages.0.from").String())
			}
		case sharedentities.ChannelEmail:
			sender = pointer.New(gjson.GetBytes(e.Data, "data.from.email").String())
		}
	} else {
		sender = pointer.Copy(e.Sender)
	}

	return sender
}
