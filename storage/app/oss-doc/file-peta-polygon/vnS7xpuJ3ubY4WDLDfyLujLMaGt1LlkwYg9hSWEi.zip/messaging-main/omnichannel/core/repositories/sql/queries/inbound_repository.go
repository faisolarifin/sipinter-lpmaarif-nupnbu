package queries

const (
	inboundRepositorySelect = `
		id,
		mid, 
		client_id, 
		channel_id, 
		account_id, 
		application_id, 
		data, 
		created_at
	`

	InboundRepositoryCreate = `
		insert into "%s".inbounds (
			mid, 
			client_id, 
			channel_id, 
			account_id, 
			application_id, 
			data, 
		    status,
			created_at
		) values (
			:mid, 
			:client_id, 
			:channel_id, 
			:account_id, 
			:application_id, 
			:data::jsonb,
			:status,
			:created_at		          
		) returning ` + inboundRepositorySelect
)

// (regexp_replace((:data::text), '\\u0000', '', 'g'))::jsonb
