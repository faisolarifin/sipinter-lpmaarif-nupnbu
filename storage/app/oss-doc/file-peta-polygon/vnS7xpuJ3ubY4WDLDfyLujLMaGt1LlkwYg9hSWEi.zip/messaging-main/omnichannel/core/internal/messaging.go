package internal

type MessagingOptions interface {
	options()
}

type AMQPMessagingOptions struct {
	MessagingOptions
	Topic     string
	Reconnect chan struct{}
	Stop      chan struct{}
}
