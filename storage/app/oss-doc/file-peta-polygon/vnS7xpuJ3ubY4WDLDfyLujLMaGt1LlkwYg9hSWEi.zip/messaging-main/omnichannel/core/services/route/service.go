package route

import (
	"context"
	"fmt"
	"strings"

	"core/entities"
	"core/events"
	corerepositories "core/repositories"
	"core/services/route/dto"
	"framework/list"
	"framework/messaging"
	"framework/pointer"
	"framework/service"
	sharedentities "shared/entities"
	sharedrepositories "shared/repositories"

	"github.com/jackc/pgconn"
	"github.com/pkg/errors"
	"github.com/sirupsen/logrus"
)

type Service struct {
	clientRepository             sharedrepositories.ClientRepository
	accountRepository            sharedrepositories.AccountRepository
	applicationRepository        sharedrepositories.ApplicationRepository
	applicationAccountRepository sharedrepositories.ApplicationAccountRepository
	routeRepository              corerepositories.RouteRepository
	sessionRepository            corerepositories.SessionRepository
	amqpPublisher                *messaging.AMQPPublisher
	logger                       *logrus.Entry
}

func NewService(
	clientRepository sharedrepositories.ClientRepository,
	accountRepository sharedrepositories.AccountRepository,
	applicationRepository sharedrepositories.ApplicationRepository,
	applicationAccountRepository sharedrepositories.ApplicationAccountRepository,
	routeRepository corerepositories.RouteRepository,
	sessionRepository corerepositories.SessionRepository,
	amqpPublisher *messaging.AMQPPublisher,
	logger *logrus.Logger,
) *Service {
	return &Service{
		clientRepository:             clientRepository,
		accountRepository:            accountRepository,
		applicationRepository:        applicationRepository,
		applicationAccountRepository: applicationAccountRepository,
		routeRepository:              routeRepository,
		sessionRepository:            sessionRepository,
		amqpPublisher:                amqpPublisher,
		logger: logger.WithFields(
			logrus.Fields{
				"resource": "RouteService",
			},
		),
	}
}

func (s *Service) Create(ctx context.Context, dto *dto.CreateDto) error {
	if dto.MId() != nil && strings.TrimSpace(*dto.MId()) == "" {
		return errors.WithStack(service.NewErrorValidation("mid required"))
	}

	if strings.TrimSpace(dto.ClientId) == "" {
		return errors.WithStack(service.NewErrorValidation("client id required"))
	}

	if strings.TrimSpace(dto.ChannelId) == "" {
		return errors.WithStack(service.NewErrorValidation("channel id required"))
	}

	if strings.TrimSpace(dto.AccountId) == "" && strings.TrimSpace(dto.AccountAlias) == "" {
		return errors.WithStack(service.NewErrorValidation("account id required"))
	}

	if strings.TrimSpace(dto.ApplicationId) == "" && strings.TrimSpace(dto.ApplicationId) == "" {
		return errors.WithStack(service.NewErrorValidation("application id required"))
	}

	if strings.TrimSpace(dto.Route) == "" && strings.TrimSpace(dto.Route) == "" {
		return errors.WithStack(service.NewErrorValidation("route required"))
	}

	if err := s.clientRepository.ExistById(ctx, dto.ClientId); err != nil {
		switch errors.Cause(err).(type) {
		case *sharedentities.ErrorClientNotFound:
			return errors.WithStack(service.NewErrorValidation(err.Error()))
		default:
			return errors.WithStack(err)
		}
	}

	if err := sharedentities.IsChannelValid(dto.ChannelId); err != nil {
		return errors.WithStack(service.NewErrorValidation(err.Error()))
	}

	var (
		account *sharedentities.Account
		err     error
	)
	switch sharedentities.NewChannel(dto.ChannelId) {
	case sharedentities.ChannelEmail:
		account, err = s.accountRepository.FindByChannelAndId(ctx, dto.ClientId, dto.ChannelId, dto.AccountId)
		if err != nil {
			switch errors.Cause(err).(type) {
			case *sharedentities.ErrorAccountNotFound:
				return errors.WithStack(service.NewErrorValidation(err.Error()))
			default:
				return errors.WithStack(err)
			}
		}
	default:
		account, err = s.accountRepository.FindByChannelAndAlias(ctx, dto.ClientId, dto.ChannelId, dto.AccountAlias)
		if err != nil {
			switch errors.Cause(err).(type) {
			case *sharedentities.ErrorAccountNotFound:
				return errors.WithStack(service.NewErrorValidation(err.Error()))
			default:
				return errors.WithStack(err)
			}
		}
	}

	if !account.IsActive {
		return errors.WithStack(service.NewErrorValidation("inactive account with channel %s and alias %s",
			dto.ChannelId, dto.AccountAlias))
	}

	sourceApplication, err := s.applicationAccountRepository.FindByApplicationAndAccount(ctx, dto.ClientId, dto.ApplicationId, account.Id)
	if err != nil {
		switch errors.Cause(err).(type) {
		case *sharedentities.ErrorApplicationAccountNotFound:
			return errors.WithStack(service.NewErrorValidation(err.Error()))
		default:
			return errors.WithStack(err)
		}
	}

	routeApplication, err := s.applicationAccountRepository.FindByApplicationAndAccount(ctx, dto.ClientId, dto.Route, account.Id)
	if err != nil {
		switch errors.Cause(err).(type) {
		case *sharedentities.ErrorApplicationAccountNotFound:
			return errors.WithStack(service.NewErrorValidation(err.Error()))
		default:
			return errors.WithStack(err)
		}
	}

	s.logger.WithField("args", map[string]any{
		"client_id":     dto.ClientId,
		"channel_id":    dto.ChannelId,
		"account_alias": dto.AccountAlias,
		"sender":        pointer.Default(dto.GetSender(), ""),
	}).Infoln("Find Session By Sender")
	session, err := s.sessionRepository.Find(ctx, dto.ClientId, dto.ChannelId, dto.AccountAlias, pointer.Default(dto.GetSender(), ""))
	if err != nil {
		switch errors.Cause(err).(type) {
		case *entities.ErrorSessionNotFound:
			s.logger.WithField("args", map[string]any{
				"client_id":     dto.ClientId,
				"channel_id":    dto.ChannelId,
				"account_alias": dto.AccountAlias,
				"sender":        pointer.Default(dto.GetSender(), ""),
			}).WithError(err).Warningln("SessionRepository.Find")
		default:
			return errors.WithStack(err)
		}
	}

	if session == nil {
		sessionCreate := &entities.SessionCreate{
			ClientId:      dto.ClientId,
			ChannelId:     dto.ChannelId,
			AccountAlias:  dto.AccountAlias,
			ApplicationId: dto.Route,
			Sender:        pointer.Default(dto.GetSender(), ""),
			CreatedAt:     dto.CreatedAt,
		}
		s.logger.WithField("args", sessionCreate.ToMap()).Infoln("Create Session")
		session, err = s.sessionRepository.Create(ctx, sessionCreate)
		if err != nil {
			switch e := errors.Cause(err).(type) {
			case *pgconn.PgError:
				if e.Code == "23505" {
					session, err = s.sessionRepository.Find(ctx, dto.ClientId, dto.ChannelId, dto.AccountAlias, pointer.Default(dto.GetSender(), ""))
					if err != nil {
						s.logger.WithField("args", sessionCreate.ToMap()).WithError(err).Warningln("Create Session")
						return errors.WithStack(err)
					}
				} else {
					s.logger.WithField("args", sessionCreate.ToMap()).WithError(err).Errorln("Create Session")
					return errors.WithStack(err)
				}
			default:
				return errors.WithStack(err)
			}
		}
	} else {
		s.logger.WithFields(logrus.Fields{
			"current_application": session.ApplicationId,
			"source_application":  sourceApplication.ApplicationId,
			"route_application":   routeApplication.ApplicationId,
		})

		if session.ApplicationId == "helpdesk" {
			if sourceApplication.ApplicationId != "helpdesk" {
				return errors.WithStack(service.NewErrorValidation(
					fmt.Sprintf("can't route application session %s, source %s, destination %s",
						session.ApplicationId, sourceApplication.ApplicationId, routeApplication.ApplicationId)))
			}
		}

		sessionUpdate := &entities.SessionUpdate{
			ClientId:      dto.ClientId,
			ChannelId:     dto.ChannelId,
			AccountAlias:  dto.AccountAlias,
			ApplicationId: dto.Route,
			Sender:        pointer.Default(dto.GetSender(), ""),
			UpdatedAt:     dto.CreatedAt,
		}
		s.logger.WithField("args", sessionUpdate.ToMap()).Infoln("Update Session")
		session, err = s.sessionRepository.Update(ctx, sessionUpdate)
		if err != nil {
			s.logger.WithField("args", sessionUpdate.ToMap()).WithError(err).Errorln("Update Session")
			return errors.WithStack(err)
		}
	}

	routeCreate := &entities.RouteCreate{
		MId:           dto.MId(),
		ClientId:      dto.ClientId,
		ChannelId:     dto.ChannelId,
		AccountId:     account.Id,
		ApplicationId: session.ClientApplicationId,
		Route:         dto.Route,
		Data:          dto.Data,
		CreatedAt:     dto.CreatedAt,
	}
	route, err := s.routeRepository.Create(ctx, routeCreate)
	if err != nil {
		return errors.WithStack(err)
	}

	if dto.Data != nil {
		inboundEvent := &events.ApplicationInboundEvent{
			Id:            route.Id,
			MId:           pointer.Default(route.MId, ""),
			ClientId:      route.ClientId,
			ChannelId:     route.ChannelId,
			AccountId:     route.AccountId,
			AccountAlias:  account.AccountAlias,
			ApplicationId: pointer.New(route.ApplicationId),
			Data:          list.Copy(route.Data),
			CreatedAt:     route.CreatedAt,
		}
		applicationId := inboundEvent.ApplicationId
		if applicationId == nil {
			applicationId = pointer.New(session.ClientApplicationId)
		}

		// key: client.channel.account-alias.inbound.application
		key := fmt.Sprintf(
			"%s.%s.%s.inbound.%s",
			inboundEvent.ClientId,
			inboundEvent.ChannelId,
			account.AccountAlias,
			*applicationId,
		)
		s.logger.WithFields(
			logrus.Fields{
				"queue": key,
				"args":  inboundEvent.ToMap(),
			},
		).Infoln("Publishing Inbound Message To Application")
		if err = s.amqpPublisher.Publish(ctx, key, inboundEvent); err != nil {
			return errors.WithMessage(err, "Publishing Inbound Message To Application")
		}
	}

	return nil
}
