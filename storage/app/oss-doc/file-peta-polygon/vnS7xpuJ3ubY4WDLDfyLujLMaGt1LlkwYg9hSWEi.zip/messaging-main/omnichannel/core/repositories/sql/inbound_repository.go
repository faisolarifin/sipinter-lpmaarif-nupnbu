package sql

import (
	"context"
	"fmt"

	"core/entities"
	"core/repositories/sql/queries"
	"framework/database"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/pkg/errors"
)

type InboundRepository struct {
	db database.Querier
}

func newInboundRepository(db *pgxpool.Pool) *InboundRepository {
	return &InboundRepository{
		db: db,
	}
}

func (r *InboundRepository) SetTx(tx pgx.Tx) {
	r.db = tx
}

func (r *InboundRepository) Create(ctx context.Context, args *entities.InboundCreate) (*entities.Inbound, error) {
	namedArgs := map[string]any{
		"mid":            args.MId,
		"client_id":      args.ClientId,
		"channel_id":     args.ChannelId,
		"account_id":     args.AccountId,
		"application_id": args.ApplicationId,
		"data":           args.Data,
		"status":         args.Status,
		"created_at":     args.CreatedAt,
	}

	query := r.bindQueryChannel(queries.InboundRepositoryCreate, args.ChannelId)
	query, params, err := database.NamedQuery(query, namedArgs)
	if err != nil {
		return nil, errors.WithMessage(err, "InboundRepository.Create NamedQuery")
	}

	var inbound entities.Inbound
	row := r.db.QueryRow(ctx, query, params...)
	if err = r.scan(row, &inbound); err != nil {
		return nil, errors.WithMessage(err, "InboundRepository.Create QueryRow")
	}

	return &inbound, nil
}

func (r *InboundRepository) bindQueryChannel(query, channelId string) string {
	return fmt.Sprintf(query, channelId)
}

func (r *InboundRepository) scan(scanner database.RowScanner, inbound *entities.Inbound) error {
	return scanner.Scan(
		&inbound.Id,
		&inbound.MId,
		&inbound.ClientId,
		&inbound.ChannelId,
		&inbound.AccountId,
		&inbound.ApplicationId,
		&inbound.Data,
		&inbound.CreatedAt,
	)
}
