package events

import (
	"encoding/json"
	"strings"

	"shared/entities"

	"github.com/tidwall/gjson"
)

type ReceiverInboundEvent struct {
	ClientId     string          `json:"client_id"`
	AccountId    string          `json:"account_id"`
	AccountAlias string          `json:"channel_account_alias"`
	Channel      string          `json:"channel"`
	ChannelId    string          `json:"channel_id"`
	Data         json.RawMessage `json:"data"`
}

func (e *ReceiverInboundEvent) GetChannelId() string {
	channelId := e.Channel
	if strings.TrimSpace(channelId) == "" {
		channelId = e.ChannelId
	}

	return channelId
}

func (e *ReceiverInboundEvent) Sender() string {
	var sender string
	switch entities.NewChannel(e.GetChannelId()) {
	case entities.ChannelWhatsApp:
		sender = gjson.GetBytes(e.Data, "messages.0.from").String()
	case entities.ChannelWhatsAppCloud:
		sender = gjson.GetBytes(e.Data, "entry.0.changes.0.value.messages.0.from").String()
	case entities.ChannelEmail:
		sender = gjson.GetBytes(e.Data, "data.from.email").String()
	case entities.ChannelInstagram:
		sender = gjson.GetBytes(e.Data, "entry.0.messaging.0.recipient.id").String()
	}

	return sender
}
