package sql

import (
	"core/repositories"
	"core/repositories/cache"
	"github.com/go-redis/redis/v8"

	"github.com/jackc/pgx/v5/pgxpool"
)

type RepositoryFactory struct {
	db   *pgxpool.Pool
	conn *redis.Client
}

func NewRepositoryFactory(db *pgxpool.Pool, conn *redis.Client) *RepositoryFactory {
	return &RepositoryFactory{db: db, conn: conn}
}

func (f *RepositoryFactory) NewInboundRepository() repositories.InboundRepository {
	return newInboundRepository(f.db)
}

func (f *RepositoryFactory) NewOutboundRepository() repositories.OutboundRepository {
	return newOutboundRepository(f.db)
}

func (f *RepositoryFactory) NewOutboundApplicationRepository() repositories.OutboundApplicationRepository {
	return newOutboundApplicationRepository(f.db)
}

func (f *RepositoryFactory) NewSessionRepository() repositories.SessionRepository {
	return newSessionRepository(f.db)
}

func (f *RepositoryFactory) NewStatusRepository() repositories.StatusRepository {
	return newStatusRepository(f.db)
}

func (f *RepositoryFactory) NewRouteRepository() repositories.RouteRepository {
	return newRouteRepository(f.db)
}

func (f *RepositoryFactory) NewClientApplicationRepository() repositories.ClientApplicationRepository {
	return newClientApplicationRepository(f.db)
}

func (f *RepositoryFactory) NewWhatsAppSessionRepository() repositories.WhatsAppSessionRepository {
	return newWhatsAppSessionRepository(f.db)
}

func (f *RepositoryFactory) NewSpamRepository() repositories.SpamRepository {
	return newSpamRepository(f.db)
}

func (f *RepositoryFactory) NewTemplateRepository() repositories.TemplateRepository {
	return newTemplateRepository(f.db)
}

func (f *RepositoryFactory) NewTemplateCacheRepository() repositories.TemplateCacheRepository {
	return cache.NewTemplateRepository(f.conn)
}
