package inbound

import (
	"context"
	corerepositories "core/repositories"
	"github.com/sirupsen/logrus"
	sharedrepositories "shared/repositories"
	"sync"
)

func NewSpamJanitorService(
	accountRepository sharedrepositories.AccountRepository,
	spamRepository corerepositories.SpamRepository,
	logger *logrus.Logger,
	cleanupLimit int,
) *SpamJanitorService {
	return &SpamJanitorService{
		accountRepository: accountRepository,
		spamRepository:    spamRepository,
		logger:            logger,
		cleanupLimit:      cleanupLimit,
	}
}

type SpamJanitorService struct {
	accountRepository sharedrepositories.AccountRepository
	spamRepository    corerepositories.SpamRepository
	logger            *logrus.Logger
	cleanupLimit      int
}

func (s *SpamJanitorService) cleanup(ctx context.Context, wg *sync.WaitGroup, clientId, channelId string, limit int) {
	defer wg.Done()
	deleted, err := s.spamRepository.DeleteExpired(ctx, clientId, channelId, limit)
	if err != nil {
		s.logger.WithFields(logrus.Fields{"client_id": clientId, "channel_id": channelId}).
			WithError(err).Errorln("delete expired spam")
		return
	}

	s.logger.WithFields(logrus.Fields{"client_id": clientId, "channel_id": channelId, "deleted": deleted}).
		Infoln("expired spam deleted")
}

func (s *SpamJanitorService) Cleanup(ctx context.Context) {
	s.logger.Infoln("start cleanup account expired spams")

	accounts, err := s.accountRepository.GetAllExceptChannels(ctx, []string{"sms", "phone"})
	if err != nil {
		s.logger.WithError(err).Errorln("get account expired spams")
		return
	}

	wg := &sync.WaitGroup{}
	for _, account := range accounts {
		wg.Add(1)
		go s.cleanup(ctx, wg, account.ClientId, account.ChannelId, s.cleanupLimit)
	}
	wg.Wait()

	s.logger.Infoln("finish cleanup account expired spams")
}
