package server

import (
	corerepositories "core/repositories"
	coreclient "core/services/client"
	coreinbound "core/services/inbound"
	coremanager "core/services/manager"
	coreoutbound "core/services/outbound"
	coreroute "core/services/route"
	corestatus "core/services/status"
	"framework/amqpx"
	"framework/messaging"
	sharedrepositories "shared/repositories"

	"github.com/go-redis/redis/v8"
	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/sirupsen/logrus"
	"github.com/spf13/viper"
)

type CustomContext struct {
	conf                       *viper.Viper
	logger                     *logrus.Logger
	db                         *pgxpool.Pool
	redis                      *redis.Client
	amqpReader                 *amqpx.Pool
	amqpWriter                 *amqpx.Pool
	coreRepositoryFactory      corerepositories.RepositoryFactory
	sharedRepositoryFactory    sharedrepositories.RepositoryFactory
	amqpMessagingFactory       messaging.AMQPFactory
	coreInboundServiceFactory  *coreinbound.ServiceFactory
	coreOutboundServiceFactory *coreoutbound.ServiceFactory
	coreStatusServiceFactory   *corestatus.ServiceFactory
	coreRouteServiceFactory    *coreroute.ServiceFactory
	coreClientMessagingFactory *coreclient.MessagingFactory
	coreClientServiceFactory   *coreclient.ServiceFactory
	coreManagerServiceFactory  *coremanager.ServiceFactory
}

func (c *CustomContext) Config() *viper.Viper {
	return c.conf
}

func (c *CustomContext) Logger() *logrus.Logger {
	return c.logger
}

func (c *CustomContext) DB() *pgxpool.Pool {
	return c.db
}

func (c *CustomContext) Redis() *redis.Client {
	return c.redis
}

func (c *CustomContext) AMQPReader() *amqpx.Pool {
	return c.amqpReader
}

func (c *CustomContext) AMQPWriter() *amqpx.Pool {
	return c.amqpWriter
}

func (c *CustomContext) AMQPMessagingFactory() messaging.AMQPFactory {
	return c.amqpMessagingFactory
}

func (c *CustomContext) CoreRepositoryFactory() corerepositories.RepositoryFactory {
	return c.coreRepositoryFactory
}

func (c *CustomContext) SharedRepositoryFactory() sharedrepositories.RepositoryFactory {
	return c.sharedRepositoryFactory
}

func (c *CustomContext) CoreInboundServiceFactory() *coreinbound.ServiceFactory {
	return c.coreInboundServiceFactory
}

func (c *CustomContext) CoreOutboundServiceFactory() *coreoutbound.ServiceFactory {
	return c.coreOutboundServiceFactory
}

func (c *CustomContext) CoreStatusServiceFactory() *corestatus.ServiceFactory {
	return c.coreStatusServiceFactory
}

func (c *CustomContext) CoreRouteServiceFactory() *coreroute.ServiceFactory {
	return c.coreRouteServiceFactory
}

func (c *CustomContext) CoreClientMessagingFactory() *coreclient.MessagingFactory {
	return c.coreClientMessagingFactory
}

func (c *CustomContext) CoreClientServiceFactory() *coreclient.ServiceFactory {
	return c.coreClientServiceFactory
}

func (c *CustomContext) CoreManagerServiceFactory() *coremanager.ServiceFactory {
	return c.coreManagerServiceFactory
}
