package sql

import (
	"context"
	"core/entities"
	"fmt"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgconn"
	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/jackc/pgxutil"
	"github.com/pkg/errors"
)

func newSpamRepository(conn *pgxpool.Pool) *SpamRepository {
	return &SpamRepository{conn: conn}
}

type SpamRepository struct {
	conn *pgxpool.Pool
}

func (r *SpamRepository) IsSpam(ctx context.Context, clientId, channelId, accountId, sender string) (bool, error) {
	query := `
		select exists(select sender
					  from "%s".spams
					  where client_id = @client_id
						and channel_id = @channel_id
						and account_id = @account_id
						and sender = @sender) as is_spam
	`
	query = fmt.Sprintf(query, channelId)
	params := pgx.NamedArgs{
		"client_id":  clientId,
		"channel_id": channelId,
		"account_id": accountId,
		"sender":     sender,
	}

	result, err := pgxutil.SelectValue[bool](ctx, r.conn, query, params)
	if err != nil {
		return false, errors.WithStack(err)
	}

	return result, nil
}

func (r *SpamRepository) Create(ctx context.Context, args *entities.CreateSpam) error {
	query := `
		insert into "%s".spams(client_id, channel_id, account_id, sender, type, expired_at, created_at)
			values (@client_id, @channel_id, @account_id, @sender, @type, @expired_at, @created_at)
	`
	query = fmt.Sprintf(query, args.ChannelId)
	params := pgx.NamedArgs{
		"client_id":  args.ClientId,
		"channel_id": args.ChannelId,
		"account_id": args.AccountId,
		"sender":     args.Sender,
		"type":       args.Type,
		"expired_at": args.ExpiredAt,
		"created_at": args.CreatedAt,
	}
	_, err := r.conn.Exec(ctx, query, params)
	if err != nil {
		switch e := err.(type) {
		case *pgconn.PgError:
			if e.Code != "23505" {
				return errors.WithStack(err)
			}
		default:
			return errors.WithStack(err)
		}
	}

	return nil
}

func (r *SpamRepository) DeleteExpired(ctx context.Context, clientId, channelId string, limit int) (int64, error) {
	query := `
		with data as (
			select id
			from "%s".spams
			where client_id = @client_id
				and channel_id = @channel_id
				and type = 'temporary'
				and extract(epoch from expired_at at time zone 'UTC') < extract(epoch from now() at time zone 'UTC')
			limit @limit
		)
		delete from "whatsapp-cloud".spams
			where id in(select id from data)
	`
	query = fmt.Sprintf(query, channelId)
	params := pgx.NamedArgs{
		"client_id":  clientId,
		"channel_id": channelId,
		"limit":      limit,
	}
	exec, err := r.conn.Exec(ctx, query, params)
	if err != nil {
		return 0, errors.WithStack(err)
	}

	return exec.RowsAffected(), nil
}
