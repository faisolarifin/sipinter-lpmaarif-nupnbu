package repositories

import (
	"context"
	"core/entities"
)

type TemplateRepository interface {
	FindByName(ctx context.Context, clientId, accountId, name string) (*entities.Template, error)
}
