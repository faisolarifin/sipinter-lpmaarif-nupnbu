package cmd

import (
	"os"
	"os/signal"

	"core/cmd/server"

	"github.com/spf13/cobra"
)

func newRunCmd() *cobra.Command {
	cmd := &cobra.Command{
		Use:   "run",
		Short: "Run Coster V3 Core",
		Run: func(cmd *cobra.Command, args []string) {
			terminate := make(chan os.Signal, 1)
			signal.Notify(terminate, os.Interrupt, os.Kill)
			svr := server.New()
			svr.Start()
			<-terminate
			svr.Stop()
		},
	}

	return cmd
}
