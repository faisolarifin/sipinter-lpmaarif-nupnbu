package entities

import (
	"encoding/json"
	"fmt"
	"time"
)

var (
	NilOutbound = &Outbound{}
)

type Outbound struct {
	Id            string
	XId           string
	MId           *string
	ClientId      string
	ChannelId     string
	AccountId     string
	ApplicationId string
	Type          OutboundType
	Recipient     string
	Data          json.RawMessage
	CreatedAt     time.Time
	UpdatedAt     *time.Time
}

type OutboundCreate struct {
	XId           string
	ClientId      string
	ChannelId     string
	AccountId     string
	ApplicationId string
	Type          OutboundType
	Recipient     string
	Data          json.RawMessage
	CreatedAt     time.Time
}

type OutboundUpdateMid struct {
	Id        string
	MId       string
	ClientId  string
	ChannelId string
	UpdatedAt time.Time
}

type ErrorOutboundNotFound struct {
	message string
}

func NewErrorOutboundNotFound(format string, args ...any) *ErrorOutboundNotFound {
	return &ErrorOutboundNotFound{message: fmt.Sprintf(format, args...)}
}

func (e *ErrorOutboundNotFound) Error() string {
	return e.message
}
