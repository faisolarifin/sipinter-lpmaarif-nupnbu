package entities

const (
	RoutingTypeUnknown RoutingType = iota
	RoutingTypeSession
	RoutingTypeOutbound
	RoutingTypeApplication
)

type RoutingType int

func (t RoutingType) String() string {
	switch t {
	case RoutingTypeSession:
		return "session"
	case RoutingTypeOutbound:
		return "outbound"
	case RoutingTypeApplication:
		return "application"
	default:
		return ""
	}
}
