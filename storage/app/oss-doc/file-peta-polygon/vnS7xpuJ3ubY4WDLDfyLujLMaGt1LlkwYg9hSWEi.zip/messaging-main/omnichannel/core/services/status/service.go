package status

import (
	"context"
	"fmt"
	"github.com/jackc/pgx/v5/pgconn"
	amqp "github.com/rabbitmq/amqp091-go"
	"github.com/tidwall/gjson"
	"strings"
	"time"

	"core/entities"
	"core/events"
	corerepositories "core/repositories"
	"core/services/status/dto"
	"framework/list"
	"framework/messaging"
	"framework/pointer"
	sharedentities "shared/entities"
	sharedrepositories "shared/repositories"

	"github.com/pkg/errors"
	"github.com/sirupsen/logrus"
)

type Service struct {
	clientRepository          sharedrepositories.ClientRepository
	accountRepository         sharedrepositories.AccountRepository
	statusRepository          corerepositories.StatusRepository
	outboundRepository        corerepositories.OutboundRepository
	whatsAppSessionRepository corerepositories.WhatsAppSessionRepository
	amqpPublisher             *messaging.AMQPPublisher
	logger                    *logrus.Entry
}

func NewService(
	clientRepository sharedrepositories.ClientRepository,
	accountRepository sharedrepositories.AccountRepository,
	statusRepository corerepositories.StatusRepository,
	outboundRepository corerepositories.OutboundRepository,
	whatsAppSessionRepository corerepositories.WhatsAppSessionRepository,
	amqpPublisher *messaging.AMQPPublisher,
	logger *logrus.Logger,
) *Service {
	return &Service{
		clientRepository:          clientRepository,
		accountRepository:         accountRepository,
		statusRepository:          statusRepository,
		outboundRepository:        outboundRepository,
		whatsAppSessionRepository: whatsAppSessionRepository,
		amqpPublisher:             amqpPublisher,
		logger: logger.WithFields(
			logrus.Fields{
				"resource": "StatusService",
			},
		),
	}
}

func (s *Service) Create(ctx context.Context, dto *dto.CreateDto) error {
	var statusError *entities.StatusError

	if strings.TrimSpace(dto.ClientId) == "" {
		statusError = pointer.New(entities.StatusErrorMissingClientId)
	}

	if strings.TrimSpace(dto.ChannelId) == "" {
		statusError = pointer.New(entities.StatusErrorMissingChannelId)
	}

	if strings.TrimSpace(dto.AccountAlias) == "" {
		statusError = pointer.New(entities.StatusErrorMissingAccountAlias)
	}

	if err := s.clientRepository.ExistById(ctx, dto.ClientId); err != nil {
		switch errors.Cause(err).(type) {
		case *sharedentities.ErrorClientNotFound:
			statusError = pointer.New(entities.StatusErrorClientIdNotFound)
		default:
			return errors.WithStack(err)
		}
	}

	if err := sharedentities.IsChannelValid(dto.ChannelId); err != nil {
		statusError = pointer.New(entities.StatusErrorInvalidChannelId)
	}

	account, err := s.accountRepository.FindByChannelAndAlias(ctx, dto.ClientId, dto.ChannelId, dto.AccountAlias)
	if err != nil {
		switch errors.Cause(err).(type) {
		case *sharedentities.ErrorAccountNotFound:
			statusError = pointer.New(entities.StatusErrorAccountIdNotFound)
		default:
			return errors.WithStack(err)
		}
	}

	if !account.IsActive {
		statusError = pointer.New(entities.StatusErrorInactiveAccountId)
	}

	if strings.TrimSpace(dto.MId()) == "" {
		statusError = pointer.New(entities.StatusErrorMissingMId)
	}

	outbound, err := s.outboundRepository.FindByChannelAndAccountAndMid(ctx, dto.ClientId, dto.ChannelId, account.Id, dto.MId())
	if err != nil {
		switch errors.Cause(err).(type) {
		case *entities.ErrorOutboundNotFound:
			outbound = entities.NilOutbound
			statusError = pointer.New(entities.StatusErrorOutboundNotFound)
		default:
			return errors.WithStack(err)
		}
	}

	statusCreate := &entities.StatusCreate{
		OId:           outbound.Id,
		XId:           outbound.XId,
		MId:           dto.MId(),
		ClientId:      dto.ClientId,
		ChannelId:     dto.ChannelId,
		AccountId:     account.Id,
		ApplicationId: outbound.ApplicationId,
		Type:          dto.Type(),
		Error:         statusError,
		Data:          dto.Data,
		CreatedAt:     dto.CreatedAt,
	}
	status, err := s.statusRepository.Create(ctx, statusCreate)
	if err != nil {
		switch e := errors.Cause(err).(type) {
		case *pgconn.PgError:
			// handle meta sent duplicate delivery report
			if e.Code == "23505" {
				s.logger.WithError(err).WithFields(logrus.Fields{
					"mid": dto.MId(), "type": dto.Type()}).Warningln("duplicate delivery report")
				return nil
			}
		}
		return errors.WithStack(err)
	}

	// update whatsapp session pricing
	if list.In(dto.ChannelId, []string{"whatsapp", "whatsapp-cloud"}) && dto.Type() == entities.StatusTypeSent {
		var (
			recipient       string
			conversationId  string
			pricingCategory string
			expiredAt       time.Time
		)
		switch sharedentities.NewChannel(dto.ChannelId) {
		case sharedentities.ChannelWhatsApp:
			recipient = gjson.GetBytes(dto.Data, "statuses.0.recipient_id").String()
			conversationId = gjson.GetBytes(dto.Data, "statuses.0.conversation.id").String()
			pricingCategory = gjson.GetBytes(dto.Data, "statuses.0.pricing.category").String()
			expiredAt = time.Unix(gjson.GetBytes(dto.Data, "statuses.0.conversation.expiration_timestamp").Int(), 0).Local()
		case sharedentities.ChannelWhatsAppCloud:
			recipient = gjson.GetBytes(dto.Data, "entry.0.changes.0.value.statuses.0.recipient_id").String()
			conversationId = gjson.GetBytes(dto.Data, "entry.0.changes.0.value.statuses.0.conversation.id").String()
			pricingCategory = gjson.GetBytes(dto.Data, "entry.0.changes.0.value.statuses.0.pricing.category").String()
			expiredAt = time.Unix(gjson.GetBytes(dto.Data, "entry.0.changes.0.value.statuses.0.conversation.expiration_timestamp").Int(), 0).Local()
		}

		err = s.whatsAppSessionRepository.CreateOrUpdate(ctx, dto.ChannelId, &entities.CreateOrUpdateWhatsAppSession{
			ClientId:        dto.ClientId,
			ClientAccountId: account.Id,
			Recipient:       recipient,
			ConversationId:  conversationId,
			PricingCategory: pricingCategory,
			ExpiredAt:       expiredAt,
			DateTime:        time.Now().Local(),
		})
		if err != nil {
			s.logger.WithError(err).Errorln("update whatsapp recipient session")
		}
	}

	if statusError != nil {
		s.logger.WithFields(
			logrus.Fields{
				"args": status.ToMap(),
			},
		).Infoln("Not Publishing Status Message To Application Due To Status Error")
		return nil
	}

	statusEvent := &events.ApplicationStatusEvent{
		Id:            status.Id,
		OId:           status.OId,
		XId:           status.XId,
		MId:           status.MId,
		ClientId:      status.ClientId,
		ChannelId:     status.ChannelId,
		AccountId:     status.AccountId,
		AccountAlias:  account.AccountAlias,
		ApplicationId: status.ApplicationId,
		Type:          status.Type.String(),
		Data:          list.Copy(status.Data),
		Outbound: &events.Outbound{
			Type:      outbound.Type.String(),
			Recipient: outbound.Recipient,
			Data:      list.Copy(outbound.Data),
		},
		CreatedAt: status.CreatedAt,
	}

	// key: client.channel.account-alias.status.application
	key := fmt.Sprintf(
		"%s.%s.%s.status.%s",
		statusEvent.ClientId,
		statusEvent.ChannelId,
		account.AccountAlias,
		statusEvent.ApplicationId,
	)
	s.logger.WithFields(
		logrus.Fields{
			"queue": key,
			"args":  statusEvent.ToMap(),
		},
	).Infoln("Publishing Status Message To Application")
	if err = s.amqpPublisher.Publish(ctx, key, statusEvent); err != nil {
		return errors.WithMessage(err, "Publishing Status Message To Application")
	}

	// publish status event to all consumer
	exchangeEvent := &events.ExchangeStatusEvent{
		Id:            status.Id,
		OId:           status.OId,
		XId:           status.XId,
		MId:           status.MId,
		ClientId:      status.ClientId,
		ChannelId:     status.ChannelId,
		AccountId:     status.AccountId,
		AccountAlias:  account.AccountAlias,
		ApplicationId: status.ApplicationId,
		Type:          status.Type.String(),
		Data:          list.Copy(status.Data),
		Outbound: &events.ExchangeOutbound{
			Type:      outbound.Type.String(),
			Recipient: outbound.Recipient,
			Data:      list.Copy(outbound.Data),
			CreatedAt: outbound.CreatedAt,
			UpdatedAt: outbound.UpdatedAt,
		},
		CreatedAt: status.CreatedAt,
	}
	// key: client.channel.account-alias.status.exchange
	key = fmt.Sprintf(
		"%s.%s.%s.status.exchange",
		statusEvent.ClientId,
		statusEvent.ChannelId,
		account.AccountAlias,
	)
	s.logger.WithFields(
		logrus.Fields{
			"queue": key,
			"args":  exchangeEvent.ToMap(),
		},
	).Infoln("Publishing Status Message To Exchange")
	if err = s.amqpPublisher.ExchangePublish(ctx, key, amqp.ExchangeFanout, exchangeEvent); err != nil {
		return errors.WithMessage(err, "Publishing Status Message To Exchange")
	}

	return nil
}
