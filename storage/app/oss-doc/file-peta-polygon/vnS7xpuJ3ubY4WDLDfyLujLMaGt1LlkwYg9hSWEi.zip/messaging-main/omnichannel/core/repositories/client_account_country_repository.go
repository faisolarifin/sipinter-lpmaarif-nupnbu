package repositories

import (
	"context"
	"core/entities"
)

type ClientAccountCountryRepository interface {
	FindByPrefix(ctx context.Context, accountId, prefix string) (*entities.ClientAccountCountry, error)
	ExistsByPrefix(ctx context.Context, accountId, prefix string) (bool, error)
}
