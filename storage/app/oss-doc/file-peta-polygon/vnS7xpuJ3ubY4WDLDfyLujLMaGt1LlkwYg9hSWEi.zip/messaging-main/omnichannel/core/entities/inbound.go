package entities

import (
	"encoding/json"
	"time"
)

const (
	StatusAllowed   = "allowed"
	StatusForbidden = "forbidden"
	StatusSpam      = "spam"
)

type Inbound struct {
	Id            string
	MId           string
	ClientId      string
	ChannelId     string
	AccountId     string
	ApplicationId *string
	Data          json.RawMessage
	CreatedAt     time.Time
}

type InboundCreate struct {
	MId           string
	ClientId      string
	ChannelId     string
	AccountId     string
	ApplicationId string
	Data          json.RawMessage
	Status        string
	CreatedAt     time.Time
}
