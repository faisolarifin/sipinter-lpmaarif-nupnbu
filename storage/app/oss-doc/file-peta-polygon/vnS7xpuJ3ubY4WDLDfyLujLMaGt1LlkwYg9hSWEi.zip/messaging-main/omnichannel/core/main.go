package main

import "core/cmd"

func main() {
	cmd.Execute()
}
