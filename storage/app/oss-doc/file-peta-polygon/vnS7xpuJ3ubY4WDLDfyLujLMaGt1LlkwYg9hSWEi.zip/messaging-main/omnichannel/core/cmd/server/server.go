package server

import (
	"context"
	"github.com/robfig/cron/v3"

	"core/internal"
	coresqlrepository "core/repositories/sql"
	coreclient "core/services/client"
	coreinbound "core/services/inbound"
	coremanager "core/services/manager"
	coreoutbound "core/services/outbound"
	coreroute "core/services/route"
	corestatus "core/services/status"
	"framework/kernel"
	"framework/kernel/bootstrap"
	"framework/kernel/config"
	"framework/messaging"
	sharedsqlrepository "shared/repositories/sql"

	"github.com/sirupsen/logrus"
	"github.com/spf13/viper"
)

var banner = `


   ___ ___  ___ _____ ___ ___  __   ______   ___ ___  ___ ___ 
  / __/ _ \/ __|_   _| __| _ \ \ \ / /__ /  / __/ _ \| _ \ __|
 | (_| (_) \__ \ | | | _||   /  \ V / |_ \ | (_| (_) |   / _| 
  \___\___/|___/ |_| |___|_|_\   \_/ |___/  \___\___/|_|_\___|

 Version: %s
 Author : %s


`

func New() kernel.Kernel[*CustomContext] {
	server := kernel.NewBuilder[*CustomContext]().
		NewContext(func(conf *viper.Viper, logger *logrus.Logger) *CustomContext {
			return &CustomContext{
				conf:   conf,
				logger: logger,
			}
		}).
		ConfigureConfiguration(func() config.Options {
			return config.NewFileOptions().
				SetName("core")
		}).
		// bootstrapping resources
		Bootstrap(func() []kernel.BootstrapFn[*CustomContext] {
			return []kernel.BootstrapFn[*CustomContext]{
				// initialize db
				func(ctx *CustomContext) func(ctx *CustomContext) {
					ctx.Logger().Infoln("connecting database")
					ctx.db = bootstrap.DB(context.Background(), ctx)
					ctx.Logger().Infoln("database connected")
					// finalize db
					return func(ctx *CustomContext) {
						ctx.Logger().Infoln("disconnecting database")
						ctx.db.Close()
						ctx.Logger().Infoln("database disconnected")
					}
				},
				// initialize redis
				func(ctx *CustomContext) func(ctx *CustomContext) {
					ctx.Logger().Infoln("connecting redis")
					ctx.redis = bootstrap.Redis(context.Background(), ctx)
					ctx.Logger().Infoln("redis connected")
					// finalize redis
					return func(ctx *CustomContext) {
						ctx.Logger().Infoln("disconnecting redis")
						if err := ctx.redis.Close(); err != nil {
							ctx.Logger().WithError(err).Infoln("redis disconnected")
						} else {
							ctx.Logger().Infoln("redis disconnected")
						}
					}
				},
				// initialize amqp reader
				func(ctx *CustomContext) func(ctx *CustomContext) {
					ctx.Logger().Infoln("connecting amqp reader")
					ctx.amqpReader = bootstrap.AMQPXPool(ctx)
					ctx.Logger().Infoln("amqp reader connected")
					// finalize amqp
					return func(ctx *CustomContext) {
						ctx.Logger().Infoln("disconnecting amqp reader")
						if err := ctx.amqpReader.Close(); err != nil {
							ctx.Logger().WithError(err).Errorln("amqp reader disconnected")
						} else {
							ctx.Logger().Infoln("amqp reader disconnected")
						}
					}
				},
				// initialize amqp writer
				func(ctx *CustomContext) func(ctx *CustomContext) {
					ctx.Logger().Infoln("connecting amqp writer")
					ctx.amqpWriter = bootstrap.AMQPXPool(ctx)
					ctx.Logger().Infoln("amqp writer connected")
					// finalize amqp
					return func(ctx *CustomContext) {
						ctx.Logger().Infoln("disconnecting amqp writer")
						if err := ctx.amqpWriter.Close(); err != nil {
							ctx.Logger().WithError(err).Errorln("amqp writer disconnected")
						} else {
							ctx.Logger().Infoln("amqp writer disconnected")
						}
					}
				},
			}
		}).
		// bootstrapping repositories
		Bootstrap(func() []kernel.BootstrapFn[*CustomContext] {
			return []kernel.BootstrapFn[*CustomContext]{
				kernel.BootstrapNoCleanup(func(ctx *CustomContext) {
					ctx.Logger().Infoln("bootstrapping shared repository factory")
					ctx.sharedRepositoryFactory = sharedsqlrepository.NewRepositoryFactory(ctx.DB())
					ctx.Logger().Infoln("bootstrapping core repository factory")
					ctx.coreRepositoryFactory = coresqlrepository.NewRepositoryFactory(ctx.DB(), ctx.redis)
				}),
			}
		}).
		// bootstrapping messaging
		Bootstrap(func() []kernel.BootstrapFn[*CustomContext] {
			return []kernel.BootstrapFn[*CustomContext]{
				kernel.BootstrapNoCleanup(func(ctx *CustomContext) {
					ctx.Logger().Infoln("bootstrapping amqp messaging factory")
					ctx.amqpMessagingFactory = messaging.NewAMQPPoolFactory(ctx.AMQPReader(), ctx.AMQPWriter())
				}),
			}
		}).
		// bootstrapping services
		Bootstrap(func() []kernel.BootstrapFn[*CustomContext] {
			return []kernel.BootstrapFn[*CustomContext]{
				// initialize core inbound service factory
				kernel.BootstrapNoCleanup(func(ctx *CustomContext) {
					ctx.Logger().Infoln("bootstrapping core inbound service factory")
					ctx.coreInboundServiceFactory = coreinbound.NewServiceFactory(
						ctx.SharedRepositoryFactory(),
						ctx.CoreRepositoryFactory(),
						ctx.AMQPMessagingFactory(),
						ctx.redis,
						ctx.Logger(),
						&coreinbound.Options{
							SpamPeriod:              ctx.Config().GetDuration("spam.period"),
							SpamLimit:               ctx.Config().GetInt64("spam.limit"),
							SpamSecondaryPeriod:     ctx.Config().GetDuration("spam.secondary_period"),
							SpamSecondaryLimit:      ctx.Config().GetInt64("spam.secondary_limit"),
							SpamJanitorCleanupLimit: ctx.Config().GetInt("spam.cleanup_limit"),
						},
					)
				}),
				// initialize core outbound service factory
				kernel.BootstrapNoCleanup(func(ctx *CustomContext) {
					ctx.Logger().Infoln("bootstrapping core outbound service factory")
					ctx.coreOutboundServiceFactory = coreoutbound.NewServiceFactory(
						ctx.redis,
						ctx.SharedRepositoryFactory(),
						ctx.CoreRepositoryFactory(),
						ctx.AMQPMessagingFactory(),
						ctx.Logger(),
					)
				}),
				// initialize core status service factory
				kernel.BootstrapNoCleanup(func(ctx *CustomContext) {
					ctx.Logger().Infoln("bootstrapping core status service factory")
					ctx.coreStatusServiceFactory = corestatus.NewServiceFactory(
						ctx.SharedRepositoryFactory(),
						ctx.CoreRepositoryFactory(),
						ctx.AMQPMessagingFactory(),
						ctx.Logger(),
					)
				}),
				// initialize core route service factory
				kernel.BootstrapNoCleanup(func(ctx *CustomContext) {
					ctx.Logger().Infoln("bootstrapping core route service factory")
					ctx.coreRouteServiceFactory = coreroute.NewServiceFactory(
						ctx.SharedRepositoryFactory(),
						ctx.CoreRepositoryFactory(),
						ctx.AMQPMessagingFactory(),
						ctx.Logger(),
					)
				}),
				// initialize core client messaging factory
				kernel.BootstrapNoCleanup(func(ctx *CustomContext) {
					ctx.Logger().Infoln("bootstrapping core client messaging factory")
					ctx.coreClientMessagingFactory = coreclient.NewMessagingFactory(
						ctx.CoreInboundServiceFactory(),
						ctx.CoreOutboundServiceFactory(),
						ctx.CoreStatusServiceFactory(),
						ctx.CoreRouteServiceFactory(),
						ctx.AMQPMessagingFactory(),
						ctx.Logger(),
					)
				}),
				// initialize core client service factory
				kernel.BootstrapNoCleanup(func(ctx *CustomContext) {
					ctx.Logger().Infoln("bootstrapping core client service factory")
					ctx.coreClientServiceFactory = coreclient.NewServiceFactory(
						ctx.Config(),
						ctx.SharedRepositoryFactory(),
						ctx.CoreClientMessagingFactory(),
						ctx.Logger(),
					)
				}),
				// initialize core manager service factory
				kernel.BootstrapNoCleanup(func(ctx *CustomContext) {
					ctx.Logger().Infoln("bootstrapping core manager service factory")
					ctx.coreManagerServiceFactory = coremanager.NewServiceFactory(
						ctx.SharedRepositoryFactory(),
						ctx.CoreClientServiceFactory(),
						ctx.Logger(),
					)
				}),
			}
		}).
		Run(func(ctx *CustomContext) []kernel.RunFn {
			return []kernel.RunFn{
				func(stop chan struct{}) {
					managerService := ctx.CoreManagerServiceFactory().NewManagerService()
					managerService.Start()

					spamJanitorService := ctx.coreInboundServiceFactory.NewSpamJanitorService()
					cr := cron.New(
						cron.WithSeconds(),
						cron.WithParser(cron.NewParser(
							cron.SecondOptional|cron.Minute|cron.Hour|cron.Dom|cron.Month|cron.Dow|cron.Descriptor,
						)),
						cron.WithChain(
							cron.Recover(cron.DiscardLogger),
							cron.DelayIfStillRunning(cron.DiscardLogger),
						),
					)
					_, _ = cr.AddFunc(ctx.Config().GetString("spam.cleanup_interval"), func() {
						spamJanitorService.Cleanup(context.Background())
					})
					cr.Start()

					<-stop

					managerService.Stop()
					cr.Stop()
				},
			}
		}).
		Startup(func(ctx *CustomContext) {
			ctx.Logger().Infof(banner, internal.Version, internal.Author)
			ctx.Logger().Infoln("Startup")
		}).
		Shutdown(func(ctx *CustomContext) {
			ctx.Logger().Infoln("Shutdown")
		}).Build()

	return server
}
