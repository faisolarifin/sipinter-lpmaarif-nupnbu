package inbound

import (
	"core/ratelimiter"
	corerepositories "core/repositories"
	"framework/messaging"
	"github.com/go-redis/redis/v8"
	sharedrepositories "shared/repositories"
	"time"

	"github.com/sirupsen/logrus"
)

type Options struct {
	SpamPeriod time.Duration
	SpamLimit  int64

	SpamSecondaryPeriod time.Duration
	SpamSecondaryLimit  int64

	SpamJanitorCleanupLimit int
}

func NewServiceFactory(
	sharedRepositoryFactory sharedrepositories.RepositoryFactory,
	coreRepositoryFactory corerepositories.RepositoryFactory,
	amqpMessagingFactory messaging.AMQPFactory,
	redisClient *redis.Client,
	logger *logrus.Logger,
	opts *Options,
) *ServiceFactory {
	return &ServiceFactory{
		sharedRepositoryFactory: sharedRepositoryFactory,
		coreRepositoryFactory:   coreRepositoryFactory,
		amqpMessagingFactory:    amqpMessagingFactory,
		redisClient:             redisClient,
		logger:                  logger,
		opts:                    opts,
	}
}

type ServiceFactory struct {
	sharedRepositoryFactory sharedrepositories.RepositoryFactory
	coreRepositoryFactory   corerepositories.RepositoryFactory
	amqpMessagingFactory    messaging.AMQPFactory
	redisClient             *redis.Client
	logger                  *logrus.Logger
	opts                    *Options
}

func (f *ServiceFactory) NewService() *Service {
	return NewService(
		f.sharedRepositoryFactory.NewClientRepository(),
		f.sharedRepositoryFactory.NewAccountRepository(),
		f.sharedRepositoryFactory.NewApplicationRepository(),
		f.sharedRepositoryFactory.NewApplicationAccountRepository(),
		f.coreRepositoryFactory.NewOutboundApplicationRepository(),
		f.coreRepositoryFactory.NewInboundRepository(),
		f.coreRepositoryFactory.NewSessionRepository(),
		f.coreRepositoryFactory.NewClientApplicationRepository(),
		f.sharedRepositoryFactory.NewAccountCountryRepository(),
		f.coreRepositoryFactory.NewSpamRepository(),
		ratelimiter.NewRedisRateLimiter(f.redisClient, &ratelimiter.Options{
			Period: f.opts.SpamPeriod,
			Limit:  f.opts.SpamLimit,
		}),
		ratelimiter.NewRedisRateLimiter(f.redisClient, &ratelimiter.Options{
			Period: f.opts.SpamSecondaryPeriod,
			Limit:  f.opts.SpamSecondaryLimit,
		}),
		&DefaultMSISDNNormalizer{},
		f.amqpMessagingFactory.NewAMQPPublisher(),
		f.logger,
	)
}

func (f *ServiceFactory) NewSpamJanitorService() *SpamJanitorService {
	return NewSpamJanitorService(
		f.sharedRepositoryFactory.NewAccountRepository(),
		f.coreRepositoryFactory.NewSpamRepository(),
		f.logger,
		f.opts.SpamJanitorCleanupLimit,
	)
}
