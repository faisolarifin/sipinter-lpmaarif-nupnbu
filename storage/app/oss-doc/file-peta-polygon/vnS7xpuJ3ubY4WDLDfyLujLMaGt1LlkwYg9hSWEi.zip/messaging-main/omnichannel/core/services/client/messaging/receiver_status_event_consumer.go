package messaging

import (
	"context"
	"encoding/json"
	"fmt"
	"sync/atomic"
	"time"

	"core/events"
	"core/services/status"
	"core/services/status/dto"
	"framework/list"
	"framework/messaging"
	sharedentities "shared/entities"

	amqp "github.com/rabbitmq/amqp091-go"
	"github.com/sirupsen/logrus"
)

type ReceiverStatusEventConsumer struct {
	state        int32
	queue        string
	account      *sharedentities.Account
	service      *status.Service
	amqpConsumer *messaging.AMQPConsumer
	logger       *logrus.Entry
}

func NewReceiverStatusEventConsumer(
	account *sharedentities.Account,
	service *status.Service,
	amqpConsumer *messaging.AMQPConsumer,
	logger *logrus.Logger,
) *ReceiverStatusEventConsumer {
	queue := fmt.Sprintf("%s.%s.%s.status", account.ClientId, account.ChannelId, account.AccountAlias)
	return &ReceiverStatusEventConsumer{
		queue:        queue,
		account:      account,
		service:      service,
		amqpConsumer: amqpConsumer,
		logger: logger.WithFields(
			logrus.Fields{
				"resource": "ReceiverStatusEventConsumer",
				"queue":    queue,
			},
		),
	}
}

func (c *ReceiverStatusEventConsumer) Consume() {
	if !atomic.CompareAndSwapInt32(&c.state, 0, 1) {
		return
	}

	c.logger.Infoln("Consume")
	logger := c.logger.WithField("func", "Consume")
	err := c.amqpConsumer.Consume(c.queue, func(delivery amqp.Delivery) {
		logger.WithField("body", string(delivery.Body)).Infoln("Consume Status Message")
		var event events.ReceiverStatusEvent
		if err := json.Unmarshal(delivery.Body, &event); err != nil {
			logger.WithError(err).
				WithField("body", string(delivery.Body)).
				Errorln("JSON.Unmarshal")
			if err = delivery.Nack(false, false); err != nil {
				logger.WithError(err).Errorln("AMQPConsumer.Nack")
			}
			return
		}

		createDto := &dto.CreateDto{
			ClientId:     event.ClientId,
			ChannelId:    event.ChannelId,
			AccountAlias: event.GetAccountAlias(),
			Data:         list.Copy(event.Data),
			CreatedAt:    time.Now().Local(),
		}
		logger.WithField("args", createDto.ToMap()).Infoln("Processing Status Message")
		err := c.service.Create(context.Background(), createDto)
		if err != nil {
			logger.WithError(err).Errorln("Service.Create")
			if err = delivery.Nack(false, true); err != nil {
				logger.WithError(err).Errorln("AMQPConsumer.Nack")
			}
			return
		}
		if err = delivery.Ack(false); err != nil {
			logger.WithError(err).Errorln("AMQPConsumer.Ack")
		}
	})
	if err != nil {
		logger.WithError(err).Errorln("AMQPConsumer.Consume")
	}
}

func (c *ReceiverStatusEventConsumer) Stop() {
	if !atomic.CompareAndSwapInt32(&c.state, 1, 0) {
		return
	}
	c.logger.Infoln("Stop")
	c.amqpConsumer.Stop()
}
