package repositories

import (
	"context"

	"core/entities"
)

type OutboundApplicationRepository interface {
	FindByChannelAndAccountAndMid(ctx context.Context, clientId, channelId, accountId, mid string) (*entities.OutboundApplication, error)
}
