package status

import (
	corerepositories "core/repositories"
	"framework/messaging"
	sharedrepositories "shared/repositories"

	"github.com/sirupsen/logrus"
)

type ServiceFactory struct {
	sharedRepositoryFactory sharedrepositories.RepositoryFactory
	coreRepositoryFactory   corerepositories.RepositoryFactory
	amqpMessagingFactory    messaging.AMQPFactory
	logger                  *logrus.Logger
}

func NewServiceFactory(
	sharedRepositoryFactory sharedrepositories.RepositoryFactory,
	coreRepositoryFactory corerepositories.RepositoryFactory,
	amqpMessagingFactory messaging.AMQPFactory,
	logger *logrus.Logger,
) *ServiceFactory {
	return &ServiceFactory{
		sharedRepositoryFactory: sharedRepositoryFactory,
		coreRepositoryFactory:   coreRepositoryFactory,
		amqpMessagingFactory:    amqpMessagingFactory,
		logger:                  logger,
	}
}

func (f *ServiceFactory) NewService() *Service {
	return NewService(
		f.sharedRepositoryFactory.NewClientRepository(),
		f.sharedRepositoryFactory.NewAccountRepository(),
		f.coreRepositoryFactory.NewStatusRepository(),
		f.coreRepositoryFactory.NewOutboundRepository(),
		f.coreRepositoryFactory.NewWhatsAppSessionRepository(),
		f.amqpMessagingFactory.NewAMQPPublisher(),
		f.logger,
	)
}
