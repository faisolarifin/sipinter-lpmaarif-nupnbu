package entities

import (
	"encoding/json"
	"time"
)

type Route struct {
	Id            string
	MId           *string
	ClientId      string
	ChannelId     string
	AccountId     string
	ApplicationId string
	Route         string
	Data          json.RawMessage
	CreatedAt     time.Time
}

type RouteCreate struct {
	MId           *string
	ClientId      string
	ChannelId     string
	AccountId     string
	ApplicationId string
	Route         string
	Data          json.RawMessage
	CreatedAt     time.Time
}
