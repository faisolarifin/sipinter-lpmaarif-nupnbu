package dto

import (
	"encoding/json"
	"strings"
	"time"

	"core/entities"
	sharedentities "shared/entities"

	"github.com/tidwall/gjson"
)

type CreateDto struct {
	XId           string
	ClientId      string
	ChannelId     string
	AccountAlias  string
	ApplicationId string
	Data          json.RawMessage
	CreatedAt     time.Time
}

func (d *CreateDto) Type() entities.OutboundType {
	var typ string
	switch sharedentities.NewChannel(d.ChannelId) {
	case sharedentities.ChannelWhatsApp:
		typ = gjson.GetBytes(d.Data, "type").String()
		if strings.EqualFold(typ, "template") {
			return entities.OutboundTypeTemplate
		}
		return entities.OutboundTypeInteractive
	case sharedentities.ChannelWhatsAppCloud:
		typ = gjson.GetBytes(d.Data, "type").String()
		if strings.EqualFold(typ, "template") {
			return entities.OutboundTypeTemplate
		}
		return entities.OutboundTypeInteractive
	case sharedentities.ChannelEmail:
		return entities.OutboundTypeInteractive
	case sharedentities.ChannelSMS:
		return entities.OutboundTypeInteractive
	}

	return entities.OutboundTypeInteractive
}

func (d *CreateDto) Recipient() string {
	switch sharedentities.NewChannel(d.ChannelId) {
	case sharedentities.ChannelWhatsApp:
		return gjson.GetBytes(d.Data, "to").String()
	case sharedentities.ChannelWhatsAppCloud:
		return gjson.GetBytes(d.Data, "to").String()
	case sharedentities.ChannelSMS:
		return gjson.GetBytes(d.Data, "to").String()
	}

	return ""
}

func (d *CreateDto) ToMap() map[string]any {
	if d == nil {
		return nil
	}

	return map[string]any{
		"XId":           d.XId,
		"ClientId":      d.ClientId,
		"ChannelId":     d.ChannelId,
		"AccountAlias":  d.AccountAlias,
		"ApplicationId": d.ApplicationId,
		"Type":          d.Type(),
		"Recipient":     d.Recipient(),
		"Data":          string(d.Data),
		"CreatedAt":     d.CreatedAt,
	}
}
