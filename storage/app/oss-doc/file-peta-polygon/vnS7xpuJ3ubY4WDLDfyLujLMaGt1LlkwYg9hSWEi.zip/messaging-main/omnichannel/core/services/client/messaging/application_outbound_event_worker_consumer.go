package messaging

import (
	"fmt"
	"framework/messaging"
	"github.com/sirupsen/logrus"
	sharedentities "shared/entities"
	"sync/atomic"
)

type ApplicationOutboundEventWorkerConsumer struct {
	state              int32
	queue              string
	applicationAccount *sharedentities.ApplicationAccount
	amqpWorkerConsumer *messaging.AMQPWorkerConsumer
	logger             *logrus.Entry
}

func NewApplicationOutboundEventWorkerConsumer(
	applicationAccount *sharedentities.ApplicationAccount,
	amqpWorkerConsumer *messaging.AMQPWorkerConsumer,
	logger *logrus.Logger,
) *ApplicationOutboundEventWorkerConsumer {
	queue := fmt.Sprintf("%s.%s.%s.outbound.%s",
		applicationAccount.ClientId,
		applicationAccount.ChannelId,
		applicationAccount.AccountAlias,
		applicationAccount.ClientApplicationId,
	)
	return &ApplicationOutboundEventWorkerConsumer{
		queue:              queue,
		applicationAccount: applicationAccount,
		amqpWorkerConsumer: amqpWorkerConsumer,
		logger: logger.WithFields(
			logrus.Fields{
				"resource": "ApplicationOutboundEventWorkerConsumer",
				"queue":    queue,
			},
		),
	}
}

func (c *ApplicationOutboundEventWorkerConsumer) Consume() {
	if !atomic.CompareAndSwapInt32(&c.state, 0, 1) {
		return
	}

	c.logger.Infoln("Consume")
	logger := c.logger.WithField("func", "Consume")
	err := c.amqpWorkerConsumer.Consume(c.queue)
	if err != nil {
		logger.WithError(err).Errorln("AMQPWorkerConsumer.Consume")
	}
}

func (c *ApplicationOutboundEventWorkerConsumer) Stop() {
	if !atomic.CompareAndSwapInt32(&c.state, 1, 0) {
		return
	}
	c.logger.Infoln("Stop")
	c.amqpWorkerConsumer.Stop()
}
