package events

import (
	"encoding/json"
	"time"
)

type ApplicationInboundEvent struct {
	Id            string          `json:"id"`
	MId           string          `json:"mid"`
	ClientId      string          `json:"client_id"`
	ChannelId     string          `json:"channel_id"`
	AccountId     string          `json:"account_id"`
	AccountAlias  string          `json:"account_alias"`
	ApplicationId *string         `json:"application_id"`
	Data          json.RawMessage `json:"data"`
	CreatedAt     time.Time       `json:"created_at"`
}

func (e *ApplicationInboundEvent) ToMap() map[string]any {
	if e == nil {
		return nil
	}

	return map[string]any{
		"Id":            e.Id,
		"MId":           e.MId,
		"ClientId":      e.ClientId,
		"ChannelId":     e.ChannelId,
		"AccountId":     e.AccountId,
		"AccountAlias":  e.AccountAlias,
		"ApplicationId": e.ApplicationId,
		"Data":          string(e.Data),
		"CreatedAt":     e.CreatedAt,
	}
}
