package entities

import (
	"encoding/json"
	"time"
)

type (
	Template struct {
		Id         string `json:"id" db:"id"`
		Name       string `json:"name" db:"name"`
		CategoryId string `json:"category_id" db:"category_id"`
	}

	CreateCacheTemplate struct {
		ClientId  string
		AccountId string
		Name      string
		Template  *Template
		Ttl       time.Duration
		Data      *Template
	}
)

func (e *CreateCacheTemplate) String() string {
	result, _ := json.Marshal(e.Template)

	return string(result)
}
