package sql

import (
	"context"
	"core/entities"
	"framework/database"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/jackc/pgxutil"
	"github.com/pkg/errors"
)

func newClientApplicationRepository(db *pgxpool.Pool) *ClientApplicationRepository {
	return &ClientApplicationRepository{db: db}
}

type ClientApplicationRepository struct {
	db *pgxpool.Pool
}

func (r *ClientApplicationRepository) FindByApplicationId(ctx context.Context, clientId, clientAccountAlias, applicationId string) (*entities.ClientApplication, error) {
	query := `
		select ca.id,
			   ca.client_id,
			   ca.application_id,
			   caa.client_account_id,
			   ca.name,
			   ca.configuration,
			   ca.is_default,
			   ca.is_active,
			   ca.created_at,
			   ca.created_by,
			   ca.updated_at,
			   ca.updated_by
		from client_applications as ca
				 left join client_application_accounts caa on ca.id = caa.client_application_id
				 left join client_accounts as a on caa.client_account_id = a.id
		where ca.deleted_at is null
		  and ca.client_id = @client_id
		  and a.account_alias = @account_alias
		  and ca.application_id = @application_id
		limit 1
	`
	params := pgx.NamedArgs{
		"client_id":      clientId,
		"account_alias":  clientAccountAlias,
		"application_id": applicationId,
	}

	result, err := pgxutil.SelectRow(ctx, r.db, query, []any{params}, pgx.RowToAddrOfStructByName[entities.ClientApplication])
	if err != nil {
		if err.Error() == pgx.ErrNoRows.Error() {
			return nil, errors.WithStack(
				database.NewErrorNotFound("client application with client id %s, account_alias %s and  application id %s not found",
					clientId, clientAccountAlias, applicationId))
		}
		return nil, errors.WithStack(err)
	}

	return result, nil
}

func (r *ClientApplicationRepository) FindById(ctx context.Context, clientId, clientAccountAlias, id string) (*entities.ClientApplication, error) {
	query := `
		select ca.id,
			   ca.client_id,
			   ca.application_id,
			   caa.client_account_id,
			   ca.name,
			   ca.configuration,
			   ca.is_default,
			   ca.is_active,
			   ca.created_at,
			   ca.created_by,
			   ca.updated_at,
			   ca.updated_by
		from client_applications as ca
				 left join client_application_accounts caa on ca.id = caa.client_application_id
				 left join client_accounts as a on caa.client_account_id = a.id
		where ca.deleted_at is null
		  and ca.client_id = @client_id
		  and a.account_alias = @account_alias
		  and ca.id = @id
		limit 1
	`
	params := pgx.NamedArgs{
		"client_id":     clientId,
		"account_alias": clientAccountAlias,
		"id":            id,
	}

	result, err := pgxutil.SelectRow(ctx, r.db, query, []any{params}, pgx.RowToAddrOfStructByName[entities.ClientApplication])
	if err != nil {
		if err.Error() == pgx.ErrNoRows.Error() {
			return nil, errors.WithStack(
				database.NewErrorNotFound("client application with client id %s, account_alias %s and id %s not found",
					clientId, clientAccountAlias, id))
		}
		return nil, errors.WithStack(err)
	}

	return result, nil
}
