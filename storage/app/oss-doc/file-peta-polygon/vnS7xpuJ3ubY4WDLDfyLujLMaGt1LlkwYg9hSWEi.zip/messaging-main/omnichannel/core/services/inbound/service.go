package inbound

import (
	"context"
	"core/entities"
	"core/events"
	"core/ratelimiter"
	corerepositories "core/repositories"
	"core/services/inbound/dto"
	"fmt"
	"framework/list"
	"framework/messaging"
	"framework/pointer"
	"framework/service"
	amqp "github.com/rabbitmq/amqp091-go"
	"github.com/tidwall/gjson"
	"math"
	sharedentities "shared/entities"
	sharedrepositories "shared/repositories"
	"strings"
	"time"

	"github.com/jackc/pgconn"
	"github.com/pkg/errors"
	"github.com/sirupsen/logrus"
)

var (
	allowedRouteApplications = []string{"chatbot", "helpdesk", "campaign"}
	broadcastApplications    = []string{"broadcast", "broadcast-m2m"}
)

func NewService(
	clientRepository sharedrepositories.ClientRepository,
	accountRepository sharedrepositories.AccountRepository,
	applicationRepository sharedrepositories.ApplicationRepository,
	applicationAccountRepository sharedrepositories.ApplicationAccountRepository,
	outboundRepository corerepositories.OutboundApplicationRepository,
	inboundRepository corerepositories.InboundRepository,
	sessionRepository corerepositories.SessionRepository,
	clientApplicationRepository corerepositories.ClientApplicationRepository,
	accountCountryRepository sharedrepositories.AccountCountryRepository,
	spamRepository corerepositories.SpamRepository,
	redisRateLimiter *ratelimiter.RedisRateLimiter,
	redisSecondaryRateLimiter *ratelimiter.RedisRateLimiter,
	msisdnNormalizer MSISDNNormalizer,
	amqpPublisher *messaging.AMQPPublisher,
	logger *logrus.Logger,
) *Service {
	return &Service{
		clientRepository:             clientRepository,
		accountRepository:            accountRepository,
		applicationRepository:        applicationRepository,
		applicationAccountRepository: applicationAccountRepository,
		outboundRepository:           outboundRepository,
		inboundRepository:            inboundRepository,
		sessionRepository:            sessionRepository,
		clientApplicationRepository:  clientApplicationRepository,
		accountCountryRepository:     accountCountryRepository,
		spamRepository:               spamRepository,
		redisRateLimiter:             redisRateLimiter,
		redisSecondaryRateLimiter:    redisSecondaryRateLimiter,
		msisdnNormalizer:             msisdnNormalizer,
		amqpPublisher:                amqpPublisher,
		logger: logger.WithFields(
			logrus.Fields{
				"resource": "InboundService",
			},
		),
	}
}

type Service struct {
	clientRepository             sharedrepositories.ClientRepository
	accountRepository            sharedrepositories.AccountRepository
	applicationRepository        sharedrepositories.ApplicationRepository
	applicationAccountRepository sharedrepositories.ApplicationAccountRepository
	outboundRepository           corerepositories.OutboundApplicationRepository
	inboundRepository            corerepositories.InboundRepository
	sessionRepository            corerepositories.SessionRepository
	clientApplicationRepository  corerepositories.ClientApplicationRepository
	accountCountryRepository     sharedrepositories.AccountCountryRepository
	spamRepository               corerepositories.SpamRepository
	redisRateLimiter             *ratelimiter.RedisRateLimiter
	redisSecondaryRateLimiter    *ratelimiter.RedisRateLimiter
	msisdnNormalizer             MSISDNNormalizer
	amqpPublisher                *messaging.AMQPPublisher
	logger                       *logrus.Entry
}

func (s *Service) Create(ctx context.Context, dto *dto.CreateDto) error {
	defer func() {
		if err := recover(); err != nil {
			s.logger.WithError(fmt.Errorf("%+v", err)).Errorln("panic recovery")
		}
	}()

	if strings.TrimSpace(dto.MId()) == "" {
		return errors.WithStack(service.NewErrorValidation("mid required"))
	}

	if strings.TrimSpace(dto.ClientId) == "" {
		return errors.WithStack(service.NewErrorValidation("client id required"))
	}

	if strings.TrimSpace(dto.ChannelId) == "" {
		return errors.WithStack(service.NewErrorValidation("channel id required"))
	}

	if strings.TrimSpace(dto.AccountId) == "" && strings.TrimSpace(dto.AccountAlias) == "" {
		return errors.WithStack(service.NewErrorValidation("account id required"))
	}

	if err := s.clientRepository.ExistById(ctx, dto.ClientId); err != nil {
		switch errors.Cause(err).(type) {
		case *sharedentities.ErrorClientNotFound:
			return errors.WithStack(service.NewErrorValidation(err.Error()))
		default:
			return errors.WithStack(err)
		}
	}

	if err := sharedentities.IsChannelValid(dto.ChannelId); err != nil {
		return errors.WithStack(service.NewErrorValidation(err.Error()))
	}

	var (
		account *sharedentities.Account
		err     error
	)
	switch sharedentities.NewChannel(dto.ChannelId) {
	case sharedentities.ChannelEmail:
		account, err = s.accountRepository.FindByChannelAndId(ctx, dto.ClientId, dto.ChannelId, dto.AccountId)
		if err != nil {
			switch errors.Cause(err).(type) {
			case *sharedentities.ErrorAccountNotFound:
				return errors.WithStack(service.NewErrorValidation(err.Error()))
			default:
				return errors.WithStack(err)
			}
		}
	default:
		account, err = s.accountRepository.FindByChannelAndAlias(ctx, dto.ClientId, dto.ChannelId, dto.AccountAlias)
		if err != nil {
			switch errors.Cause(err).(type) {
			case *sharedentities.ErrorAccountNotFound:
				return errors.WithStack(service.NewErrorValidation(err.Error()))
			default:
				return errors.WithStack(err)
			}
		}
	}

	if !account.IsActive {
		return errors.WithStack(service.NewErrorValidation("inactive account with channel %s and alias %s",
			dto.ChannelId, dto.AccountAlias))
	}

	msisdn := dto.Sender()
	if list.In(sharedentities.NewChannel(dto.ChannelId), []sharedentities.Channel{sharedentities.ChannelWhatsApp, sharedentities.ChannelWhatsAppCloud}) {
		msisdn = s.msisdnNormalizer.Normalize(dto.Sender())
	}

	//
	// Get sender session
	//
	session, err := s.sessionRepository.Find(ctx, dto.ClientId, dto.ChannelId, dto.AccountAlias, dto.Sender())
	if err != nil {
		switch errors.Cause(err).(type) {
		case *entities.ErrorSessionNotFound:
		default:
			return errors.WithStack(err)
		}
	}

	if session == nil {
		session, err = s.sessionRepository.Create(ctx, &entities.SessionCreate{
			ClientId:      dto.ClientId,
			ChannelId:     dto.ChannelId,
			AccountAlias:  dto.AccountAlias,
			ApplicationId: pointer.Default(account.ApplicationId, ""),
			Sender:        dto.Sender(),
			CreatedAt:     dto.CreatedAt,
		})
		if err != nil {
			switch e := errors.Cause(err).(type) {
			case *pgconn.PgError:
				if e.Code == "23505" {
					session, err = s.sessionRepository.Find(ctx, dto.ClientId, dto.ChannelId, dto.AccountAlias, dto.Sender())
					if err != nil {
						return errors.WithStack(err)
					}
				} else {
					return errors.WithStack(err)
				}
			default:
				return errors.WithStack(err)
			}
		}
	}
	//
	// End get sender session
	//

	//
	// Check spam
	//
	if list.In(sharedentities.NewChannel(dto.ChannelId), []sharedentities.Channel{sharedentities.ChannelWhatsApp, sharedentities.ChannelWhatsAppCloud}) {
		isSpam, err := s.spamRepository.IsSpam(context.Background(), dto.ClientId, dto.ChannelId, account.Id, msisdn)
		if err != nil {
			return errors.WithStack(err)
		}

		if isSpam {
			s.logger.WithFields(logrus.Fields{
				"client_id":  dto.ClientId,
				"channel_id": dto.ChannelId,
				"account_id": account.Id,
				"msisdn":     msisdn,
			}).Infoln("sender detected as spam")

			inboundCreate := &entities.InboundCreate{
				MId:           dto.MId(),
				ClientId:      dto.ClientId,
				ChannelId:     dto.ChannelId,
				AccountId:     account.Id,
				ApplicationId: session.ClientApplicationId,
				Data:          dto.Data,
				Status:        entities.StatusSpam,
				CreatedAt:     dto.CreatedAt,
			}
			_, err = s.inboundRepository.Create(ctx, inboundCreate)
			if err != nil {
				// ERROR: unsupported Unicode escape sequence (SQLSTATE 22P05)
				s.logger.WithFields(logrus.Fields{
					"client_id":  dto.ClientId,
					"channel_id": dto.ChannelId,
					"account_id": account.Id,
					"msisdn":     msisdn,
					"data":       string(dto.Data),
				}).WithError(fmt.Errorf("%+v", err)).Errorln("error create inbound")
				//return errors.WithStack(err)
			}

			return nil
		}

		err = s.redisRateLimiter.Allowed(context.Background(), dto.ClientId, dto.ChannelId, account.Id, msisdn)
		if err != nil {
			switch err.(type) {
			case *ratelimiter.ErrorLimitExceed:
				tm := time.Now().Local()
				ex := tm.Add(time.Hour * 24)
				err = s.spamRepository.Create(context.Background(), &entities.CreateSpam{
					ClientId:  dto.ClientId,
					ChannelId: dto.ChannelId,
					AccountId: account.Id,
					Sender:    msisdn,
					Type:      entities.SpamTypeTemporary,
					ExpiredAt: ex,
					CreatedAt: tm,
				})
				if err != nil {
					return errors.WithStack(err)
				}

				s.logger.WithFields(logrus.Fields{
					"client_id":  dto.ClientId,
					"channel_id": dto.ChannelId,
					"account_id": account.Id,
					"msisdn":     msisdn,
				}).Infoln("sender detected as spam blocked")

				inboundCreate := &entities.InboundCreate{
					MId:           dto.MId(),
					ClientId:      dto.ClientId,
					ChannelId:     dto.ChannelId,
					AccountId:     account.Id,
					ApplicationId: session.ClientApplicationId,
					Data:          dto.Data,
					Status:        entities.StatusSpam,
					CreatedAt:     dto.CreatedAt,
				}
				_, err = s.inboundRepository.Create(ctx, inboundCreate)
				if err != nil {
					// ERROR: unsupported Unicode escape sequence (SQLSTATE 22P05)
					s.logger.WithFields(logrus.Fields{
						"client_id":  dto.ClientId,
						"channel_id": dto.ChannelId,
						"account_id": account.Id,
						"msisdn":     msisdn,
						"data":       string(dto.Data),
					}).WithError(fmt.Errorf("%+v", err)).Errorln("error create inbound")
					//return errors.WithStack(err)
				}

				return nil
			default:
				return errors.WithStack(err)
			}
		}

		err = s.redisSecondaryRateLimiter.Allowed(context.Background(), dto.ClientId, dto.ChannelId, account.Id, "secondary:"+msisdn)
		if err != nil {
			switch err.(type) {
			case *ratelimiter.ErrorLimitExceed:
				tm := time.Now().Local()
				ex := tm.Add(time.Hour * 24)
				err = s.spamRepository.Create(context.Background(), &entities.CreateSpam{
					ClientId:  dto.ClientId,
					ChannelId: dto.ChannelId,
					AccountId: account.Id,
					Sender:    msisdn,
					Type:      entities.SpamTypeTemporary,
					ExpiredAt: ex,
					CreatedAt: tm,
				})
				if err != nil {
					return errors.WithStack(err)
				}

				s.logger.WithFields(logrus.Fields{
					"client_id":  dto.ClientId,
					"channel_id": dto.ChannelId,
					"account_id": account.Id,
					"msisdn":     msisdn,
				}).Infoln("sender detected as spam blocked")

				inboundCreate := &entities.InboundCreate{
					MId:           dto.MId(),
					ClientId:      dto.ClientId,
					ChannelId:     dto.ChannelId,
					AccountId:     account.Id,
					ApplicationId: session.ClientApplicationId,
					Data:          dto.Data,
					Status:        entities.StatusSpam,
					CreatedAt:     dto.CreatedAt,
				}
				_, err = s.inboundRepository.Create(ctx, inboundCreate)
				if err != nil {
					// ERROR: unsupported Unicode escape sequence (SQLSTATE 22P05)
					s.logger.WithFields(logrus.Fields{
						"client_id":  dto.ClientId,
						"channel_id": dto.ChannelId,
						"account_id": account.Id,
						"msisdn":     msisdn,
						"data":       string(dto.Data),
					}).WithError(fmt.Errorf("%+v", err)).Errorln("error create inbound")
					//return errors.WithStack(err)
				}

				return nil
			default:
				return errors.WithStack(err)
			}
		}
	}
	//
	// End check spam
	//

	//
	// Allowed sent message to another country
	//

	// if prefix not from indonesia check allowed country by prefix
	if list.In(sharedentities.NewChannel(dto.ChannelId), []sharedentities.Channel{sharedentities.ChannelWhatsApp, sharedentities.ChannelWhatsAppCloud}) {
		// build prefixes msisdn with length from 5 to 1 and + character
		var prefixes []string
		count := int(math.Min(float64(5), float64(len(msisdn))))
		if count > 0 {
			for i := 0; i < count-1; i++ {
				prefixes = append(prefixes, msisdn[:count-i])
			}
		}

		indonesiaPrefix := list.In("+62", prefixes)
		if !indonesiaPrefix {
			//var (
			//	session *entities.Session
			//	allowed bool
			//)
			var allowed bool

			if !account.AllowedToOtherCountry {
				allowed = false
			} else {
				if !account.AllowedToAllOtherCountry {
					var accountCountries []*sharedentities.AccountCountry

					accountCountries, err = s.accountCountryRepository.GetByAccountAndPrefixes(ctx, account.Id, prefixes)
					if err != nil {
						switch errors.Cause(err).(type) {
						case *sharedentities.ErrorAccountCountryNotFound:
						default:
							return errors.WithStack(err)
						}
					}

					allowed = len(accountCountries) > 0
				} else {
					allowed = true
				}
			}

			if !allowed {
				inboundCreate := &entities.InboundCreate{
					MId:           dto.MId(),
					ClientId:      dto.ClientId,
					ChannelId:     dto.ChannelId,
					AccountId:     account.Id,
					ApplicationId: session.ClientApplicationId,
					Data:          dto.Data,
					Status:        entities.StatusForbidden,
					CreatedAt:     dto.CreatedAt,
				}
				_, err = s.inboundRepository.Create(ctx, inboundCreate)
				if err != nil {
					// ERROR: unsupported Unicode escape sequence (SQLSTATE 22P05)
					s.logger.WithFields(logrus.Fields{
						"client_id":  dto.ClientId,
						"channel_id": dto.ChannelId,
						"account_id": account.Id,
						"msisdn":     msisdn,
						"data":       string(dto.Data),
					}).WithError(fmt.Errorf("%+v", err)).Errorln("error create inbound")
					//return errors.WithStack(err)
				}

				return nil
			}
		}

	}
	//
	// End allowed sent message to another country
	//

	var (
		applicationId      string
		routeApplicationId string
		outbound           *entities.OutboundApplication
		currentApplication *entities.ClientApplication
		routeApplication   *sharedentities.Application
		routingType        = entities.RoutingTypeSession
		forwardInbound     = false
	)
	if sharedentities.NewChannel(dto.ChannelId) == sharedentities.ChannelWhatsApp || sharedentities.NewChannel(dto.ChannelId) == sharedentities.ChannelWhatsAppCloud {
		if dto.Type() == "button" {
			value := gjson.GetBytes(dto.Data, "entry.0.changes.0.value.messages.0.button.payload").String()
			routeApplicationId = strings.TrimSpace(list.First(strings.Split(value, ".")))

			//
			// routing application
			//
			logger := s.logger.WithFields(logrus.Fields{"payload": value, "route_application": routeApplicationId})
			logger.Infoln("get inbound button")

			if list.In(routeApplicationId, allowedRouteApplications) {
				logger.Infoln("allowed route applications")
				//
				// get current user session application
				//
				currentApplication, err = s.clientApplicationRepository.FindById(ctx, dto.ClientId, dto.AccountAlias, session.ClientApplicationId)
				if err != nil {
					return errors.WithStack(err)
				}
				logger.WithField("current_application", currentApplication.ApplicationId).Infoln("get current application")

				//
				// get route application
				//
				routeApplication, err = s.applicationRepository.FindByApplicationId(ctx, dto.ClientId, routeApplicationId)
				if err != nil {
					return errors.WithStack(err)
				}
				logger.WithField("route_application", routeApplication.ApplicationId).Infoln("get route application")

				//
				// get outbound message
				//
				outbound, err = s.outboundRepository.FindByChannelAndAccountAndMid(ctx, dto.ClientId, dto.ChannelId, account.Id, dto.OId())
				if err != nil {
					switch errors.Cause(err).(type) {
					case *entities.ErrorOutboundNotFound:
						return errors.WithStack(service.NewErrorValidation(err.Error()))
					default:
						return errors.WithStack(err)
					}
				}
				logger.WithField("outbound_application", outbound.ApplicationId).Infoln("get outbound application")

				//
				// set forward inbound to true if application id in broadcast, broadcast-m2m
				//
				logger = logger.WithField("outbound_application", outbound.ApplicationId)
				forwardInbound = list.In(outbound.ApplicationId, broadcastApplications)
				logger.WithField("forward_inbound", forwardInbound).Infoln("forward inbound application")

				switch currentApplication.ApplicationId {
				case "helpdesk":
					routingType = entities.RoutingTypeSession
				case "chatbot":
					switch routeApplication.ApplicationId {
					case "helpdesk", "campaign":
						routingType = entities.RoutingTypeApplication
					default:
						routingType = entities.RoutingTypeSession
					}
				case "campaign":
					switch routeApplication.ApplicationId {
					case "helpdesk":
						routingType = entities.RoutingTypeApplication
					default:
						routingType = entities.RoutingTypeSession
					}
				}
			} else {
				//
				// button value not in routing application, routing by outbound
				//
				logger.Infoln("not in allowed route applications")
				routingType = entities.RoutingTypeOutbound
			}
		} else if dto.Type() == "interactive" {
			interactiveType := gjson.GetBytes(dto.Data, "entry.0.changes.0.value.messages.0.interactive.type").String()
			if interactiveType == "nfm_reply" {
				routingType = entities.RoutingTypeOutbound
			}
		}
	}

	if routingType == entities.RoutingTypeOutbound {
		outbound, err = s.outboundRepository.FindByChannelAndAccountAndMid(ctx, dto.ClientId, dto.ChannelId, account.Id, dto.OId())
		if err != nil {
			switch errors.Cause(err).(type) {
			case *entities.ErrorOutboundNotFound:
				routingType = entities.RoutingTypeSession
			default:
				return errors.WithStack(err)
			}
		}
	}

	switch routingType {
	case entities.RoutingTypeSession:
		applicationId = session.ClientApplicationId
	case entities.RoutingTypeOutbound:
		applicationId = outbound.ClientApplicationId
	case entities.RoutingTypeApplication:
		applicationId = routeApplication.Id

		// set user routing session
		session, err = s.sessionRepository.Find(ctx, dto.ClientId, dto.ChannelId, dto.AccountAlias, dto.Sender())
		if err != nil {
			switch errors.Cause(err).(type) {
			case *entities.ErrorSessionNotFound:
			default:
				return errors.WithStack(err)
			}
		}

		if session == nil {
			session, err = s.sessionRepository.Create(ctx, &entities.SessionCreate{
				ClientId:      dto.ClientId,
				ChannelId:     dto.ChannelId,
				AccountAlias:  dto.AccountAlias,
				ApplicationId: applicationId,
				Sender:        dto.Sender(),
				CreatedAt:     dto.CreatedAt,
			})
			if err != nil {
				switch e := errors.Cause(err).(type) {
				case *pgconn.PgError:
					if e.Code == "23505" {
						session, err = s.sessionRepository.Find(ctx, dto.ClientId, dto.ChannelId, dto.AccountAlias, dto.Sender())
						if err != nil {
							return errors.WithStack(err)
						}
					} else {
						return errors.WithStack(err)
					}
				default:
					return errors.WithStack(err)
				}
			}
		} else {
			sessionUpdate := &entities.SessionUpdate{
				ClientId:      dto.ClientId,
				ChannelId:     dto.ChannelId,
				AccountAlias:  dto.AccountAlias,
				ApplicationId: applicationId,
				Sender:        dto.Sender(),
				UpdatedAt:     dto.CreatedAt,
			}
			s.logger.WithField("args", sessionUpdate.ToMap()).Infoln("Update Session")
			session, err = s.sessionRepository.Update(ctx, sessionUpdate)
			if err != nil {
				s.logger.WithField("args", sessionUpdate.ToMap()).WithError(err).Errorln("Update Session")
				return errors.WithStack(err)
			}
		}
	default:
		return errors.New("unknown routing type")
	}

	s.logger.WithFields(
		logrus.Fields{
			"routing_type":   routingType,
			"application_id": applicationId,
		},
	).Infoln("Routing Inbound Message To Application")

	inboundCreate := &entities.InboundCreate{
		MId:       dto.MId(),
		ClientId:  dto.ClientId,
		ChannelId: dto.ChannelId,
		AccountId: account.Id,
		//ApplicationId: session.ApplicationId,
		ApplicationId: applicationId,
		Data:          dto.Data,
		Status:        entities.StatusAllowed,
		CreatedAt:     dto.CreatedAt,
	}
	inbound, err := s.inboundRepository.Create(ctx, inboundCreate)
	if err != nil {
		// ERROR: unsupported Unicode escape sequence (SQLSTATE 22P05)
		s.logger.WithFields(logrus.Fields{
			"client_id":  dto.ClientId,
			"channel_id": dto.ChannelId,
			"account_id": account.Id,
			"msisdn":     msisdn,
			"data":       string(dto.Data),
		}).WithError(fmt.Errorf("%+v", err)).Errorln("error create inbound")
		return nil
		//return errors.WithStack(err)
	}

	inboundEvent := &events.ApplicationInboundEvent{
		Id:            inbound.Id,
		MId:           inbound.MId,
		ClientId:      inbound.ClientId,
		ChannelId:     inbound.ChannelId,
		AccountId:     inbound.AccountId,
		AccountAlias:  account.AccountAlias,
		ApplicationId: pointer.New(applicationId),
		//ApplicationId: pointer.Copy(inbound.ApplicationId),
		Data:      list.Copy(inbound.Data),
		CreatedAt: inbound.CreatedAt,
	}

	// key: client.channel.account-alias.inbound.application
	key := fmt.Sprintf(
		"%s.%s.%s.inbound.%s",
		inboundEvent.ClientId,
		inboundEvent.ChannelId,
		account.AccountAlias,
		applicationId,
	)
	s.logger.WithFields(
		logrus.Fields{
			"queue": key,
			"args":  inboundEvent.ToMap(),
		},
	).Infoln("Publishing Inbound Message To Application")
	if err = s.amqpPublisher.Publish(ctx, key, inboundEvent); err != nil {
		return errors.WithMessage(err, "Publishing Inbound Message To Application")
	}

	// CTWA
	// key: client.inbound.ctwa
	key = fmt.Sprintf("%s.inbound.ctwa", inboundEvent.ClientId)
	s.logger.WithFields(
		logrus.Fields{
			"queue": key,
			"args":  inboundEvent.ToMap(),
		},
	).Infoln("Publishing Inbound CTWA Message To Application")
	if err = s.amqpPublisher.Publish(ctx, key, inboundEvent); err != nil {
		return errors.WithMessage(err, "Publishing Inbound CTWA Message To Application")
	}

	// publish inbound event to all consumer
	// key: client.channel.account-alias.inbound.exchange
	key = fmt.Sprintf(
		"%s.%s.%s.inbound.exchange",
		inboundEvent.ClientId,
		inboundEvent.ChannelId,
		account.AccountAlias,
	)
	s.logger.WithFields(
		logrus.Fields{
			"queue": key,
			"args":  inboundEvent.ToMap(),
		},
	).Infoln("Publishing Inbound Message To Exchange")
	if err = s.amqpPublisher.ExchangePublish(ctx, key, amqp.ExchangeFanout, inboundEvent); err != nil {
		return errors.WithMessage(err, "Publishing Inbound Message To Exchange")
	}

	if forwardInbound {
		if outbound != nil {
			// key: client.channel.account-alias.inbound.application
			key = fmt.Sprintf(
				"%s.%s.%s.inbound.%s",
				inboundEvent.ClientId,
				inboundEvent.ChannelId,
				account.AccountAlias,
				outbound.ClientApplicationId,
			)
			s.logger.WithFields(
				logrus.Fields{
					"queue": key,
					"args":  inboundEvent.ToMap(),
				},
			).Infoln("Publishing Forward Inbound Message To Application")
			if err = s.amqpPublisher.Publish(ctx, key, inboundEvent); err != nil {
				s.logger.WithFields(
					logrus.Fields{
						"queue": key,
						"args":  inboundEvent.ToMap(),
					},
				).WithError(err).Errorln("Publishing Forward Inbound Message To Outbound Application")
			}
		}
	}

	return nil
}
