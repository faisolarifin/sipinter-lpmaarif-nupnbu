package entities

import (
	"encoding/json"
	"time"
)

type Status struct {
	Id            string
	OId           string
	XId           string
	MId           string
	ClientId      string
	ChannelId     string
	AccountId     string
	ApplicationId string
	Type          StatusType
	Error         *StatusError
	Data          json.RawMessage
	CreatedAt     time.Time
}

func (e *Status) ToMap() map[string]any {
	return map[string]any{
		"Id":            e.Id,
		"OId":           e.OId,
		"XId":           e.XId,
		"MId":           e.MId,
		"ClientId":      e.ClientId,
		"ChannelId":     e.ChannelId,
		"AccountId":     e.AccountId,
		"ApplicationId": e.ApplicationId,
		"Type":          e.Type,
		"Error":         e.Error,
		"Data":          string(e.Data),
		"CreatedAt":     e.CreatedAt,
	}
}

type StatusCreate struct {
	OId           string
	XId           string
	MId           string
	ClientId      string
	ChannelId     string
	AccountId     string
	ApplicationId string
	Type          StatusType
	Error         *StatusError
	Data          json.RawMessage
	CreatedAt     time.Time
}

func (e *StatusCreate) WithOId(oId string) *StatusCreate {
	e.OId = oId
	return e
}

func (e *StatusCreate) WithXId(xId string) *StatusCreate {
	e.XId = xId
	return e
}

func (e *StatusCreate) WithMId(mId string) *StatusCreate {
	e.MId = mId
	return e
}

func (e *StatusCreate) WithClientId(clientId string) *StatusCreate {
	e.ClientId = clientId
	return e
}

func (e *StatusCreate) WithChannelId(channelId string) *StatusCreate {
	e.ChannelId = channelId
	return e
}

func (e *StatusCreate) WithAccountId(accountId string) *StatusCreate {
	e.AccountId = accountId
	return e
}

func (e *StatusCreate) WithApplicationId(applicationId string) *StatusCreate {
	e.ApplicationId = applicationId
	return e
}

func (e *StatusCreate) WithType(typ StatusType) *StatusCreate {
	e.Type = typ
	return e
}

func (e *StatusCreate) WithError(error *StatusError) *StatusCreate {
	e.Error = error
	return e
}

func (e *StatusCreate) WithData(data json.RawMessage) *StatusCreate {
	e.Data = data
	return e
}

func (e *StatusCreate) WithCreatedAt(createdAt time.Time) *StatusCreate {
	e.CreatedAt = createdAt
	return e
}
