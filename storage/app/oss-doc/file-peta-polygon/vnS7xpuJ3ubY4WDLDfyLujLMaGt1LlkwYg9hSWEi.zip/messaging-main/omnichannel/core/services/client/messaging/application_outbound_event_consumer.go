package messaging

import (
	"context"
	"encoding/json"
	"fmt"
	"sync/atomic"
	"time"

	"core/events"
	"core/services/outbound"
	"core/services/outbound/dto"
	"framework/list"
	"framework/messaging"
	"framework/service"
	sharedentities "shared/entities"

	"github.com/pkg/errors"
	amqp "github.com/rabbitmq/amqp091-go"
	"github.com/sirupsen/logrus"
)

type ApplicationOutboundEventConsumer struct {
	state              int32
	queue              string
	applicationAccount *sharedentities.ApplicationAccount
	service            *outbound.Service
	amqpConsumer       *messaging.AMQPConsumer
	logger             *logrus.Entry
}

func NewApplicationOutboundEventConsumer(
	applicationAccount *sharedentities.ApplicationAccount,
	service *outbound.Service,
	amqpConsumer *messaging.AMQPConsumer,
	logger *logrus.Logger,
) *ApplicationOutboundEventConsumer {
	queue := fmt.Sprintf("%s.%s.%s.outbound.%s",
		applicationAccount.ClientId,
		applicationAccount.ChannelId,
		applicationAccount.AccountAlias,
		applicationAccount.ClientApplicationId,
	)
	return &ApplicationOutboundEventConsumer{
		queue:              queue,
		applicationAccount: applicationAccount,
		service:            service,
		amqpConsumer:       amqpConsumer,
		logger: logger.WithFields(
			logrus.Fields{
				"resource": "ApplicationOutboundEventConsumer",
				"queue":    queue,
			},
		),
	}
}

func (c *ApplicationOutboundEventConsumer) Consume() {
	if !atomic.CompareAndSwapInt32(&c.state, 0, 1) {
		return
	}

	c.logger.Infoln("Consume")
	logger := c.logger.WithField("func", "Consume")
	err := c.amqpConsumer.Consume(c.queue, func(delivery amqp.Delivery) {
		logger.WithField("body", string(delivery.Body)).Infoln("Consume Outbound Message")
		var event events.ApplicationOutboundEvent
		if err := json.Unmarshal(delivery.Body, &event); err != nil {
			logger.WithError(err).
				WithField("body", string(delivery.Body)).
				Errorln("JSON.Unmarshal")

			if err = delivery.Nack(false, false); err != nil {
				logger.WithError(err).Errorln("AMQPConsumer.Nack")
			}
			return
		}

		createDto := &dto.CreateDto{
			XId:           event.XId,
			ClientId:      event.ClientId,
			ChannelId:     event.ChannelId,
			AccountAlias:  event.AccountAlias,
			ApplicationId: event.ApplicationId,
			Data:          list.Copy(event.Data),
			CreatedAt:     time.Now().Local(),
		}
		logger.WithField("args", createDto.ToMap()).Infoln("Processing Outbound Message")
		err := c.service.Create(context.Background(), createDto)
		if err != nil {
			switch errors.Cause(err).(type) {
			case *service.ErrorValidation:
			default:
				logger.WithError(err).Errorln("Service.Create")
				if err = delivery.Nack(false, true); err != nil {
					logger.WithError(err).Errorln("AMQPConsumer.Nack")
				}
				return
			}
		}
		if err = delivery.Ack(false); err != nil {
			logger.WithError(err).Errorln("AMQPConsumer.Ack")
		}
	})
	if err != nil {
		logger.WithError(err).Errorln("AMQPConsumer.Consume")
	}
}

func (c *ApplicationOutboundEventConsumer) Stop() {
	if !atomic.CompareAndSwapInt32(&c.state, 1, 0) {
		return
	}
	c.logger.Infoln("Stop")
	c.amqpConsumer.Stop()
}
