package dto

import (
	"encoding/json"
	"strings"
	"time"

	sharedentities "shared/entities"

	uuid "github.com/satori/go.uuid"
	"github.com/tidwall/gjson"
)

type CreateDto struct {
	ClientId     string
	ChannelId    string
	AccountId    string
	AccountAlias string
	Data         json.RawMessage
	CreatedAt    time.Time
}

func (d *CreateDto) MId() string {
	var mid string
	switch sharedentities.NewChannel(d.ChannelId) {
	case sharedentities.ChannelWhatsApp:
		mid = gjson.GetBytes(d.Data, "messages.0.id").String()
	case sharedentities.ChannelWhatsAppCloud:
		mid = gjson.GetBytes(d.Data, "entry.0.changes.0.value.messages.0.id").String()
	case sharedentities.ChannelEmail:
		mid = strings.Replace(uuid.NewV1().String(), "-", "", -1)
	case sharedentities.ChannelInstagram:
		mid = gjson.GetBytes(d.Data, "entry.0.messaging.0.message.mid").String()
	}

	return mid
}

func (d *CreateDto) OId() string {
	var oid string
	switch sharedentities.NewChannel(d.ChannelId) {
	case sharedentities.ChannelWhatsApp:
		oid = gjson.GetBytes(d.Data, "messages.0.context.id").String()
	case sharedentities.ChannelWhatsAppCloud:
		oid = gjson.GetBytes(d.Data, "entry.0.changes.0.value.messages.0.context.id").String()
	case sharedentities.ChannelEmail:
	case sharedentities.ChannelInstagram:
	}

	return oid
}

func (d *CreateDto) Sender() string {
	var sender string
	switch sharedentities.NewChannel(d.ChannelId) {
	case sharedentities.ChannelWhatsApp:
		sender = gjson.GetBytes(d.Data, "messages.0.from").String()
	case sharedentities.ChannelWhatsAppCloud:
		sender = gjson.GetBytes(d.Data, "entry.0.changes.0.value.messages.0.from").String()
	case sharedentities.ChannelEmail:
		sender = gjson.GetBytes(d.Data, "data.from.email").String()
	case sharedentities.ChannelInstagram:
		sender = gjson.GetBytes(d.Data, "entry.0.messaging.0.recipient.id").String()
	}

	return sender
}

func (d *CreateDto) Type() string {
	var typ string
	switch sharedentities.NewChannel(d.ChannelId) {
	case sharedentities.ChannelWhatsApp:
		typ = gjson.GetBytes(d.Data, "messages.0.type").String()
	case sharedentities.ChannelWhatsAppCloud:
		typ = gjson.GetBytes(d.Data, "entry.0.changes.0.value.messages.0.type").String()
	case sharedentities.ChannelEmail:
	case sharedentities.ChannelInstagram:
	}

	return typ
}

func (d *CreateDto) ToMap() map[string]any {
	if d == nil {
		return nil
	}

	return map[string]any{
		"MId":          d.MId(),
		"ClientId":     d.ClientId,
		"ChannelId":    d.ChannelId,
		"AccountId":    d.AccountId,
		"AccountAlias": d.AccountAlias,
		"Sender":       d.Sender(),
		"Data":         string(d.Data),
		"CreatedAt":    d.CreatedAt,
	}
}
