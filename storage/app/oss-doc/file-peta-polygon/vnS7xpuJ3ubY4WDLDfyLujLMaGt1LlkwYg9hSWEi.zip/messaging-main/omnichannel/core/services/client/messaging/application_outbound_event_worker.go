package messaging

import (
	"context"
	"core/events"
	"core/services/outbound"
	"core/services/outbound/dto"
	"encoding/json"
	"framework/list"
	"framework/service"
	"github.com/pkg/errors"
	amqp "github.com/rabbitmq/amqp091-go"
	"github.com/sirupsen/logrus"
	"time"
)

type ApplicationOutboundEventWorker struct {
	logger  *logrus.Logger
	service *outbound.Service
}

func NewApplicationOutboundEventWorker(logger *logrus.Logger, service *outbound.Service) *ApplicationOutboundEventWorker {
	return &ApplicationOutboundEventWorker{logger: logger, service: service}
}

func (w *ApplicationOutboundEventWorker) Handle(delivery amqp.Delivery) {
	w.logger.Infoln("Consume")
	logger := w.logger.WithField("func", "Consume")
	logger.WithField("body", string(delivery.Body)).Infoln("Consume Outbound Message")
	var event events.ApplicationOutboundEvent
	if err := json.Unmarshal(delivery.Body, &event); err != nil {
		logger.WithError(err).
			WithField("body", string(delivery.Body)).
			Errorln("JSON.Unmarshal")
		if err = delivery.Nack(false, false); err != nil {
			logger.WithError(err).Errorln("AMQPConsumer.Nack")
		}
		return
	}

	createDto := &dto.CreateDto{
		XId:           event.XId,
		ClientId:      event.ClientId,
		ChannelId:     event.ChannelId,
		AccountAlias:  event.AccountAlias,
		ApplicationId: event.ApplicationId,
		Data:          list.Copy(event.Data),
		CreatedAt:     time.Now().Local(),
	}
	logger.WithField("args", createDto.ToMap()).Infoln("Processing Outbound Message")
	err := w.service.Create(context.Background(), createDto)
	if err != nil {
		switch errors.Cause(err).(type) {
		case *service.ErrorValidation:
		default:
			logger.WithError(err).Errorln("Service.Create")
			if err = delivery.Nack(false, true); err != nil {
				logger.WithError(err).Errorln("AMQPConsumer.Nack")
			}
			return
		}
	}
	if err = delivery.Ack(false); err != nil {
		logger.WithError(err).Errorln("AMQPConsumer.Ack")
	}
}
