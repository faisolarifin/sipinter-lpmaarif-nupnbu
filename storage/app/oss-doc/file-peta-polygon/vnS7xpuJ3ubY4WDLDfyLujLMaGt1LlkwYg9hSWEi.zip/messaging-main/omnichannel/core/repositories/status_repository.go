package repositories

import (
	"context"

	"core/entities"
)

type StatusRepository interface {
	Create(ctx context.Context, args *entities.StatusCreate) (*entities.Status, error)
}
