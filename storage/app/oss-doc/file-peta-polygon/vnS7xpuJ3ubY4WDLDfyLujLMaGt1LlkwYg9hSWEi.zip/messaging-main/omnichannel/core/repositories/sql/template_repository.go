package sql

import (
	"context"
	"core/entities"
	"framework/database"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/jackc/pgxutil"
	"github.com/pkg/errors"
)

type TemplateRepository struct {
	db *pgxpool.Pool
}

func newTemplateRepository(db *pgxpool.Pool) *TemplateRepository {
	return &TemplateRepository{db: db}
}

func (r TemplateRepository) FindByName(ctx context.Context, clientId, accountId, name string) (*entities.Template, error) {
	sql := `
		select t.id, t.name, tw.category_id
		from template.templates as t
			left join template.whatsapp as tw on t.id = tw.template_id
		where t.deleted_at is null
		  and t.client_id = @client_id
		  and t.account_id = @account_id
		  and t.name = @name
		limit 1
	`
	params := pgx.NamedArgs{
		"client_id":  clientId,
		"account_id": accountId,
		"name":       name,
	}

	result, err := pgxutil.SelectRow(ctx, r.db, sql, []any{params}, pgx.RowToAddrOfStructByName[entities.Template])
	if err != nil {
		if err.Error() == pgx.ErrNoRows.Error() {
			return nil, errors.WithStack(
				database.NewErrorNotFound("template with client id %s, account_id %s and name %s",
					clientId, accountId, name))
		}
		return nil, errors.WithMessage(err, "TemplateRepository.FindByName")
	}

	return result, nil
}
