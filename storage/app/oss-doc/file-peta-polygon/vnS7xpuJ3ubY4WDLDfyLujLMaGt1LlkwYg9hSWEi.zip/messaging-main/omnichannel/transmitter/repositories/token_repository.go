package repositories

import (
	"context"

	"transmitter/entities"
)

type TokenRepository interface {
	Find(ctx context.Context, clientId, channelId, accountId string) (*entities.Token, error)
}
