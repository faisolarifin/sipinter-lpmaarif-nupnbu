package entities

import (
	"fmt"
	"time"
)

type Contact struct {
	Id         string
	ClientId   string
	ChannelId  string
	AccountId  string
	MSISDN     string
	WhatsAppId string
	ExpiredAt  time.Time
	CreatedAt  time.Time
}

func (e *Contact) IsExpired() bool {
	if e == nil {
		return true
	}
	return e.CreatedAt.Before(time.Now().Local())
}

type ContactCreate struct {
	ClientId   string
	ChannelId  string
	AccountId  string
	MSISDN     string
	WhatsAppId string
	ExpiredAt  time.Time
	CreatedAt  time.Time
}

type ErrorContactNotFound struct {
	message string
}

func NewErrorContactNotFound(format string, args ...any) *ErrorContactNotFound {
	return &ErrorContactNotFound{message: fmt.Sprintf(format, args...)}
}

func (e *ErrorContactNotFound) Error() string {
	return e.message
}
