package whatsappcloud

import (
	"context"
	"crypto/tls"
	"framework/api"
	"github.com/go-resty/resty/v2"
	"github.com/pkg/errors"
)

type Client struct {
	options *Options
	client  *resty.Client
}

func NewClient(host string, options ...Option) *Client {
	opts := NewOptions(host)
	for _, option := range options {
		option(opts)
	}

	return NewClientWithOptions(opts)
}

func NewClientWithOptions(options *Options) *Client {
	client := resty.New()
	client.SetBaseURL(options.Host)

	if options.InsecureSkipVerify != nil {
		client.SetTLSClientConfig(
			&tls.Config{InsecureSkipVerify: *options.InsecureSkipVerify},
		)
	}
	if options.Timeout != nil {
		client.SetTimeout(*options.Timeout)
	}

	return &Client{options: options, client: client}
}

func (c *Client) Messages(ctx context.Context, token string, request any) (*api.Response[Messages], error) {
	response, err := c.client.NewRequest().
		SetDoNotParseResponse(true).
		SetAuthToken(token).
		SetBody(request).
		Post("/messages")
	if err != nil {
		return nil, errors.WithStack(err)
	}

	return api.NewResponse[Messages](response.RawResponse), nil
}
