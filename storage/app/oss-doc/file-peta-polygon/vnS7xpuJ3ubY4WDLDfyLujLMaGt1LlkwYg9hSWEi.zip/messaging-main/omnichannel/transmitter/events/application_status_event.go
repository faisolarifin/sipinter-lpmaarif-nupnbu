package events

import (
	"encoding/json"
	"fmt"
)

type ApplicationStatusEvent struct {
	Id            string          `json:"id"`
	OId           string          `json:"oid"`
	XId           string          `json:"xid"`
	MId           *string         `json:"mid,omitempty"`
	ClientId      string          `json:"client_id"`
	ChannelId     string          `json:"channel_id"`
	AccountId     string          `json:"account_id"`
	AccountAlias  string          `json:"account_alias"`
	ApplicationId string          `json:"application_id"`
	Type          string          `json:"type"`
	Error         *string         `json:"error,omitempty"`
	Data          json.RawMessage `json:"data,omitempty"`
}

func (e *ApplicationStatusEvent) Queue() string {
	return fmt.Sprintf("%s.%s.%s.status.%s", e.ClientId, e.ChannelId, e.AccountAlias, e.ApplicationId)
}

func (e *ApplicationStatusEvent) ToMap() map[string]any {
	return map[string]any{
		"Id":            e.Id,
		"OId":           e.OId,
		"XId":           e.XId,
		"MId":           e.MId,
		"ClientId":      e.ClientId,
		"ChannelId":     e.ChannelId,
		"AccountId":     e.AccountId,
		"AccountAlias":  e.AccountAlias,
		"ApplicationId": e.ApplicationId,
		"Type":          e.Type,
		"Error":         e.Error,
		"Data":          string(e.Data),
	}
}
