package services

import (
	"context"
	"encoding/json"
	"strings"
	"time"

	"framework/api"
	"framework/messaging"
	"framework/pointer"
	"framework/service"
	sharedentities "shared/entities"
	sharedrepositories "shared/repositories"
	"transmitter/entities"
	"transmitter/events"
	"transmitter/messenger/whatsapppremise"
	"transmitter/repositories"
	"transmitter/services/dto"

	"github.com/jackc/pgx/v5/pgconn"
	"github.com/pkg/errors"
	"github.com/sirupsen/logrus"
)

type Options struct {
	ContactTTL time.Duration
}

type WhatsAppPremiseService struct {
	account            *sharedentities.Account
	msisdnNormalizer   MSISDNNormalizer
	contactRateLimiter RateLimiter
	messageRateLimiter RateLimiter
	whatsappClient     *whatsapppremise.Client
	amqpPublisher      *messaging.AMQPPublisher
	clientRepository   sharedrepositories.ClientRepository
	accountRepository  sharedrepositories.AccountRepository
	contactRepository  repositories.ContactRepository
	tokenRepository    repositories.TokenRepository
	outboundRepository repositories.OutboundRepository
	logger             *logrus.Entry
	options            *Options
}

func (s *WhatsAppPremiseService) Transmit(ctx context.Context, dto *dto.OutboundDto) error {
	if s.account.ClientId != dto.ClientId || s.account.ChannelId != dto.ChannelId || s.account.AccountAlias != dto.AccountAlias {
		return errors.WithStack(service.NewErrorValidation("invalid routing"))
	}

	if strings.TrimSpace(dto.Id) == "" {
		return errors.WithStack(service.NewErrorValidation("id required"))
	}

	if strings.TrimSpace(dto.ClientId) == "" {
		return errors.WithStack(service.NewErrorValidation("client id required"))
	}

	if err := s.clientRepository.ExistById(ctx, dto.ClientId); err != nil {
		switch errors.Cause(err).(type) {
		case *sharedentities.ErrorClientNotFound:
			return errors.WithStack(service.NewErrorValidation(err.Error()))
		default:
			return errors.WithStack(err)
		}
	}

	if strings.TrimSpace(dto.ChannelId) == "" {
		return errors.WithStack(service.NewErrorValidation("channel id required"))
	}

	if err := sharedentities.IsChannelValid(dto.ChannelId); err != nil {
		return errors.WithStack(service.NewErrorValidation(err.Error()))
	}

	if strings.TrimSpace(dto.AccountAlias) == "" {
		return errors.WithStack(service.NewErrorValidation("account alias required"))
	}

	account, err := s.accountRepository.FindByChannelAndAlias(ctx, dto.ClientId, dto.ChannelId, dto.AccountAlias)
	if err != nil {
		switch errors.Cause(err).(type) {
		case *sharedentities.ErrorAccountNotFound:
			return errors.WithStack(service.NewErrorValidation(err.Error()))
		default:
			return errors.WithStack(err)
		}
	}

	if !account.IsActive {
		return errors.WithStack(service.NewErrorValidation("inactive account with channel %s and alias %s",
			dto.ChannelId, dto.AccountAlias))
	}

	if strings.TrimSpace(dto.ApplicationId) == "" {
		return errors.WithStack(service.NewErrorValidation("application required"))
	}

	now := time.Now().Local()
	token, err := s.tokenRepository.Find(ctx, dto.ClientId, dto.ChannelId, dto.AccountId)
	if err != nil {
		return errors.WithMessage(err, "WhatsAppOnPremisesService.Transmit TokenRepository.Find")
	}

	if err = token.IsExpired(now); err != nil {
		return errors.WithMessage(err, "WhatsAppOnPremisesService.Transmit Token Expired")
	}

	msisdn := s.msisdnNormalizer.Normalize(dto.To())
	contact, err := s.contactRepository.FindByMSISDN(ctx, dto.ClientId, dto.ChannelId, dto.AccountId, msisdn, now)
	if err != nil {
		switch errors.Cause(err).(type) {
		case *entities.ErrorContactNotFound:
		default:
			return errors.WithMessage(err, "WhatsAppOnPremisesService.Transmit ContactRepository.FindByMSISDN")
		}
	}

	// contact cache not found
	if (contact == nil) || (contact.IsExpired()) {
		if err = s.contactRateLimiter.Allowed(ctx, dto.ClientId, dto.ChannelId, dto.AccountId); err != nil {
			return errors.WithMessage(err, "WhatsAppOnPremisesService.Transmit ContactRateLimiter.Allowed")
		}

		var contacts *api.Response[whatsapppremise.Contacts]
		contacts, err = s.whatsappClient.Contacts(ctx, token.Token, whatsapppremise.NewContactRequest(msisdn))
		if err != nil {
			return errors.WithMessage(err, "WhatsAppOnPremisesService.Transmit WhatsAppClient.Contacts")
		}

		if contacts.IsError() {
			return errors.WithMessage(contacts.Error, "WhatsAppOnPremisesService.Transmit API.Response[whatsapp.Contacts]")
		}

		if contacts.Resource.IsError() {
			if err = s.outboundRepository.SetError(ctx, dto.Id, dto.ChannelId, "checking_contact", contacts.RawBody); err != nil {
				return errors.WithMessage(err, "WhatsAppOnPremisesService.Transmit OutboundRepository.SetError")
			}

			// TODO: publish status check contact error
			statusEvent := &events.ApplicationStatusEvent{
				Id:            dto.Id,
				XId:           dto.XId,
				MId:           nil,
				ClientId:      dto.ClientId,
				ChannelId:     dto.ChannelId,
				AccountId:     dto.AccountId,
				AccountAlias:  dto.AccountAlias,
				ApplicationId: dto.ApplicationId,
				Type:          "error",
				Error:         pointer.New("invalid_contact"),
				Data:          contacts.RawBody,
			}
			if err = s.amqpPublisher.Publish(ctx, statusEvent.Queue(), statusEvent); err != nil {
				return errors.WithStack(err)
			}
			return nil
		}

		contactCreate := &entities.ContactCreate{
			ClientId:   dto.ClientId,
			ChannelId:  dto.ChannelId,
			AccountId:  dto.AccountAlias,
			MSISDN:     msisdn,
			WhatsAppId: contacts.Resource.Contact().WhatsAppId,
			ExpiredAt:  time.Now().Local().Add(s.options.ContactTTL),
			CreatedAt:  time.Time{},
		}
		contact, err = s.contactRepository.Create(ctx, contactCreate)
		if err != nil {
			switch e := errors.Cause(err).(type) {
			case *pgconn.PgError:
				if e.Code == "23505" {
					contact, err = s.contactRepository.FindByMSISDN(
						ctx, dto.ClientId, dto.ChannelId, dto.AccountAlias, msisdn, now)
					if err != nil {
						return errors.WithMessage(err,
							"WhatsAppOnPremisesService.Transmit ContactRepository.FindByMSISDN")
					}
				} else {
					return errors.WithMessage(err, "WhatsAppOnPremisesService.Transmit ContactRepository.FindByMSISDN")
				}
			default:
				return errors.WithMessage(err, "WhatsAppOnPremisesService.Transmit ContactRepository.FindByMSISDN")
			}
		}
	}

	if err = s.messageRateLimiter.Allowed(ctx, dto.ClientId, dto.ChannelId, dto.AccountAlias); err != nil {
		return errors.WithMessage(err, "WhatsAppOnPremisesService.Transmit MessageRateLimiter.Allowed")
	}

	message := make(map[string]any)
	if err = json.Unmarshal(dto.Data, &message); err != nil {
		return errors.WithMessage(err, "WhatsAppOnPremisesService.Transmit JSON.Unmarshal")
	}

	message["to"] = contact.WhatsAppId
	messages, err := s.whatsappClient.Messages(ctx, token.Token, message)
	if err != nil {
		return errors.WithMessage(err, "WhatsAppOnPremisesService.Transmit WhatsAppClient.Messages")
	}

	if messages.IsError() {
		return errors.WithMessage(messages.Error, "WhatsAppOnPremisesService.Transmit API.Response[whatsapp.Messages]")
	}

	if messages.Resource.IsError() {
		if err = s.outboundRepository.SetError(ctx, dto.Id, dto.ChannelId, "sending_message", messages.RawBody); err != nil {
			return errors.WithMessage(err, "WhatsAppOnPremisesService.Transmit OutboundRepository.SetError")
		}

		// TODO: publish status send message error
		statusEvent := &events.ApplicationStatusEvent{
			Id:            dto.Id,
			XId:           dto.XId,
			MId:           nil,
			ClientId:      dto.ClientId,
			ChannelId:     dto.ChannelId,
			AccountId:     dto.AccountId,
			AccountAlias:  dto.AccountAlias,
			ApplicationId: dto.ApplicationId,
			Type:          "error",
			Error:         pointer.New("sending_message"),
			Data:          messages.RawBody,
		}
		if err = s.amqpPublisher.Publish(ctx, statusEvent.Queue(), statusEvent); err != nil {
			return errors.WithStack(err)
		}
		return nil
	}

	if err = s.outboundRepository.SetRequested(ctx, dto.Id, messages.Resource.Message().Id, dto.ChannelId, messages.RawBody); err != nil {
		return errors.WithMessage(err, "WhatsAppOnPremisesService.Transmit OutboundRepository.SetRequested")
	}
	statusEvent := &events.ApplicationStatusEvent{
		Id:            dto.Id,
		XId:           dto.XId,
		MId:           pointer.New(messages.Resource.Message().Id),
		ClientId:      dto.ClientId,
		ChannelId:     dto.ChannelId,
		AccountId:     dto.AccountId,
		AccountAlias:  dto.AccountAlias,
		ApplicationId: dto.ApplicationId,
		Type:          "requested",
		Data:          messages.RawBody,
	}
	if err = s.amqpPublisher.Publish(ctx, statusEvent.Queue(), statusEvent); err != nil {
		return errors.WithStack(err)
	}

	return nil
}
