package whatsapppremise

type ContactBlocking string

const (
	ContactBlockingWait   ContactBlocking = "wait"
	ContactBlockingNoWait ContactBlocking = "no_wait"
)

type ContactRequest struct {
	Blocking   ContactBlocking `json:"blocking"`
	Contacts   []string        `json:"contacts"`
	ForceCheck bool            `json:"force_check"`
}

func NewContactRequest(contacts ...string) *ContactRequest {
	return &ContactRequest{
		Blocking:   ContactBlockingWait,
		Contacts:   contacts,
		ForceCheck: true,
	}
}

func (r *ContactRequest) AddContact(contact string) *ContactRequest {
	r.Contacts = append(r.Contacts, contact)
	return r
}

func (r *ContactRequest) SetBlocking(blocking ContactBlocking) *ContactRequest {
	r.Blocking = blocking
	return r
}

func (r *ContactRequest) SetForceCheck(forceCheck bool) *ContactRequest {
	r.ForceCheck = forceCheck
	return r
}

type ContactStatus string

const (
	ContactStatusValid      ContactStatus = "valid"
	ContactStatusProcessing ContactStatus = "processing"
	ContactStatusInvalid    ContactStatus = "invalid"
	ContactStatusFailed     ContactStatus = "failed"
)

type Contacts struct {
	Contacts []*Contact `json:"contacts"`
	Errors   []*Error   `json:"errors,omitempty"`
}

func (r *Contacts) Contact() *Contact {
	if len(r.Contacts) < 1 {
		return &Contact{}
	}
	return r.Contacts[0]
}

func (r *Contacts) Error() *Error {
	if len(r.Errors) < 1 {
		return &Error{}
	}
	return r.Errors[0]
}

func (r *Contacts) IsError() bool {
	return len(r.Errors) > 0
}

func (r *Contacts) IsEmpty() bool {
	return len(r.Errors) < 1 && len(r.Contacts) < 1
}

type Contact struct {
	WhatsAppId string        `json:"wa_id"`
	Input      string        `json:"input"`
	Status     ContactStatus `json:"status"`
}
