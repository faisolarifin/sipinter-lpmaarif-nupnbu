package whatsappcloud

import (
	"time"

	"framework/pointer"
)

type Options struct {
	Host               string
	InsecureSkipVerify *bool
	Timeout            *time.Duration
}

func NewOptions(host string) *Options {
	return &Options{Host: host}
}

func (o *Options) SetInsecureSkipVerify(insecureSkipVerify bool) *Options {
	o.InsecureSkipVerify = pointer.New(insecureSkipVerify)
	return o
}

func (o *Options) SetTimeout(timeout time.Duration) *Options {
	o.Timeout = pointer.New(timeout)
	return o
}

type Option func(options *Options)

func InsecureSkipVerify(insecureSkipVerify bool) Option {
	return func(options *Options) {
		options.InsecureSkipVerify = pointer.New(insecureSkipVerify)
	}
}

func Timeout(timeout time.Duration) Option {
	return func(options *Options) {
		options.Timeout = pointer.New(timeout)
	}
}
