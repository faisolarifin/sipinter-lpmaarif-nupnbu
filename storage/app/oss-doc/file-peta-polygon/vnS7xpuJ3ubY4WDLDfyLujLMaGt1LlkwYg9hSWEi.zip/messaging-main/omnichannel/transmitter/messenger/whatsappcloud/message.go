package whatsappcloud

type Messages struct {
	MessagingProduct string     `json:"messaging_product,omitempty"`
	Contacts         []*Contact `json:"contacts,omitempty"`
	Messages         []*Message `json:"messages,omitempty"`
	Error            *ErrorData `json:"error,omitempty"`
}

func (r *Messages) Message() *Message {
	if len(r.Messages) < 1 {
		return &Message{}
	}
	return r.Messages[0]
}

func (r *Messages) IsError() bool {
	return r.Error != nil
}

func (r *Messages) IsEmpty() bool {
	return r.Error == nil && len(r.Messages) < 1
}

type Contact struct {
	Input string `json:"input"`
	WaId  string `json:"wa_id"`
}

type Message struct {
	Id string `json:"id"`
}
