package configuration

type WhatsappCloud struct {
	Host      string `json:"host"`
	Token     string `json:"token"`
	WabaId    string `json:"waba_id"`
	RateLimit struct {
		Media   int `json:"media"`
		Contact int `json:"contact"`
		Message int `json:"message"`
	} `json:"rate_limit"`
	PhoneNoId string `json:"phone_no_id"`
}

type WhatsappPremise struct {
	Fbm struct {
		Token     string `json:"token"`
		WabaId    string `json:"waba_id"`
		Namespace string `json:"namespace"`
	} `json:"fbm"`
	Host      string `json:"host"`
	User      string `json:"user"`
	Token     string `json:"token"`
	Password  string `json:"password"`
	ExpiredAt string `json:"expired_at"`
	RateLimit struct {
		Media   int `json:"media"`
		Contact int `json:"contact"`
		Message int `json:"message"`
	} `json:"rate_limit"`
}
