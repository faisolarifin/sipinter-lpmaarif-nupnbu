package services

import (
	"context"
	"encoding/json"
	"fmt"
	"framework/api"
	"framework/list"
	"framework/loggerx"
	"github.com/tidwall/gjson"
	"math"
	"strconv"
	"strings"
	"time"

	"framework/messaging"
	"framework/pointer"
	"framework/service"
	sharedentities "shared/entities"
	sharedrepositories "shared/repositories"
	"transmitter/events"
	"transmitter/messenger/whatsappcloud"
	"transmitter/repositories"
	"transmitter/services/dto"

	"github.com/pkg/errors"
	"github.com/sirupsen/logrus"
)

func NewWhatsAppCloudWaiService(
	account *sharedentities.Account,
	msisdnNormalizer MSISDNNormalizer,
	messageRateLimiter RateLimiter,
	whatsappClient *whatsappcloud.Client,
	amqpPublisher *messaging.AMQPPublisher,
	clientRepository sharedrepositories.ClientRepository,
	accountRepository sharedrepositories.AccountRepository,
	accountCountryRepository sharedrepositories.AccountCountryRepository,
	tokenRepository repositories.TokenRepository,
	outboundRepository repositories.OutboundRepository,
	logger *logrus.Logger,
) *WhatsAppCloudWaiService {
	return &WhatsAppCloudWaiService{
		account:                  account,
		msisdnNormalizer:         msisdnNormalizer,
		messageRateLimiter:       messageRateLimiter,
		whatsappClient:           whatsappClient,
		amqpPublisher:            amqpPublisher,
		clientRepository:         clientRepository,
		accountRepository:        accountRepository,
		accountCountryRepository: accountCountryRepository,
		tokenRepository:          tokenRepository,
		outboundRepository:       outboundRepository,
		logger: logger.WithFields(
			logrus.Fields{
				"resource": "WhatsAppCloudWaiService",
			},
		),
	}
}

type WhatsAppCloudWaiService struct {
	account                  *sharedentities.Account
	msisdnNormalizer         MSISDNNormalizer
	messageRateLimiter       RateLimiter
	whatsappClient           *whatsappcloud.Client
	amqpPublisher            *messaging.AMQPPublisher
	clientRepository         sharedrepositories.ClientRepository
	accountRepository        sharedrepositories.AccountRepository
	accountCountryRepository sharedrepositories.AccountCountryRepository
	tokenRepository          repositories.TokenRepository
	outboundRepository       repositories.OutboundRepository
	logger                   *logrus.Entry
}

func (s *WhatsAppCloudWaiService) Transmit(ctx context.Context, dto *dto.OutboundDto) error {
	logger := s.logger.WithFields(
		logrus.Fields{
			"client_id":     dto.ClientId,
			"channel_id":    dto.ChannelId,
			"account_alias": dto.AccountAlias,
			"xid":           dto.XId,
		},
	)

	if s.account.ClientId != dto.ClientId || s.account.ChannelId != dto.ChannelId || s.account.AccountAlias != dto.AccountAlias {
		return errors.WithStack(service.NewErrorValidation("invalid routing"))
	}

	if strings.TrimSpace(dto.Id) == "" {
		return errors.WithStack(service.NewErrorValidation("id required"))
	}

	if strings.TrimSpace(dto.ClientId) == "" {
		return errors.WithStack(service.NewErrorValidation("client id required"))
	}

	if err := s.clientRepository.ExistById(ctx, dto.ClientId); err != nil {
		switch errors.Cause(err).(type) {
		case *sharedentities.ErrorClientNotFound:
			return errors.WithStack(service.NewErrorValidation(err.Error()))
		default:
			return errors.WithStack(err)
		}
	}

	if strings.TrimSpace(dto.ChannelId) == "" {
		return errors.WithStack(service.NewErrorValidation("channel id required"))
	}

	if err := sharedentities.IsChannelValid(dto.ChannelId); err != nil {
		return errors.WithStack(service.NewErrorValidation(err.Error()))
	}

	if strings.TrimSpace(dto.AccountAlias) == "" {
		return errors.WithStack(service.NewErrorValidation("account alias required"))
	}

	account, err := s.accountRepository.FindByChannelAndAlias(ctx, dto.ClientId, dto.ChannelId, dto.AccountAlias)
	if err != nil {
		switch errors.Cause(err).(type) {
		case *sharedentities.ErrorAccountNotFound:
			return errors.WithStack(service.NewErrorValidation(err.Error()))
		default:
			return errors.WithStack(err)
		}
	}

	if !account.IsActive {
		return errors.WithStack(service.NewErrorValidation("inactive account with channel %s and alias %s",
			dto.ChannelId, dto.AccountAlias))
	}

	//
	// Expired message check
	//
	if dto.IsExpired() {
		if err = s.outboundRepository.SetError(
			ctx, dto.Id, dto.ChannelId, "sending_message", whatsappcloud.ErrorMessageAlreadyExpiredByte); err != nil {
			return errors.WithMessage(err, "WhatsAppOnCloudsService.Transmit OutboundRepository.SetError")
		}

		// TODO: publish status send message error
		statusEvent := &events.ApplicationStatusEvent{
			Id:            dto.Id,
			XId:           dto.XId,
			MId:           nil,
			ClientId:      dto.ClientId,
			ChannelId:     dto.ChannelId,
			AccountId:     dto.AccountId,
			AccountAlias:  dto.AccountAlias,
			ApplicationId: dto.ApplicationId,
			Type:          "error",
			Error:         pointer.New("sending_message"),
			Data:          json.RawMessage(whatsappcloud.ErrorMessageAlreadyExpiredByte),
		}

		s.logger.WithFields(logrus.Fields{"queue": statusEvent.Queue(), "message": statusEvent.ToMap()}).Infoln("publish error sending message")
		if err = s.amqpPublisher.Publish(ctx, statusEvent.Queue(), statusEvent); err != nil {
			return errors.WithStack(err)
		}

		return nil
	}

	//dto.NormalizedData()

	msisdn := s.msisdnNormalizer.Normalize(dto.To())

	//
	// Allowed sent message to another country
	//

	// build prefixes msisdn with length from 5 to 1 and + character
	var prefixes []string
	count := int(math.Min(float64(5), float64(len(msisdn))))
	if count > 0 {
		for i := 0; i < count-1; i++ {
			prefixes = append(prefixes, msisdn[:count-i])
		}
	}
	logger.WithField("prefixes", prefixes).Infoln("calculated prefixes")

	// if prefix not from indonesia check allowed country by prefix
	indonesiaPrefix := list.In("+62", prefixes)
	if !indonesiaPrefix {
		if !account.AllowedToOtherCountry {
			if err = s.outboundRepository.SetError(
				ctx, dto.Id, dto.ChannelId, "sending_message", whatsappcloud.ErrorNotAllowedSentMessageToAnotherCountryByte); err != nil {
				return errors.WithMessage(err, "WhatsAppCloudWaiService.Transmit OutboundRepository.SetError")
			}

			// TODO: publish status send message error
			statusEvent := &events.ApplicationStatusEvent{
				Id:            dto.Id,
				XId:           dto.XId,
				MId:           nil,
				ClientId:      dto.ClientId,
				ChannelId:     dto.ChannelId,
				AccountId:     dto.AccountId,
				AccountAlias:  dto.AccountAlias,
				ApplicationId: dto.ApplicationId,
				Type:          "error",
				Error:         pointer.New("sending_message"),
				Data:          json.RawMessage(whatsappcloud.ErrorNotAllowedSentMessageToAnotherCountryByte),
			}

			s.logger.WithFields(logrus.Fields{"queue": statusEvent.Queue(), "message": statusEvent.ToMap()}).Infoln("publish error sending message")
			if err = s.amqpPublisher.Publish(ctx, statusEvent.Queue(), statusEvent); err != nil {
				return errors.WithStack(err)
			}

			return nil
		} else {
			if !account.AllowedToAllOtherCountry {
				var accountCountries []*sharedentities.AccountCountry

				accountCountries, err = s.accountCountryRepository.GetByAccountAndPrefixes(ctx, dto.AccountId, prefixes)
				if err != nil {
					switch errors.Cause(err).(type) {
					case *sharedentities.ErrorAccountCountryNotFound:
					default:
						return errors.WithStack(err)
					}
				}

				if len(accountCountries) < 1 {
					if err = s.outboundRepository.SetError(
						ctx, dto.Id, dto.ChannelId, "sending_message", whatsappcloud.ErrorNotAllowedSentMessageToAnotherCountryByte); err != nil {
						return errors.WithMessage(err, "WhatsAppCloudWaiService.Transmit OutboundRepository.SetError")
					}

					// TODO: publish status send message error
					statusEvent := &events.ApplicationStatusEvent{
						Id:            dto.Id,
						XId:           dto.XId,
						MId:           nil,
						ClientId:      dto.ClientId,
						ChannelId:     dto.ChannelId,
						AccountId:     dto.AccountId,
						AccountAlias:  dto.AccountAlias,
						ApplicationId: dto.ApplicationId,
						Type:          "error",
						Error:         pointer.New("sending_message"),
						Data:          json.RawMessage(whatsappcloud.ErrorNotAllowedSentMessageToAnotherCountryByte),
					}

					s.logger.WithFields(logrus.Fields{"queue": statusEvent.Queue(), "message": statusEvent.ToMap()}).Infoln("publish error sending message")
					if err = s.amqpPublisher.Publish(ctx, statusEvent.Queue(), statusEvent); err != nil {
						return errors.WithStack(err)
					}

					return nil
				}
			}
		}
	}
	//
	// End allowed sent message to another country
	//

	if strings.TrimSpace(dto.ApplicationId) == "" {
		return errors.WithStack(service.NewErrorValidation("application required"))
	}

	now := time.Now().Local()
	token, err := s.tokenRepository.Find(ctx, dto.ClientId, dto.ChannelId, dto.AccountId)
	if err != nil {
		return errors.WithMessage(err, "WhatsAppCloudWaiService.Transmit TokenRepository.Find")
	}

	if err = token.IsExpired(now); err != nil {
		return errors.WithMessage(err, "WhatsAppCloudWaiService.Transmit Token Expired")
	}

	if err = s.messageRateLimiter.Allowed(ctx, dto.ClientId, dto.ChannelId, dto.AccountId); err != nil {
		return errors.WithMessage(err, "WhatsAppCloudWaiService.Transmit MessageRateLimiter.Allowed")
	}

	message := make(map[string]any)
	if err = json.Unmarshal(dto.Data, &message); err != nil {
		return errors.WithMessage(err, "WhatsAppCloudWaiService.Transmit JSON.Unmarshal")
	}

	var messages *api.Response[whatsappcloud.Messages]
	err = loggerx.Elapsed(logger, "transmitting message to whatsapp cloud", func() error {
		message["to"] = msisdn
		messages, err = s.whatsappClient.Messages(ctx, token.Token, message)
		if err != nil {
			return errors.WithMessage(err, "WhatsAppCloudWaiService.Transmit WhatsAppClient.Messages")
		}

		if messages.IsError() {
			return errors.WithMessage(messages.Error, "WhatsAppCloudWaiService.Transmit API.Response[whatsapp.Messages]")
		}

		return nil
	})

	status := strings.TrimSpace(gjson.GetBytes(messages.RawBody, "status").String())
	if status != "" {
		errCode, _ := strconv.Atoi(status)
		errMessage := strings.TrimSpace(gjson.GetBytes(messages.RawBody, "message").String())
		resource := &whatsappcloud.Messages{
			MessagingProduct: "",
			Contacts:         nil,
			Messages:         nil,
			Error: &whatsappcloud.ErrorData{
				Code:      errCode,
				Type:      "OAuthException",
				Message:   fmt.Sprintf("(#%d) %s", errCode, errMessage),
				FbtraceId: dto.XId,
			},
		}
		messages.Resource = resource
		messages.RawBody, _ = json.Marshal(messages.Resource)
	}

	if messages.Resource.IsError() {
		if err = s.outboundRepository.SetError(ctx, dto.Id, dto.ChannelId, "sending_message", messages.RawBody); err != nil {
			return errors.WithMessage(err, "WhatsAppCloudWaiService.Transmit OutboundRepository.SetError")
		}

		// TODO: publish status send message error
		statusEvent := &events.ApplicationStatusEvent{
			Id:            dto.Id,
			XId:           dto.XId,
			MId:           nil,
			ClientId:      dto.ClientId,
			ChannelId:     dto.ChannelId,
			AccountId:     dto.AccountId,
			AccountAlias:  dto.AccountAlias,
			ApplicationId: dto.ApplicationId,
			Type:          "error",
			Error:         pointer.New("sending_message"),
			Data:          messages.RawBody,
		}

		s.logger.WithFields(logrus.Fields{"queue": statusEvent.Queue(), "message": statusEvent.ToMap()}).Infoln("publish error sending message")
		if err = s.amqpPublisher.Publish(ctx, statusEvent.Queue(), statusEvent); err != nil {
			return errors.WithStack(err)
		}
		return nil
	}

	if err = s.outboundRepository.SetRequested(ctx, dto.Id, messages.Resource.Message().Id, dto.ChannelId, messages.RawBody); err != nil {
		return errors.WithMessage(err, "WhatsAppCloudWaiService.Transmit OutboundRepository.SetRequested")
	}

	statusEvent := &events.ApplicationStatusEvent{
		Id:            dto.Id,
		XId:           dto.XId,
		MId:           pointer.New(messages.Resource.Message().Id),
		ClientId:      dto.ClientId,
		ChannelId:     dto.ChannelId,
		AccountId:     dto.AccountId,
		AccountAlias:  dto.AccountAlias,
		ApplicationId: dto.ApplicationId,
		Type:          "requested",
		Data:          messages.RawBody,
	}
	if err = s.amqpPublisher.Publish(ctx, statusEvent.Queue(), statusEvent); err != nil {
		return errors.WithStack(err)
	}

	return nil
}
