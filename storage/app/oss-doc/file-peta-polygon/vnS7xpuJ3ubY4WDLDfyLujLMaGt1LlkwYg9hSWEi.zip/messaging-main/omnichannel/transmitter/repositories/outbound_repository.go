package repositories

import "context"

type OutboundRepository interface {
	SetError(ctx context.Context, id, channelId, err string, result any) error
	SetRequested(ctx context.Context, id, mid, channelId string, result any) error
}
