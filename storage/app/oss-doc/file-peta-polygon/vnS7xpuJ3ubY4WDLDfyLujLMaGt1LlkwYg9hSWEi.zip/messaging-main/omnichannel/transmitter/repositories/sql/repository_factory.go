package sql

import (
	"transmitter/repositories"

	"github.com/jackc/pgx/v5/pgxpool"
)

func NewRepositoryFactory(db *pgxpool.Pool) *RepositoryFactory {
	return &RepositoryFactory{db: db}
}

type RepositoryFactory struct {
	db *pgxpool.Pool
}

func (f *RepositoryFactory) NewContactRepository() repositories.ContactRepository {
	return newContactRepository(f.db)
}

func (f *RepositoryFactory) NewOutboundRepository() repositories.OutboundRepository {
	return newOutboundRepository(f.db)
}

func (f *RepositoryFactory) NewTokenRepository() repositories.TokenRepository {
	return newTokenRepository(f.db)
}
