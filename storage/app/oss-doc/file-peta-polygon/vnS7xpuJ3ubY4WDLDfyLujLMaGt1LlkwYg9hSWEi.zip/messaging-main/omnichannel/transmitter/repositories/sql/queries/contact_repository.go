package queries

const (
	contactRepositorySelect = `
		id,
		client_id,
		channel_id,
		account_id,
		msisdn,
		whatsapp_id,
		expired_at,
		created_at
	`

	ContactRepositoryCreate = `
		insert into whatsapp.contacts (
			client_id,
			channel_id,
			account_id,
			msisdn,
			whatsapp_id,
			expired_at,
			created_at		                               
		) values (
			:client_id,
			:channel_id,
			:account_id,
			:msisdn,
			:whatsapp_id,
			:expired_at,
			:created_at		          
		) returning ` + contactRepositorySelect

	ContactRepositoryFindByMSISDN = `
		select 
			` + contactRepositorySelect + `
		from whatsapp.contacts
		where
			client_id = :client_id
			and channel_id = :channel_id
			and account_id = :account_id
			and msisdn = :msisdn
			and expired_at::date < :before::date
		limit 1
			
	`
)
