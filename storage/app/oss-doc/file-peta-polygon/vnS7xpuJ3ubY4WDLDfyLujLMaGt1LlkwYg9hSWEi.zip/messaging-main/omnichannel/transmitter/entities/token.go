package entities

import (
	"fmt"
	"time"
)

type Token struct {
	Token     string     `json:"token"`
	ExpiredAt *time.Time `json:"expired_at"`
	//ExpiredAt *date.Date `json:"expired_at"`
}

func (e *Token) IsExpired(tm time.Time) error {
	if e.ExpiredAt == nil {
		return nil
	}

	//if !e.ExpiredAt.Time().UTC().Before(tm) {
	if e.ExpiredAt.Unix() <= tm.Unix() {
		return NewErrorTokenExpired("Token Expired At: %s", e.ExpiredAt)
	}

	return nil
}

type ErrorTokenNotFound struct {
	message string
}

func NewErrorTokenNotFound(format string, args ...any) *ErrorTokenNotFound {
	return &ErrorTokenNotFound{message: fmt.Sprintf(format, args...)}
}

func (e *ErrorTokenNotFound) Error() string {
	return e.message
}

type ErrorTokenExpired struct {
	message string
}

func NewErrorTokenExpired(format string, args ...any) *ErrorTokenExpired {
	return &ErrorTokenExpired{message: fmt.Sprintf(format, args...)}
}

func (e *ErrorTokenExpired) Error() string {
	return e.message
}
