package main

import "transmitter/cmd"

func main() {
	cmd.Execute()
}
