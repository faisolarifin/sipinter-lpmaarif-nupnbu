package messaging

import (
	"context"
	"core/events"
	"encoding/json"
	"framework/list"
	amqp "github.com/rabbitmq/amqp091-go"
	"github.com/sirupsen/logrus"
	"transmitter/services"
	"transmitter/services/dto"
)

type OutboundEventWorker struct {
	logger  *logrus.Logger
	service services.Service
}

func NewOutboundEventWorker(logger *logrus.Logger, service services.Service) *OutboundEventWorker {
	return &OutboundEventWorker{logger: logger, service: service}
}

func (w *OutboundEventWorker) Handle(delivery amqp.Delivery) {
	w.logger.Infoln("Consume")
	logger := w.logger.WithField("func", "Consume")
	logger.WithField("body", string(delivery.Body)).Infoln("Consume Outbound Message")
	var event events.TransmitterOutboundEvent
	if err := json.Unmarshal(delivery.Body, &event); err != nil {
		logger.WithError(err).
			WithField("body", string(delivery.Body)).
			Errorln("JSON.Unmarshal")
		if err = delivery.Nack(false, false); err != nil {
			logger.WithError(err).Errorln("AMQPConsumer.Nack")
		}
		return
	}

	outbound := &dto.OutboundDto{
		Id:            event.Id,
		XId:           event.XId,
		ClientId:      event.ClientId,
		ChannelId:     event.ChannelId,
		AccountId:     event.AccountId,
		AccountAlias:  event.AccountAlias,
		ApplicationId: event.ApplicationId,
		Type:          event.Type,
		Data:          list.Copy(event.Data),
	}
	err := w.service.Transmit(context.Background(), outbound)
	if err != nil {
		logger.WithError(err).Errorln("Service.Transmit")
		if err = delivery.Nack(false, true); err != nil {
			logger.WithError(err).Errorln("AMQPConsumer.Nack")
		}
		return
	}
	if err = delivery.Ack(false); err != nil {
		logger.WithError(err).Errorln("AMQPConsumer.Ack")
	}
}
