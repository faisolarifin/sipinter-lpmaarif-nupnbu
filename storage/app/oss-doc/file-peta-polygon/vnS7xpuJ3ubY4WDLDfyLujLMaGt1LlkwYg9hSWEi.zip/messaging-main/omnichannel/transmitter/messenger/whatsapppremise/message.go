package whatsapppremise

type Messages struct {
	Messages []*Message `json:"messages"`
	Errors   []*Error   `json:"errors,omitempty"`
}

func (r *Messages) Message() *Message {
	if len(r.Messages) < 1 {
		return &Message{}
	}
	return r.Messages[0]
}

func (r *Messages) Error() *Error {
	if len(r.Errors) < 1 {
		return &Error{}
	}
	return r.Errors[0]
}

func (r *Messages) IsError() bool {
	return len(r.Errors) > 0
}

func (r *Messages) IsEmpty() bool {
	return len(r.Errors) < 1 && len(r.Messages) < 1
}

type Message struct {
	Id string `json:"id"`
}
