package repositories

type RepositoryFactory interface {
	NewContactRepository() ContactRepository
	NewOutboundRepository() OutboundRepository
	NewTokenRepository() TokenRepository
}
