package services

import (
	"context"

	"transmitter/services/dto"
)

type Service interface {
	Transmit(ctx context.Context, dto *dto.OutboundDto) error
}
