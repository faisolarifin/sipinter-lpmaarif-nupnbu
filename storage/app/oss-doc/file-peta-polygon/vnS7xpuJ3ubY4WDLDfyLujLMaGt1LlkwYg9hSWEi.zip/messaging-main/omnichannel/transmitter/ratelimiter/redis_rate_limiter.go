package ratelimiter

import (
	"context"
	"fmt"
	"github.com/go-redis/redis/v8"
	"github.com/pkg/errors"
	"github.com/ulule/limiter/v3"
	redisstore "github.com/ulule/limiter/v3/drivers/store/redis"
	"time"
)

func NewRedisRateLimiter(client *redis.Client, options *Options) *RedisRateLimiter {
	rate := limiter.Rate{Period: options.Period, Limit: options.Limit}
	store, _ := redisstore.NewStore(client)
	return &RedisRateLimiter{
		limiter: limiter.New(store, rate),
	}
}

type RedisRateLimiter struct {
	limiter *limiter.Limiter
}

func (r *RedisRateLimiter) Allowed(ctx context.Context, clientId, channelId, accountId string) error {
	key := fmt.Sprintf("%s.%s.%s", clientId, channelId, accountId)
	limit, err := r.limiter.Get(ctx, key)
	if err != nil {
		return errors.WithMessage(err, "RedisRateLimiter.Allowed Limiter.Get")
	}

	if limit.Reached {
		time.Sleep(r.limiter.Rate.Period)
		return NewErrorLimitExceed("ClientId: %s, ChannelId: %s, AccountId: %s, Key: %s Reached Rate Limit",
			clientId, channelId, accountId, key)
	}

	return nil
}
