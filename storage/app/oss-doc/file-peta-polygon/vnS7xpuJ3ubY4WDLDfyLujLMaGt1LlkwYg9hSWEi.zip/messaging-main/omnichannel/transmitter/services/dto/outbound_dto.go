package dto

import (
	"encoding/json"
	"strings"
	"time"

	coreentities "core/entities"
	sharedentities "shared/entities"

	uuid "github.com/satori/go.uuid"
	"github.com/tidwall/gjson"
)

type OutboundDto struct {
	Id            string
	XId           string
	ClientId      string
	ChannelId     string
	AccountId     string
	AccountAlias  string
	ApplicationId string
	Type          coreentities.OutboundType
	Data          json.RawMessage
}

func (d *OutboundDto) To() string {
	var to string
	switch sharedentities.NewChannel(d.ChannelId) {
	case sharedentities.ChannelWhatsApp:
		to = gjson.GetBytes(d.Data, "to").String()
	case sharedentities.ChannelWhatsAppCloud:
		to = gjson.GetBytes(d.Data, "to").String()
	case sharedentities.ChannelEmail:
		to = strings.Replace(uuid.NewV1().String(), "-", "", -1)
	}

	return to
}

func (d *OutboundDto) IsExpired() bool {
	expStr := gjson.GetBytes(d.Data, "expired_at").String()
	if expStr == "" {
		return false
	}

	loc, _ := time.LoadLocation("Asia/Jakarta")
	t, err := time.ParseInLocation("2006-01-02 15:04", expStr, loc)
	if nil != err {
		return false
	}

	return t.Before(time.Now())
}

func (d *OutboundDto) NormalizedData() {
	data := gjson.ParseBytes(d.Data).Map()
	if _, ok := data["expired_at"]; ok {
		delete(data, "expired_at")
	}

	d.Data, _ = json.Marshal(data)
}

func (d *OutboundDto) ToMap() map[string]any {
	return map[string]any{
		"Id":            d.Id,
		"XId":           d.XId,
		"ClientId":      d.ClientId,
		"GetChannelId":  d.ChannelId,
		"AccountId":     d.AccountId,
		"AccountAlias":  d.AccountAlias,
		"ApplicationId": d.ApplicationId,
		"Type":          d.Type,
		"Data":          d.Data,
	}
}
