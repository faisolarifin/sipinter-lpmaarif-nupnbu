package queries

const (
	TokenRepositoryFind = `
		select
			configuration ->> 'token'            as token,
			(configuration ->> 'expired_at')::timestamptz as expired_at
-- 			(configuration ->> 'expired_at')::date as expired_at
		from public.client_accounts
		where 
			deleted_at is null
			and client_id = :client_id
			and channel_id = :channel_id
			and id = :id
	`
)
