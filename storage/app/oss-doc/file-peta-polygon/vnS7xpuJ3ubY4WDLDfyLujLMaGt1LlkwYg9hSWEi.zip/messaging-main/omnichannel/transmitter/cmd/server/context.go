package server

import (
	"framework/amqpx"
	"framework/messaging"
	sharedrepositories "shared/repositories"
	transmittermessaging "transmitter/messaging"
	transmitterrepositories "transmitter/repositories"
	transmitterservices "transmitter/services"

	"github.com/go-redis/redis/v8"
	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/sirupsen/logrus"
	"github.com/spf13/viper"
)

type CustomContext struct {
	conf                         *viper.Viper
	logger                       *logrus.Logger
	db                           *pgxpool.Pool
	redis                        *redis.Client
	amqpReader                   *amqpx.Pool
	amqpWriter                   *amqpx.Pool
	amqpMessagingFactory         *messaging.AMQPConnectionFactory
	sharedRepositoryFactory      sharedrepositories.RepositoryFactory
	transmitterRepositoryFactory transmitterrepositories.RepositoryFactory
	transmitterServiceFactory    *transmitterservices.ServiceFactory
	outboundEventConsumerFactory *transmittermessaging.OutboundEventConsumerFactory
}

func (c *CustomContext) Config() *viper.Viper {
	return c.conf
}

func (c *CustomContext) Logger() *logrus.Logger {
	return c.logger
}

func (c *CustomContext) DB() *pgxpool.Pool {
	return c.db
}

func (c *CustomContext) Redis() *redis.Client {
	return c.redis
}

func (c *CustomContext) AMQPReader() *amqpx.Pool {
	return c.amqpReader
}

func (c *CustomContext) AMQPWriter() *amqpx.Pool {
	return c.amqpWriter
}

func (c *CustomContext) AMQPMessagingFactory() *messaging.AMQPConnectionFactory {
	return c.amqpMessagingFactory
}

func (c *CustomContext) SharedRepositoryFactory() sharedrepositories.RepositoryFactory {
	return c.sharedRepositoryFactory
}

func (c *CustomContext) TransmitterRepositoryFactory() transmitterrepositories.RepositoryFactory {
	return c.transmitterRepositoryFactory
}

func (c *CustomContext) TransmitterServiceFactory() *transmitterservices.ServiceFactory {
	return c.transmitterServiceFactory
}

func (c *CustomContext) OutboundEventConsumerFactory() *transmittermessaging.OutboundEventConsumerFactory {
	return c.outboundEventConsumerFactory
}
