package server

import (
	"context"
	"framework/kernel"
	"framework/kernel/bootstrap"
	"framework/kernel/config"
	"framework/messaging"
	sharedentities "shared/entities"
	sharedsqlrepository "shared/repositories/sql"
	"transmitter/internal"
	transmittermessaging "transmitter/messaging"
	transmittersqlrepository "transmitter/repositories/sql"
	"transmitter/services"

	"github.com/sirupsen/logrus"
	"github.com/spf13/viper"
)

var banner = `


  ___ ___  ___ _____ ___ ___  __   ______  _____ ___    _   _  _ ___ __  __ ___ _____ _____ ___ ___ 
 / __/ _ \/ __|_   _| __| _ \ \ \ / /__ / |_   _| _ \  /_\ | \| / __|  \/  |_ _|_   _|_   _| __| _ \
| (_| (_) \__ \ | | | _||   /  \ V / |_ \   | | |   / / _ \| .  \__ \ |\/| || |  | |   | | | _||   /
 \___\___/|___/ |_| |___|_|_\   \_/ |___/   |_| |_|_\/_/ \_\_|\_|___/_|  |_|___| |_|   |_| |___|_|_\

 Version: %s
 Author : %s


`

func New() kernel.Kernel[*CustomContext] {
	server := kernel.NewBuilder[*CustomContext]().
		NewContext(func(conf *viper.Viper, logger *logrus.Logger) *CustomContext {
			return &CustomContext{
				conf:   conf,
				logger: logger,
			}
		}).
		ConfigureConfiguration(func() config.Options {
			return config.NewFileOptions().
				SetName("transmitter")
		}).
		// bootstrapping resources
		Bootstrap(func() []kernel.BootstrapFn[*CustomContext] {
			return []kernel.BootstrapFn[*CustomContext]{
				// initialize db
				func(ctx *CustomContext) func(ctx *CustomContext) {
					ctx.Logger().Infoln("connecting database")
					ctx.db = bootstrap.DB(context.Background(), ctx)
					ctx.Logger().Infoln("database connected")
					// finalize db
					return func(ctx *CustomContext) {
						ctx.Logger().Infoln("disconnecting database")
						ctx.db.Close()
						ctx.Logger().Infoln("database disconnected")
					}
				},
				// initialize redis
				func(ctx *CustomContext) func(ctx *CustomContext) {
					ctx.Logger().Infoln("connecting redis")
					ctx.redis = bootstrap.Redis(context.Background(), ctx)
					ctx.Logger().Infoln("redis connected")
					// finalize redis
					return func(ctx *CustomContext) {
						ctx.Logger().Infoln("disconnecting redis")
						if err := ctx.redis.Close(); err != nil {
							ctx.Logger().WithError(err).Infoln("redis disconnected")
						} else {
							ctx.Logger().Infoln("redis disconnected")
						}
					}
				},
				// initialize amqp reader
				func(ctx *CustomContext) func(ctx *CustomContext) {
					ctx.Logger().Infoln("connecting amqp reader")
					ctx.amqpReader = bootstrap.AMQPXPool(ctx)
					ctx.Logger().Infoln("amqp reader connected")
					// finalize amqp
					return func(ctx *CustomContext) {
						ctx.Logger().Infoln("disconnecting amqp reader")
						if err := ctx.amqpReader.Close(); err != nil {
							ctx.Logger().WithError(err).Errorln("amqp reader disconnected")
						} else {
							ctx.Logger().Infoln("amqp reader disconnected")
						}
					}
				},
				// initialize amqp writer
				func(ctx *CustomContext) func(ctx *CustomContext) {
					ctx.Logger().Infoln("connecting amqp writer")
					ctx.amqpWriter = bootstrap.AMQPXPool(ctx)
					ctx.Logger().Infoln("amqp writer connected")
					// finalize amqp
					return func(ctx *CustomContext) {
						ctx.Logger().Infoln("disconnecting amqp writer")
						if err := ctx.amqpWriter.Close(); err != nil {
							ctx.Logger().WithError(err).Errorln("amqp writer disconnected")
						} else {
							ctx.Logger().Infoln("amqp writer disconnected")
						}
					}
				},
			}
		}).
		// bootstrapping repositories
		Bootstrap(func() []kernel.BootstrapFn[*CustomContext] {
			return []kernel.BootstrapFn[*CustomContext]{
				kernel.BootstrapNoCleanup(func(ctx *CustomContext) {
					ctx.Logger().Infoln("bootstrapping shared repository factory")
					ctx.sharedRepositoryFactory = sharedsqlrepository.NewRepositoryFactory(ctx.DB())
					ctx.Logger().Infoln("bootstrapping transmitter repository factory")
					ctx.transmitterRepositoryFactory = transmittersqlrepository.NewRepositoryFactory(ctx.DB())
				}),
			}
		}).
		// bootstrapping messaging
		Bootstrap(func() []kernel.BootstrapFn[*CustomContext] {
			return []kernel.BootstrapFn[*CustomContext]{
				kernel.BootstrapNoCleanup(func(ctx *CustomContext) {
					ctx.Logger().Infoln("bootstrapping amqp messaging factory")
					ctx.amqpMessagingFactory = messaging.NewAMQPConnectionFactory(ctx.AMQPReader(), ctx.AMQPWriter())
				}),
			}
		}).
		// bootstrapping services
		Bootstrap(func() []kernel.BootstrapFn[*CustomContext] {
			return []kernel.BootstrapFn[*CustomContext]{
				// initialize transmitter service factory
				kernel.BootstrapNoCleanup(func(ctx *CustomContext) {
					ctx.Logger().Infoln("bootstrapping transmitter service factory")
					ctx.transmitterServiceFactory = services.NewServiceFactory(
						ctx.Redis(),
						ctx.AMQPMessagingFactory(),
						ctx.SharedRepositoryFactory(),
						ctx.TransmitterRepositoryFactory(),
						ctx.Logger(),
					)
				}),
			}
		}).
		// messaging consumer
		Bootstrap(func() []kernel.BootstrapFn[*CustomContext] {
			return []kernel.BootstrapFn[*CustomContext]{
				// initialize transmitter service factory
				kernel.BootstrapNoCleanup(func(ctx *CustomContext) {
					ctx.Logger().Infoln("bootstrapping messaging consumer factory")
					ctx.outboundEventConsumerFactory = transmittermessaging.NewOutboundEventConsumerFactory(
						ctx.TransmitterServiceFactory(),
						ctx.AMQPMessagingFactory(),
						ctx.Logger(),
					)
				}),
			}
		}).
		Run(func(ctx *CustomContext) []kernel.RunFn {
			return []kernel.RunFn{
				func(stop chan struct{}) {
					var consumers []*transmittermessaging.OutboundEventWorkerConsumer
					//var consumers []*transmittermessaging.OutboundEventConsumer

					accountRepository := ctx.SharedRepositoryFactory().NewAccountRepository()
					accounts, err := accountRepository.GetAllExceptChannels(context.Background(), []string{
						sharedentities.ChannelSMS.String(),
						sharedentities.ChannelEmail.String(),
						sharedentities.ChannelInstagram.String(),
					})
					if err != nil {
						panic(err)
					}

					categories := []string{"template", "template-authentication", "template-marketing", "template-utility"}
					for _, account := range accounts {
						interactiveOutboundEventConsumer := ctx.OutboundEventConsumerFactory().
							NewOutboundEventWorkerConsumer("interactive", account)
						//NewOutboundEventConsumer("interactive", account)
						interactiveOutboundEventConsumer.Consume()

						for _, category := range categories {
							templateOutboundEventConsumer := ctx.OutboundEventConsumerFactory().
								NewOutboundEventWorkerConsumer(category, account)
							//NewOutboundEventConsumer(category, account)
							templateOutboundEventConsumer.Consume()
							consumers = append(consumers, templateOutboundEventConsumer)
						}

						consumers = append(consumers, interactiveOutboundEventConsumer)
					}

					<-stop
					for _, consumer := range consumers {
						consumer.Stop()
					}
				},
			}
		}).
		Startup(func(ctx *CustomContext) {
			ctx.Logger().Infof(banner, internal.Version, internal.Author)
			ctx.Logger().Infoln("startup")
		}).
		Shutdown(func(ctx *CustomContext) {
			ctx.Logger().Infoln("shutdown")
		}).Build()

	return server
}
