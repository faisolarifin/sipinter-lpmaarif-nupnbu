package messaging

import (
	"context"
	"encoding/json"
	"fmt"
	"framework/messaging"
	"sync/atomic"

	"core/events"
	"framework/list"
	sharedentities "shared/entities"
	"transmitter/services"
	"transmitter/services/dto"

	amqp "github.com/rabbitmq/amqp091-go"
	"github.com/sirupsen/logrus"
)

type OutboundEventConsumer struct {
	state        int32
	typz         string
	queue        string
	account      *sharedentities.Account
	service      services.Service
	amqpConsumer *messaging.AMQPConsumer
	logger       *logrus.Entry
}

func NewOutboundEventConsumer(
	typz string,
	account *sharedentities.Account,
	service services.Service,
	amqpConsumer *messaging.AMQPConsumer,
	logger *logrus.Logger,
) *OutboundEventConsumer {
	queue := fmt.Sprintf("%s.%s.%s.outbound-%s",
		account.ClientId,
		account.ChannelId,
		account.AccountAlias,
		typz,
	)
	return &OutboundEventConsumer{
		typz:         typz,
		queue:        queue,
		account:      account,
		service:      service,
		amqpConsumer: amqpConsumer,
		logger: logger.WithFields(
			logrus.Fields{
				"resource": "OutboundEventConsumer",
				"queue":    queue,
			},
		),
	}
}

func (c *OutboundEventConsumer) Consume() {
	if !atomic.CompareAndSwapInt32(&c.state, 0, 1) {
		return
	}

	c.logger.Infoln("Consume")
	logger := c.logger.WithField("func", "Consume")
	err := c.amqpConsumer.Consume(c.queue, func(delivery amqp.Delivery) {
		logger.WithField("body", string(delivery.Body)).Infoln("Consume Outbound Message")
		var event events.TransmitterOutboundEvent
		if err := json.Unmarshal(delivery.Body, &event); err != nil {
			logger.WithError(err).
				WithField("body", string(delivery.Body)).
				Errorln("JSON.Unmarshal")
			return
		}

		outbound := &dto.OutboundDto{
			Id:            event.Id,
			XId:           event.XId,
			ClientId:      event.ClientId,
			ChannelId:     event.ChannelId,
			AccountId:     event.AccountId,
			AccountAlias:  event.AccountAlias,
			ApplicationId: event.ApplicationId,
			Type:          event.Type,
			Data:          list.Copy(event.Data),
		}
		err := c.service.Transmit(context.Background(), outbound)
		if err != nil {
			logger.WithError(err).Errorln("Service.Transmit")
			if err = delivery.Nack(false, true); err != nil {
				logger.WithError(err).Errorln("AMQPConsumer.Nack")
			}
			return
		}
		if err = delivery.Ack(false); err != nil {
			logger.WithError(err).Errorln("AMQPConsumer.Ack")
		}
	})
	if err != nil {
		logger.WithError(err).Errorln("AMQPConsumer.Consume")
	}
}

func (c *OutboundEventConsumer) Stop() {
	if !atomic.CompareAndSwapInt32(&c.state, 1, 0) {
		return
	}
	c.logger.Infoln("Stop")
	c.amqpConsumer.Stop()
}
