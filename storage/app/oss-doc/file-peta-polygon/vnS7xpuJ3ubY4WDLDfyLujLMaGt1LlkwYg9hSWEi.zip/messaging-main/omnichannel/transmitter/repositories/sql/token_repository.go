package sql

import (
	"context"

	"framework/database"
	"transmitter/entities"
	"transmitter/repositories/sql/queries"

	"github.com/jackc/pgx/v5"
	"github.com/pkg/errors"
)

func newTokenRepository(db database.Querier) *TokenRepository {
	return &TokenRepository{
		db: db,
	}
}

type TokenRepository struct {
	db database.Querier
}

func (r *TokenRepository) Find(ctx context.Context, clientId, channelId, accountId string) (*entities.Token, error) {
	namedArgs := map[string]any{
		"client_id":  clientId,
		"channel_id": channelId,
		"id":         accountId,
	}
	query, params, err := database.NamedQuery(queries.TokenRepositoryFind, namedArgs)
	if err != nil {
		return nil, errors.WithMessage(err, "TokenRepository.Find NamedQuery")
	}

	var token entities.Token
	row := r.db.QueryRow(ctx, query, params...)
	if err = r.scan(row, &token); err != nil {
		if err == pgx.ErrNoRows {
			return nil, errors.WithStack(
				entities.NewErrorTokenNotFound("token with client id %s, channel id %s and account id %s not found",
					clientId, channelId, accountId))
		}
		return nil, errors.WithMessage(err, "TokenRepository.Token QueryRow")
	}

	return &token, nil
}

func (r *TokenRepository) scan(scanner database.RowScanner, token *entities.Token) error {
	return scanner.Scan(
		&token.Token,
		&token.ExpiredAt,
	)
}
