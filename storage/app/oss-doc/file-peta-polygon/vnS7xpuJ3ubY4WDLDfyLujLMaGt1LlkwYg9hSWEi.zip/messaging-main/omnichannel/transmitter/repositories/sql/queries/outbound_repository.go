package queries

const (
	OutboundRepositorySetError = `
		update "%s".outbounds
		set
		    error = :error,
		    result = :result
		where
		    id = :id
	`

	OutboundRepositorySetRequested = `
		update "%s".outbounds
		set
		    mid = :mid,
		    result = :result
		where
		    id = :id
	`
)
