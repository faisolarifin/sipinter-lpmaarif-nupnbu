package sql

import (
	"context"
	"fmt"

	"framework/database"
	"transmitter/repositories/sql/queries"

	"github.com/pkg/errors"
)

func newOutboundRepository(db database.Querier) *OutboundRepository {
	return &OutboundRepository{db: db}
}

type OutboundRepository struct {
	db database.Querier
}

func (r *OutboundRepository) SetError(ctx context.Context, id, channelId, err string, result any) error {
	namedArgs := map[string]any{
		"id":     id,
		"error":  err,
		"result": result,
	}
	query, params, e := database.NamedQuery(
		r.bindScheme(channelId, queries.OutboundRepositorySetError), namedArgs)
	if e != nil {
		return errors.WithMessage(e, "OutboundRepository.SetError NamedQuery")
	}

	_, e = r.db.Exec(ctx, query, params...)
	if e != nil {
		return errors.WithMessage(e, "OutboundRepository.SetError Exec")
	}

	return nil
}

func (r *OutboundRepository) SetRequested(ctx context.Context, id, mid, channelId string, result any) error {
	namedArgs := map[string]any{
		"id":     id,
		"mid":    mid,
		"result": result,
	}
	query, params, e := database.NamedQuery(
		r.bindScheme(channelId, queries.OutboundRepositorySetRequested), namedArgs)
	if e != nil {
		return errors.WithMessage(e, "OutboundRepository.SetRequested NamedQuery")
	}

	_, e = r.db.Exec(ctx, query, params...)
	if e != nil {
		return errors.WithMessage(e, "OutboundRepository.SetRequested Exec")
	}

	return nil
}

func (r *OutboundRepository) bindScheme(channelId, sql string) string {
	return fmt.Sprintf(sql, channelId)
}
