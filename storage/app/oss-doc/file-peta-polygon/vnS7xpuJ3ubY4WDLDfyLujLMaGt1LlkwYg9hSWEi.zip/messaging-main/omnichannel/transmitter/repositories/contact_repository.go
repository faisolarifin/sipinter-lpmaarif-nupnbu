package repositories

import (
	"context"
	"time"

	"transmitter/entities"
)

type ContactRepository interface {
	Create(ctx context.Context, args *entities.ContactCreate) (*entities.Contact, error)
	FindByMSISDN(ctx context.Context, clientId, channelId, accountId, msisdn string, before time.Time) (*entities.Contact, error)
}
