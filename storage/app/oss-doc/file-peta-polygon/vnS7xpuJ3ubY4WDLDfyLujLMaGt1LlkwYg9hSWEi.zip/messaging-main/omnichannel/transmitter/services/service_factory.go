package services

import (
	"encoding/json"
	"time"

	"framework/messaging"
	sharedentities "shared/entities"
	sharedrepositories "shared/repositories"
	"transmitter/messenger/whatsappcloud"
	"transmitter/ratelimiter"
	"transmitter/repositories"
	"transmitter/services/configuration"

	"github.com/go-redis/redis/v8"
	"github.com/sirupsen/logrus"
)

func NewServiceFactory(
	client *redis.Client,
	amqpMessagingFactory *messaging.AMQPConnectionFactory,
	sharedRepositoryFactory sharedrepositories.RepositoryFactory,
	transmitterRepositoryFactory repositories.RepositoryFactory,
	logger *logrus.Logger,
) *ServiceFactory {
	return &ServiceFactory{
		client:                       client,
		amqpMessagingFactory:         amqpMessagingFactory,
		sharedRepositoryFactory:      sharedRepositoryFactory,
		transmitterRepositoryFactory: transmitterRepositoryFactory,
		logger:                       logger,
	}
}

type ServiceFactory struct {
	client                       *redis.Client
	amqpMessagingFactory         *messaging.AMQPConnectionFactory
	sharedRepositoryFactory      sharedrepositories.RepositoryFactory
	transmitterRepositoryFactory repositories.RepositoryFactory
	logger                       *logrus.Logger
}

func (f *ServiceFactory) NewWhatsAppCloudService(account *sharedentities.Account) *WhatsAppCloudService {
	var conf configuration.WhatsappCloud
	_ = json.Unmarshal(account.Configuration, &conf)

	return NewWhatsAppCloudService(
		account,
		&DefaultMSISDNNormalizer{},
		ratelimiter.NewRedisRateLimiter(f.client, &ratelimiter.Options{
			Period: time.Second,
			Limit:  int64(conf.RateLimit.Message),
		}),
		whatsappcloud.NewClient(
			conf.Host+"/"+conf.PhoneNoId,
			whatsappcloud.InsecureSkipVerify(true),
		),
		f.amqpMessagingFactory.NewAMQPPublisher(),
		f.sharedRepositoryFactory.NewClientRepository(),
		f.sharedRepositoryFactory.NewAccountRepository(),
		f.sharedRepositoryFactory.NewAccountCountryRepository(),
		f.transmitterRepositoryFactory.NewTokenRepository(),
		f.transmitterRepositoryFactory.NewOutboundRepository(),
		f.logger,
	)
}

func (f *ServiceFactory) NewWhatsAppCloudWaiService(account *sharedentities.Account) *WhatsAppCloudWaiService {
	var conf configuration.WhatsappCloud
	_ = json.Unmarshal(account.Configuration, &conf)

	return NewWhatsAppCloudWaiService(
		account,
		&DefaultMSISDNNormalizer{},
		ratelimiter.NewRedisRateLimiter(f.client, &ratelimiter.Options{
			Period: time.Second,
			Limit:  int64(conf.RateLimit.Message),
		}),
		whatsappcloud.NewClient(
			conf.Host+"/"+conf.PhoneNoId,
			whatsappcloud.InsecureSkipVerify(true),
		),
		f.amqpMessagingFactory.NewAMQPPublisher(),
		f.sharedRepositoryFactory.NewClientRepository(),
		f.sharedRepositoryFactory.NewAccountRepository(),
		f.sharedRepositoryFactory.NewAccountCountryRepository(),
		f.transmitterRepositoryFactory.NewTokenRepository(),
		f.transmitterRepositoryFactory.NewOutboundRepository(),
		f.logger,
	)
}
