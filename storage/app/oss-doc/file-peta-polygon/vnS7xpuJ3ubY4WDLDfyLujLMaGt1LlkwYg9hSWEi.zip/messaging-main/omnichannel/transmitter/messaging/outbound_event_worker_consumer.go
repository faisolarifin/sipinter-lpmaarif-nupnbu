package messaging

import (
	"fmt"
	"framework/messaging"
	"sync/atomic"

	"github.com/sirupsen/logrus"
	sharedentities "shared/entities"
)

type OutboundEventWorkerConsumer struct {
	state              int32
	typz               string
	queue              string
	account            *sharedentities.Account
	amqpWorkerConsumer *messaging.AMQPWorkerConsumer
	logger             *logrus.Entry
}

func NewOutboundEventWorkerConsumer(
	typz string,
	account *sharedentities.Account,
	amqpWorkerConsumer *messaging.AMQPWorkerConsumer,
	logger *logrus.Logger,
) *OutboundEventWorkerConsumer {
	queue := fmt.Sprintf("%s.%s.%s.outbound-%s",
		account.ClientId,
		account.ChannelId,
		account.AccountAlias,
		typz,
	)
	return &OutboundEventWorkerConsumer{
		typz:               typz,
		queue:              queue,
		account:            account,
		amqpWorkerConsumer: amqpWorkerConsumer,
		logger: logger.WithFields(
			logrus.Fields{
				"resource": "OutboundEventWorkerConsumer",
				"queue":    queue,
			},
		),
	}
}

func (c *OutboundEventWorkerConsumer) Consume() {
	if !atomic.CompareAndSwapInt32(&c.state, 0, 1) {
		return
	}

	c.logger.Infoln("Consume")
	logger := c.logger.WithField("func", "Consume")
	err := c.amqpWorkerConsumer.Consume(c.queue)
	if err != nil {
		logger.WithError(err).Errorln("AMQPWorkerConsumer.Consume")
	}
}

func (c *OutboundEventWorkerConsumer) Stop() {
	if !atomic.CompareAndSwapInt32(&c.state, 1, 0) {
		return
	}
	c.logger.Infoln("Stop")
	c.amqpWorkerConsumer.Stop()
}
