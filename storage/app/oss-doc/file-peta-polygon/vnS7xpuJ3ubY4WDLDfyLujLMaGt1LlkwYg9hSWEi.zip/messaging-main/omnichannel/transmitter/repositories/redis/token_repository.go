package redis

import (
	"context"
	"encoding/json"
	"fmt"

	"transmitter/entities"

	"github.com/go-redis/redis/v8"
	"github.com/jackc/pgx/v5"
	"github.com/pkg/errors"
)

func newTokenRepository(client *redis.Client) *TokenRepository {
	return &TokenRepository{
		client: client,
	}
}

type TokenRepository struct {
	client *redis.Client
}

func (r *TokenRepository) SetTx(tx pgx.Tx) {}

func (r *TokenRepository) Find(ctx context.Context, clientId, channelId, accountId string) (*entities.Token, error) {
	key := fmt.Sprintf("token.%s.%s.%s", clientId, channelId, accountId)
	data, err := r.client.Get(ctx, key).Bytes()
	if err != nil {
		if err == redis.Nil {
			if err == pgx.ErrNoRows {
				return nil, errors.WithStack(entities.NewErrorTokenNotFound(
					"Token With ClientId: '%s', GetChannelId: '%s' And AccountId: '%s' Not Found", clientId, channelId, accountId))
			}
		}
	}
	var token entities.Token
	if err = json.Unmarshal(data, &token); err != nil {
		return nil, errors.WithMessage(err, "TokenRepository.Token JSON.Unmarshal")
	}

	return &token, nil
}
