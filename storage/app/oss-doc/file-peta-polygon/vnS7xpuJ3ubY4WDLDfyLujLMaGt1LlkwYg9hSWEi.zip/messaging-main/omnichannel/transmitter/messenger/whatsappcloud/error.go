package whatsappcloud

import (
	"encoding/json"
	"fmt"
)

var (
	ErrNotAllowedSentMessageToAnotherCountry = ErrorResponse{
		ErrorData: ErrorData{
			Message:   "(#7465847383) The account not allowed sent message to another country.",
			Type:      "OAuthException",
			Code:      7465847383,
			FbtraceId: "7465847383",
		},
	}

	ErrorNotAllowedSentMessageToAnotherCountryByte, _ = json.Marshal(ErrNotAllowedSentMessageToAnotherCountry)

	ErrMessageAlreadyExpired = ErrorResponse{
		ErrorData: ErrorData{
			Code:      4558504952,
			FbtraceId: "4558504952",
			Type:      "MessageExpiredException",
			Message:   "(#4558504952) Message is already expired",
		},
	}

	ErrorMessageAlreadyExpiredByte, _ = json.Marshal(ErrMessageAlreadyExpired)
)

type ErrorResponse struct {
	ErrorData ErrorData `json:"error"`
}

func (e *ErrorResponse) Error() string {
	return fmt.Sprintf("Message: %s, Type: %s, Code: %d, FbtraceId: %s",
		e.ErrorData.Message, e.ErrorData.Type, e.ErrorData.Code, e.ErrorData.FbtraceId)
}

type ErrorData struct {
	Code      int    `json:"code"`
	Type      string `json:"type"`
	Message   string `json:"message"`
	FbtraceId string `json:"fbtrace_id"`
}
