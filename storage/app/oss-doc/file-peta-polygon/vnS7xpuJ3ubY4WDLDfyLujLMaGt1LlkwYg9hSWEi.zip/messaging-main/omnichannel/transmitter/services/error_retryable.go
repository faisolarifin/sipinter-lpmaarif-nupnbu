package services

import "fmt"

func NewErrorRetryableWithError(err error) *ErrorRetryable {
	return NewErrorRetryable(err.Error())
}

func NewErrorRetryable(format string, args ...any) *ErrorRetryable {
	return &ErrorRetryable{message: fmt.Sprintf(format, args...)}
}

type ErrorRetryable struct {
	message string
}

func (e *ErrorRetryable) Error() string {
	return e.message
}
