package sql

import (
	"context"
	"time"

	"framework/database"
	"transmitter/entities"
	"transmitter/repositories/sql/queries"

	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/pkg/errors"
)

func newContactRepository(db *pgxpool.Pool) *ContactRepository {
	return &ContactRepository{
		db: db,
	}
}

type ContactRepository struct {
	db database.Querier
}

func (r *ContactRepository) Create(ctx context.Context, args *entities.ContactCreate) (*entities.Contact, error) {
	namedArgs := map[string]any{
		"client_id":   args.ClientId,
		"channel_id":  args.ChannelId,
		"account_id":  args.AccountId,
		"msisdn":      args.MSISDN,
		"whatsapp_id": args.WhatsAppId,
		"expired_at":  args.ExpiredAt,
		"created_at":  args.CreatedAt,
	}
	query, params, err := database.NamedQuery(queries.ContactRepositoryCreate, namedArgs)
	if err != nil {
		return nil, errors.WithMessage(err, "ContactRepository.Create NamedQuery")
	}

	var contact entities.Contact
	row := r.db.QueryRow(ctx, query, params...)
	if err = r.scan(row, &contact); err != nil {
		return nil, errors.WithMessage(err, "ContactRepository.Create QueryRow")
	}

	return &contact, nil
}

func (r *ContactRepository) FindByMSISDN(ctx context.Context, clientId, channelId, accountId, msisdn string, before time.Time) (*entities.Contact, error) {
	namedArgs := map[string]any{
		"client_id":  clientId,
		"channel_id": channelId,
		"account_id": accountId,
		"msisdn":     msisdn,
		"before":     before.Format("2006-01-02"),
	}
	query, params, err := database.NamedQuery(queries.ContactRepositoryFindByMSISDN, namedArgs)
	if err != nil {
		return nil, errors.WithMessage(err, "ContactRepository.FindByMSISDN NamedQuery")
	}

	var contact entities.Contact
	row := r.db.QueryRow(ctx, query, params...)
	if err = r.scan(row, &contact); err != nil {
		return nil, errors.WithMessage(err, "ContactRepository.FindByMSISDN QueryRow")
	}

	return &contact, nil
}

func (r *ContactRepository) scan(scanner database.RowScanner, contact *entities.Contact) error {
	return scanner.Scan(
		&contact.Id,
		&contact.ClientId,
		&contact.ChannelId,
		&contact.AccountId,
		&contact.MSISDN,
		&contact.WhatsAppId,
		&contact.ExpiredAt,
		&contact.CreatedAt,
	)
}
