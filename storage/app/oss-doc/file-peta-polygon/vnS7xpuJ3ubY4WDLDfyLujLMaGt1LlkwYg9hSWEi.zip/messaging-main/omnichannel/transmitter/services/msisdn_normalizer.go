package services

type MSISDNNormalizer interface {
	Normalize(msisdn string) string
}

type DefaultMSISDNNormalizer struct{}

func (n *DefaultMSISDNNormalizer) Normalize(msisdn string) string {
	if len(msisdn) < 3 {
		return msisdn
	}

	if rune(msisdn[0]) == '0' {
		return "+62" + msisdn[1:]
	}

	if msisdn[0:2] == "62" {
		return "+" + msisdn
	}

	if rune(msisdn[0]) != '+' {
		return "+" + msisdn
	}

	return msisdn
}
