package cmd

import (
	"fmt"
	"os"

	"github.com/spf13/cobra"
)

func newRootCommand() *cobra.Command {
	cmd := &cobra.Command{
		Use:   "transmitter",
		Short: "Run and manage Coster V3 Transmitter",
	}
	registerCommand(cmd)

	return cmd
}

func registerCommand(root *cobra.Command) {
	root.AddCommand(newRunCmd())
}

func Execute() {
	if err := newRootCommand().Execute(); err != nil {
		fmt.Println(err)
		os.Exit(-1)
	}
}
