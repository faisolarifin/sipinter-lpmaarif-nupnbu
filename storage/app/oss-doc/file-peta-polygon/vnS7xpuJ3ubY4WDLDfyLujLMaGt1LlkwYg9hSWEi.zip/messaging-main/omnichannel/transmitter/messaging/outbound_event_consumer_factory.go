package messaging

import (
	"framework/messaging"
	"framework/messaging/consumer"
	"framework/pointer"
	"github.com/tidwall/gjson"
	sharedentities "shared/entities"
	"transmitter/services"

	"github.com/sirupsen/logrus"
)

func NewOutboundEventConsumerFactory(
	serviceFactory *services.ServiceFactory,
	amqpMessagingFactory *messaging.AMQPConnectionFactory,
	logger *logrus.Logger,
) *OutboundEventConsumerFactory {
	return &OutboundEventConsumerFactory{
		serviceFactory:       *serviceFactory,
		amqpMessagingFactory: amqpMessagingFactory,
		logger:               logger,
	}
}

type OutboundEventConsumerFactory struct {
	serviceFactory       services.ServiceFactory
	amqpMessagingFactory *messaging.AMQPConnectionFactory
	logger               *logrus.Logger
}

func (f *OutboundEventConsumerFactory) NewOutboundEventConsumer(typz string, account *sharedentities.Account) *OutboundEventConsumer {
	var service services.Service

	switch account.ChannelId {
	case sharedentities.ChannelWhatsApp.String():
	case sharedentities.ChannelWhatsAppCloud.String():
		switch pointer.Default(account.ChannelProviderId, "meta") {
		case "meta":
			service = f.serviceFactory.NewWhatsAppCloudService(account)
		case "wai":
			service = f.serviceFactory.NewWhatsAppCloudWaiService(account)
		}
	}

	return NewOutboundEventConsumer(
		typz,
		account,
		service,
		f.amqpMessagingFactory.NewAMQPConsumer(),
		f.logger,
	)
}

func (f *OutboundEventConsumerFactory) NewOutboundEventWorkerConsumer(typz string, account *sharedentities.Account) *OutboundEventWorkerConsumer {
	concurrency := int(gjson.GetBytes(account.Configuration, "concurrency").Int())
	if concurrency < 1 {
		concurrency = 20
	}

	return NewOutboundEventWorkerConsumer(
		typz,
		account,
		f.amqpMessagingFactory.NewAMQPWorkerConsumer(func() messaging.AMQPWorker {
			var service services.Service

			switch account.ChannelId {
			case sharedentities.ChannelWhatsApp.String():
			case sharedentities.ChannelWhatsAppCloud.String():
				switch pointer.Default(account.ChannelProviderId, "meta") {
				case "meta":
					service = f.serviceFactory.NewWhatsAppCloudService(account)
				case "wai":
					service = f.serviceFactory.NewWhatsAppCloudWaiService(account)
				}
			}

			return NewOutboundEventWorker(f.logger, service)
		},
			consumer.Qos(concurrency, 0, false),
			consumer.Concurrency(concurrency)),
		f.logger,
	)
}
