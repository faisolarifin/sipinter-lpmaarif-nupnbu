package whatsapppremise

import "fmt"

type Error struct {
	Code    int    `json:"code"`
	Title   string `json:"title"`
	Details string `json:"details"`
	Href    string `json:"href,omitempty"`
}

func (e *Error) Error() string {
	return fmt.Sprintf("Code: %d, Title: %s, Details: %s, Href: %s", e.Code, e.Title, e.Details, e.Href)
}
