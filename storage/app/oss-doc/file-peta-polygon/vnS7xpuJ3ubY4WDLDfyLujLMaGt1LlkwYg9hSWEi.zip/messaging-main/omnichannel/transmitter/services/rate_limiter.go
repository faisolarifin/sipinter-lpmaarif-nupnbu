package services

import (
	"context"
)

type RateLimiter interface {
	Allowed(ctx context.Context, clientId, channelId, accountId string) error
}
